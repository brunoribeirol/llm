"""llm.py — acesso ao modelo, com dois caminhos: API de verdade e simulador offline.

Uma função importa deste módulo:

    chamar_modelo(mensagens) -> {"texto", "tokens_entrada", "tokens_saida", "fonte"}

`mensagens` é a lista no formato de chat: [{"role": "system"|"user"|"assistant",
"content": "..."}]. Neste lab o ReAct é feito em TEXTO PURO — nenhuma API de tool
calling é usada, de propósito (Aula 23: ReAct é o padrão de interação, tool calling
é o transporte).

MODO DE EXECUÇÃO
    Com chave: `MODO=api` ou variável de ambiente `API_KEY` preenchida.
    Sem chave: simulador ROTEIRADO determinístico, semente fixa `SEMENTE = 25`.

A chave NUNCA aparece neste arquivo nem no notebook: ela entra por `getpass()` ou
pela variável de ambiente `API_KEY`.

MODO OFFLINE — o que ele é e o que ele não é
    O simulador é uma política escrita à mão que responde no formato ReAct. Ele
    roda sem rede, sempre igual, e serve para o loop ser depurado e para a sala sem
    internet. Ele NÃO mede capacidade de modelo nenhum, e o notebook diz isso em
    letra grande. A análise de trajetória do entregável vale nos dois modos: o que
    se analisa é o comportamento do SEU loop.

DEFEITOS ROTEIRADOS (usados pelos testes e pela demonstração do instrutor)
    llm.DEFEITO = None             -> comportamento normal
    llm.DEFEITO = "prosa"          -> primeira resposta sem linha `Action:`
    llm.DEFEITO = "repeticao"      -> repete a mesma ação para sempre
    llm.DEFEITO = "parada-precoce" -> responde no passo 1, sem observação
"""

import json
import os
import random
import re
import sys
import urllib.error
import urllib.request

SEMENTE = 25
random.seed(SEMENTE)

MODO = os.environ.get("MODO", "auto")               # auto | api | offline
MODELO_API = os.environ.get("MODELO", "llama-3.3-70b-versatile")
URL_API = os.environ.get("URL_API", "https://api.groq.com/openai/v1/chat/completions")
TIMEOUT_S = 60

# Sequência de parada: sem ela, o modelo inventa a própria `Observation:` e o loop
# passa a raciocinar sobre um resultado que ferramenta nenhuma produziu. Este é o
# detalhe de implementação que mais confunde quem escreve ReAct em texto puro.
PARADAS = ["Observation:", "\nObservation"]

DEFEITO = None


def tokens_aprox(texto):
    """1 token ~ 4 caracteres. Aproximação grosseira e declarada."""
    return max(1, len(texto) // 4)


# ---------------------------------------------------------------------------
# Caminho 1 — API de verdade
# ---------------------------------------------------------------------------
def obter_chave(interativo=True):
    if os.environ.get("API_KEY"):
        return os.environ["API_KEY"]
    if not interativo:
        return ""
    try:
        from getpass import getpass
        chave = getpass("API_KEY (Enter para o modo offline): ").strip()
    except Exception:
        chave = ""
    if chave:
        os.environ["API_KEY"] = chave
    return chave


def chamar_api(mensagens):
    corpo = json.dumps({
        "model": MODELO_API,
        "messages": mensagens,
        "temperature": 0.0,
        "stop": PARADAS,
    }).encode("utf-8")
    requisicao = urllib.request.Request(
        URL_API, data=corpo,
        headers={"Content-Type": "application/json",
                 "Authorization": f"Bearer {os.environ['API_KEY']}"})
    with urllib.request.urlopen(requisicao, timeout=TIMEOUT_S) as resposta:
        dados = json.loads(resposta.read().decode("utf-8"))
    uso = dados.get("usage", {})
    enviado = sum(tokens_aprox(m["content"]) for m in mensagens)
    texto = dados["choices"][0]["message"]["content"]
    return {"texto": texto,
            "tokens_entrada": uso.get("prompt_tokens", enviado),
            "tokens_saida": uso.get("completion_tokens", tokens_aprox(texto)),
            "fonte": f"api:{MODELO_API}"}


# ---------------------------------------------------------------------------
# Caminho 2 — simulador ROTEIRADO determinístico
# ---------------------------------------------------------------------------
def _pergunta_do_usuario(mensagens):
    for m in mensagens:
        if m["role"] == "user":
            return m["content"]
    return ""


def _tudo(mensagens):
    """Histórico SEM o prompt de sistema.

    Isto não é detalhe: o prompt de sistema contém o catálogo de ferramentas e a
    proibição de escrever `Observation:`, então procurar essas palavras no texto
    completo daria falso positivo em toda volta. É a mesma armadilha que o aluno
    encontra quando escreve heurística sobre o histórico.
    """
    return "\n".join(m["content"] for m in mensagens if m["role"] != "system")


def _acao(pensamento, nome, argumentos):
    return (f"Thought: {pensamento}\n"
            f"Action: {nome}\n"
            f"Action Input: {json.dumps(argumentos, ensure_ascii=False)}")


def simular(mensagens):
    pergunta = _pergunta_do_usuario(mensagens).lower()
    historico = _tudo(mensagens)
    observou_algo = any(m["role"] == "user" and m["content"].startswith("Observation:")
                        for m in mensagens)

    if DEFEITO == "parada-precoce":
        return ("Thought: acho que sei isso de cabeça.\n"
                "Final Answer: o prazo costuma ser de trinta dias.")

    if DEFEITO == "prosa" and not observou_algo:
        return ("Vou verificar o regulamento da universidade para responder com "
                "precisão sobre o prazo pedido.")

    if DEFEITO == "repeticao":
        return _acao("preciso confirmar isso no regulamento",
                     "buscar_regulamento", {"termo": "prazo"})

    # --- Pergunta 1: trancamento + conta ---
    if "trancar" in pergunta or "trancamento" in pergunta:
        if "trinta dias" not in historico:
            return _acao("a pergunta depende do prazo fixado no regulamento",
                         "buscar_regulamento",
                         {"termo": "prazo trancamento disciplina", "k": 2})
        if '"resultado"' not in historico:
            dias = re.search(r"(\d+)\s*dias", pergunta)
            passados = dias.group(1) if dias else "12"
            return _acao("o prazo é de 30 dias e já se passaram alguns; falta a conta",
                         "calcular", {"expressao": f"30 - {passados}"})
        restam = re.search(r'"resultado":\s*(-?\d+)', historico)
        valor = restam.group(1) if restam else "?"
        return ("Thought: tenho o dispositivo e a conta; posso encerrar citando a "
                "fonte.\n"
                f"Final Answer: o prazo é de 30 dias corridos desde o primeiro dia de "
                f"aula (Art. 42), então restam {valor} dias.")

    # --- Pergunta 2: monitoria, resolvida só com o regulamento ---
    if "monitoria" in pergunta or "monitor" in pergunta:
        if "doze horas" not in historico:
            return _acao("monitoria é matéria de regulamento",
                         "buscar_regulamento", {"termo": "monitoria carga nota", "k": 2})
        return ("Thought: o dispositivo responde as duas partes da pergunta.\n"
                "Final Answer: a monitoria exige nota igual ou superior a sete na "
                "disciplina e tem carga de até doze horas semanais (Art. 60).")

    # --- Pergunta 3: sem resposta no acervo. O agente precisa saber encerrar. ---
    if "temperatura" in pergunta or "1998" in pergunta:
        # A marca é `"resultados"`, que só aparece quando a ferramenta EXECUTOU —
        # o nome `buscar_web` já está no catálogo do prompt de sistema.
        if '"resultados"' not in historico:
            return _acao("isso não é matéria de regulamento; vou tentar o índice local",
                         "buscar_web", {"consulta": pergunta[:60]})
        return ("Thought: o índice local não tem o dado e eu não tenho fonte para "
                "afirmar nada.\n"
                "Final Answer: não encontrei essa informação nas fontes disponíveis. "
                "Busquei no índice local e ele não cobre dados climáticos; o "
                "regulamento também não trata do assunto.")

    # --- Genérico ---
    if not observou_algo:
        chaves = " ".join(re.findall(r"\w{4,}", pergunta)[:4])
        return _acao("vou procurar no regulamento antes de responder",
                     "buscar_regulamento", {"termo": chaves or "regulamento"})
    return ("Thought: com a observação que eu tenho, dá para responder.\n"
            "Final Answer: veja o dispositivo citado na observação acima.")


# ---------------------------------------------------------------------------
# Despacho
# ---------------------------------------------------------------------------
def usar_api():
    if MODO == "offline":
        return False
    if MODO == "api":
        return bool(os.environ.get("API_KEY"))
    return bool(os.environ.get("API_KEY"))


def chamar_modelo(mensagens):
    """Interface única do lab. Nunca levanta exceção por falha de rede: cai para o
    simulador e diz que caiu, porque um lab que morre por rede é um lab perdido."""
    if usar_api():
        try:
            return chamar_api(mensagens)
        except (urllib.error.URLError, urllib.error.HTTPError, KeyError) as erro:
            print(f"[llm] API indisponível ({type(erro).__name__}) — "
                  "seguindo no simulador offline", file=sys.stderr)
    texto = simular(mensagens)
    return {"texto": texto,
            "tokens_entrada": sum(tokens_aprox(m["content"]) for m in mensagens),
            "tokens_saida": tokens_aprox(texto),
            "fonte": f"simulador-roteirado(semente={SEMENTE})"}


if __name__ == "__main__":
    exemplo = [{"role": "system", "content": "..."},
               {"role": "user", "content": "Já passaram 12 dias. Ainda posso trancar?"}]
    resultado = chamar_modelo(exemplo)
    print(resultado["fonte"])
    print(resultado["texto"])
