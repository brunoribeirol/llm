"""ferramentas.py — as três ferramentas do agente do Lab 7. PRONTAS.

O que é seu neste lab é o LOOP, não as ferramentas. Elas estão implementadas aqui
para que o tempo de sala vá inteiro para o ciclo ReAct.

    buscar_regulamento(termo, k)  -> a base do Lab 5 virando ferramenta
    calcular(expressao)           -> aritmética com lista de permissão
    buscar_web(consulta)          -> busca SIMULADA sobre um índice local fixo

Três coisas para notar, porque cada uma volta na Aula 26:

1. Cada ferramenta valida a própria entrada. O host não confia no modelo, e a
   ferramenta não confia em quem a chamou. Isso é do Lab 6 e continua valendo.
2. Erro é devolvido como DICIONÁRIO, nunca levantado como exceção. Erro de
   ferramenta é informação: o agente lê e decide o que fazer.
3. `buscar_web` é um índice local FICTÍCIO, sem rede. Ela existe para o agente ter
   uma ferramenta que às vezes NÃO acha nada — porque saber parar sem resposta é
   parte do critério de parada, e um agente que sempre acha algo não treina isso.

`DESCRICOES` é o texto que o modelo lê. Ele é prompt: mudar uma descrição muda a
escolha do modelo, e isso é medível no Checkpoint 4.
"""

import re

import corpus_regulamento


# ---------------------------------------------------------------------------
# 1. A base do Lab 5 como ferramenta
# ---------------------------------------------------------------------------
def buscar_regulamento(termo, k=3):
    if not isinstance(termo, str) or not termo.strip():
        return {"erro": "'termo' é obrigatório e não pode ser vazio"}
    k = k if isinstance(k, int) and 1 <= k <= 5 else 3
    achados = corpus_regulamento.buscar(termo, k)
    if not achados:
        return {"achados": [], "aviso": "nenhum dispositivo casou com o termo — "
                                        "tente outras palavras"}
    return {"achados": achados, "fonte": corpus_regulamento.FONTE_DO_CORPUS}


# ---------------------------------------------------------------------------
# 2. Calculadora
# ---------------------------------------------------------------------------
PERMITIDO = re.compile(r"^[0-9\s\.\+\-\*/\(\)]+$")


def calcular(expressao):
    if not isinstance(expressao, str) or not PERMITIDO.match(expressao):
        return {"erro": "expressão inválida: só dígitos e + - * / ( ) são aceitos. "
                        "Passe a conta, não a pergunta."}
    try:
        return {"resultado": eval(expressao, {"__builtins__": {}}, {})}  # noqa: S307
    except Exception as erro:
        return {"erro": f"{type(erro).__name__}: {erro}"}


# ---------------------------------------------------------------------------
# 3. Busca web SIMULADA — índice local fixo, FICTÍCIO, sem rede
# ---------------------------------------------------------------------------
INDICE_WEB = [
    {"titulo": "Calendário acadêmico 2026 — período letivo",
     "trecho": ("O primeiro período letivo de 2026 começa em 2 de março e o segundo "
                "em 3 de agosto. (Página FICTÍCIA, criada para o Lab 7.)")},
    {"titulo": "Perguntas frequentes — portal do aluno",
     "trecho": ("O portal do aluno fica indisponível para manutenção nas madrugadas "
                "de domingo. (Página FICTÍCIA, criada para o Lab 7.)")},
    {"titulo": "Guia do monitor — coordenação de graduação",
     "trecho": ("O monitor recebe bolsa mensal e assina folha de frequência junto à "
                "coordenação. (Página FICTÍCIA, criada para o Lab 7.)")},
]


def buscar_web(consulta):
    """Busca sobre um índice local de três páginas fictícias. SEM REDE.

    Devolve `{"resultados": []}` quando não acha — e é isso que a torna útil no
    lab: o agente precisa saber encerrar dizendo que não achou.
    """
    if not isinstance(consulta, str) or not consulta.strip():
        return {"erro": "'consulta' é obrigatória"}
    palavras = [p for p in re.findall(r"\w+", consulta.lower()) if len(p) > 3]
    achados = []
    for pagina in INDICE_WEB:
        alvo = f"{pagina['titulo']} {pagina['trecho']}".lower()
        if any(p in alvo for p in palavras):
            achados.append(pagina)
    if not achados:
        return {"resultados": [], "aviso": "o índice local não tem nada sobre isso. "
                                          "Esta ferramenta NÃO acessa a internet."}
    return {"resultados": achados}


# ---------------------------------------------------------------------------
# O REGISTRO: nome -> função. Única ponte entre o texto do modelo e o código.
# ---------------------------------------------------------------------------
REGISTRO = {
    "buscar_regulamento": buscar_regulamento,
    "calcular": calcular,
    "buscar_web": buscar_web,
}

# O texto que o MODELO lê. É prompt — no Checkpoint 4 você mede o efeito de mexer nele.
DESCRICOES = {
    "buscar_regulamento": (
        "buscar_regulamento(termo: str, k: int = 3) — busca dispositivos do "
        "regulamento acadêmico da universidade por palavras-chave e devolve o "
        "identificador do dispositivo (ex.: 'Art. 42') e o texto integral. Use "
        "sempre que a pergunta envolver regra, prazo, nota mínima ou procedimento "
        "acadêmico. Passe palavras-chave, não a pergunta inteira."
    ),
    "calcular": (
        "calcular(expressao: str) — avalia uma expressão aritmética simples e "
        "devolve o resultado numérico. Aceita apenas dígitos e os operadores "
        "+ - * / ( ). Use para qualquer conta, inclusive subtração de dias. Passe "
        "a conta pronta (ex.: '30 - 12'), nunca a pergunta em português."
    ),
    "buscar_web": (
        "buscar_web(consulta: str) — busca em um índice local de páginas públicas da "
        "universidade (calendário, FAQ do portal, guia do monitor). NÃO acessa a "
        "internet: se o índice não tiver o assunto, devolve lista vazia. Use apenas "
        "quando a informação não estiver no regulamento."
    ),
}


def catalogo_em_texto():
    """As descrições no formato que entra no prompt de sistema."""
    return "\n".join(f"- {d}" for d in DESCRICOES.values())


if __name__ == "__main__":
    print(corpus_regulamento.FONTE_DO_CORPUS)
    print(buscar_regulamento("prazo de trancamento"))
    print(calcular("30 - 12"))
    print(calcular("quanto é 30 menos 12"))
    print(buscar_web("temperatura média em Recife em 1998"))
