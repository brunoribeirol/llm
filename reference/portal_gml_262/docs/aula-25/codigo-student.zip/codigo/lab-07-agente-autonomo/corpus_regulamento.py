"""corpus_regulamento.py — a base do Lab 5, reduzida, para servir de ferramenta.

Mesmo módulo do Lab 6 (Aula 22), reaproveitado aqui de propósito: no Lab 7 a base
deixa de ser o assunto e passa a ser UMA DAS FERRAMENTAS do agente.

GANCHO PARA O SEU LAB 5: se existir um `chunks.json` nesta pasta (o arquivo que o
notebook do Lab 5 gravou em `lab05_saida/`), ele é usado no lugar do corpus
embutido — e aí a ferramenta do agente passa a consultar a SUA base, indexada por
você na Aula 20. Copiar o arquivo para cá é o Checkpoint 3 deste lab.

Formato esperado do `chunks.json`: lista de objetos com as chaves `dispositivo`
(ou `id`), `titulo` e `texto`. É o formato que o Lab 5 grava.

A busca embutida é por termos, de propósito: aqui o assunto é o LOOP, não a
recuperação. Se o seu `chunks.json` estiver na pasta, a mesma função passa a
buscar nos seus chunks — a assinatura não muda, e é esse o ponto.
"""

import json
import pathlib
import re
import unicodedata

# ---------------------------------------------------------------------------
# Corpus embutido — regulamento acadêmico FICTÍCIO (o mesmo das Aulas 18 a 24).
# Texto inventado para a aula. Não é o regulamento de nenhuma instituição real.
# ---------------------------------------------------------------------------
EMBUTIDO = [
    {"dispositivo": "Art. 41", "titulo": "Da matrícula em disciplinas",
     "texto": ("A matrícula em disciplinas é realizada exclusivamente pelo portal do "
               "aluno. O aluno pode matricular-se em no máximo oito disciplinas por "
               "período letivo. Matrícula em disciplina com pré-requisito não cumprido "
               "é indeferida automaticamente pelo sistema.")},
    {"dispositivo": "Art. 42", "titulo": "Do trancamento de disciplina",
     "texto": ("O aluno pode solicitar o trancamento de uma disciplina isolada até o "
               "encerramento do prazo de trinta dias corridos contados a partir do "
               "primeiro dia de aula do período letivo. O trancamento não gera "
               "devolução do valor pago no período.")},
    {"dispositivo": "Art. 42 § 1º", "titulo": "Do trancamento de disciplina",
     "texto": ("Após o prazo previsto no caput, a solicitação só é aceita mediante "
               "justificativa documentada de motivo de saúde ou de força maior, "
               "protocolada em até dez dias úteis do fato gerador.")},
    {"dispositivo": "Art. 51", "titulo": "Da frequência mínima",
     "texto": ("É reprovado por falta o aluno que não alcançar setenta e cinco por "
               "cento de frequência às aulas de cada disciplina, apurada sobre o total "
               "de encontros previstos no plano de ensino.")},
    {"dispositivo": "Art. 52", "titulo": "Da segunda chamada de avaliação",
     "texto": ("O aluno ausente em avaliação pode requerer segunda chamada em até três "
               "dias úteis após a data original, com justificativa documentada. A prova "
               "substitui integralmente a nota da avaliação perdida.")},
    {"dispositivo": "Art. 53", "titulo": "Do coeficiente de rendimento",
     "texto": ("O coeficiente de rendimento é a média das notas finais ponderada pela "
               "carga horária das disciplinas cursadas. Disciplina trancada dentro do "
               "prazo não entra no cálculo.")},
    {"dispositivo": "Art. 60", "titulo": "Da monitoria",
     "texto": ("A monitoria é exercida por aluno regularmente matriculado, aprovado na "
               "disciplina objeto da monitoria com nota igual ou superior a sete. A "
               "carga é de até doze horas semanais e não gera vínculo empregatício.")},
    {"dispositivo": "Edital PRG-2025-014", "titulo": "Aproveitamento de disciplinas",
     "texto": ("O requerimento de aproveitamento deve ser protocolado com ementa e "
               "histórico oficiais da instituição de origem. A análise considera "
               "compatibilidade de ementa igual ou superior a setenta e cinco por cento "
               "da carga horária.")},
]

_AQUI = pathlib.Path(__file__).parent
_LAB5 = _AQUI / "chunks.json"
USANDO_LAB5 = _LAB5.exists()   # True quando a SUA base do Lab 5 está nesta pasta


def _normalizar_chunk(bruto, indice):
    """Aceita o formato do Lab 5 e o formato embutido, sem quebrar por chave ausente."""
    return {
        "dispositivo": bruto.get("dispositivo") or bruto.get("id") or f"chunk {indice}",
        "titulo": bruto.get("titulo", ""),
        "texto": bruto.get("texto") or bruto.get("conteudo", ""),
    }


if _LAB5.exists():
    _cru = json.loads(_LAB5.read_text(encoding="utf-8"))
    DISPOSITIVOS = [_normalizar_chunk(c, i) for i, c in enumerate(_cru)]
    FONTE_DO_CORPUS = f"chunks.json do SEU Lab 5 ({len(DISPOSITIVOS)} chunks)"
else:
    DISPOSITIVOS = EMBUTIDO
    FONTE_DO_CORPUS = (f"corpus embutido FICTÍCIO ({len(DISPOSITIVOS)} dispositivos) "
                       "— copie o chunks.json do Lab 5 para cá no Checkpoint 3")


def _normalizar(texto):
    t = unicodedata.normalize("NFKD", str(texto).lower())
    return "".join(c for c in t if not unicodedata.combining(c))


def buscar(termo, k=3):
    """Busca por termos. Devolve [{dispositivo, titulo, texto, score}].

    A assinatura é a mesma do Lab 6. Trocar o corpo por retrieval híbrido do Lab 5
    não muda nada para quem chama — é o ponto do Checkpoint 3.
    """
    palavras = [p for p in re.findall(r"\w+", _normalizar(termo)) if len(p) > 2]
    pontuados = []
    for d in DISPOSITIVOS:
        alvo = _normalizar(f"{d['dispositivo']} {d.get('titulo', '')} {d['texto']}")
        score = sum(1 for p in palavras if p in alvo)
        if score:
            pontuados.append((score, d))
    pontuados.sort(key=lambda par: -par[0])
    return [{"dispositivo": d["dispositivo"], "titulo": d.get("titulo", ""),
             "texto": d["texto"], "score": s} for s, d in pontuados[:k]]


def listar_dispositivos():
    """O índice do acervo. No Lab 6 isto era um RECURSO MCP; aqui é diagnóstico."""
    return [{"dispositivo": d["dispositivo"], "titulo": d.get("titulo", "")}
            for d in DISPOSITIVOS]


if __name__ == "__main__":
    print(FONTE_DO_CORPUS)
    for r in buscar("prazo de trancamento", k=3):
        print(f"  {r['score']}  {r['dispositivo']:<22} {r['titulo']}")
