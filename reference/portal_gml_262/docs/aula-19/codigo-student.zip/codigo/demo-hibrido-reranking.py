"""
Aula 19 — RAG II: retrieval híbrido, reranking e métricas
Demo do instrutor (13 min, fim do Bloco 1): o mesmo corpus, as mesmas consultas,
dois recuperadores — e o vencedor troca conforme a FORMA da consulta.

O ponto da demo é triplo:
  1. o denso é cego para identificador  (consulta C2);
  2. o esparso/BM25 é cego para paráfrase (consulta C1);
  3. a fusão por POSIÇÃO (RRF) resolve as duas sem calibrar escala nenhuma.

Roda em CPU, em segundos, sem chave de API. Nenhum LLM é chamado aqui.

    python demo-hibrido-reranking.py
    python demo-hibrido-reranking.py --k-rrf 1     # passo 6 da demo

O corpus é o mesmo regulamento FICTÍCIO da Aula 18, ampliado para 10 trechos.

Dependências: numpy (obrigatória). sentence-transformers é opcional — sem ele o
script cai num vetorizador léxico puro-numpy e AVISA na tela; BM25, RRF e as
métricas continuam funcionando normalmente.
"""

import argparse
import math
import re
import textwrap
import time
import unicodedata
from collections import Counter, defaultdict

import numpy as np

# ==========================================================================
# 1. Corpus de exemplo — FICTÍCIO
# ==========================================================================
# Texto inventado para a aula. NÃO é o regulamento de nenhuma instituição real.
# Os identificadores (Art. 42, PRG-2025-014) existem justamente para produzir o
# caso em que a busca vetorial perde para a busca por termo exato.

DOCUMENTOS = [
    {
        "id": "Art. 41",
        "capitulo": "CAPÍTULO III — DA MATRÍCULA E DO TRANCAMENTO",
        "titulo": "Da matrícula em disciplinas",
        "texto": (
            "A matrícula em disciplinas é realizada exclusivamente pelo portal do aluno, "
            "dentro do período divulgado no calendário acadêmico. O aluno pode matricular-se "
            "em no máximo oito disciplinas por período letivo. A matrícula em disciplina que "
            "exija pré-requisito não cumprido é indeferida automaticamente pelo sistema."
        ),
    },
    {
        "id": "Art. 42",
        "capitulo": "CAPÍTULO III — DA MATRÍCULA E DO TRANCAMENTO",
        "titulo": "Do trancamento de disciplina",
        "texto": (
            "O aluno pode solicitar o trancamento de uma disciplina isolada até o encerramento "
            "do prazo de trinta dias corridos contados a partir do primeiro dia de aula do "
            "período letivo. Após esse prazo, a solicitação só é aceita mediante justificativa "
            "documentada de motivo de saúde ou de força maior, analisada pela coordenação do "
            "curso. O trancamento não gera devolução do valor pago no período."
        ),
    },
    {
        "id": "Art. 43",
        "capitulo": "CAPÍTULO III — DA MATRÍCULA E DO TRANCAMENTO",
        "titulo": "Do trancamento total do período",
        "texto": (
            "O trancamento total do período letivo suspende o vínculo do aluno com o curso por "
            "um período, renovável uma única vez. O pedido é feito pelo portal e exige "
            "entrevista prévia com a coordenação. O aluno com trancamento total não pode cursar "
            "disciplinas isoladas nem participar de monitoria durante a suspensão."
        ),
    },
    {
        "id": "Art. 51",
        "capitulo": "CAPÍTULO IV — DA FREQUÊNCIA E DA AVALIAÇÃO",
        "titulo": "Da frequência mínima",
        "texto": (
            "É reprovado por falta o aluno que não alcançar setenta e cinco por cento de "
            "frequência às aulas de cada disciplina, apurada sobre o total de encontros "
            "previstos no plano de ensino. Abono de falta ocorre apenas nas hipóteses previstas "
            "em lei, mediante protocolo de documento comprobatório em até cinco dias úteis."
        ),
    },
    {
        "id": "Art. 52",
        "capitulo": "CAPÍTULO IV — DA FREQUÊNCIA E DA AVALIAÇÃO",
        "titulo": "Da segunda chamada de avaliação",
        "texto": (
            "O aluno ausente em avaliação pode requerer segunda chamada em até três dias úteis "
            "após a data original, com justificativa documentada. A prova de segunda chamada "
            "cobre o mesmo conteúdo e substitui integralmente a nota da avaliação perdida."
        ),
    },
    {
        "id": "Art. 53",
        "capitulo": "CAPÍTULO IV — DA FREQUÊNCIA E DA AVALIAÇÃO",
        "titulo": "Do coeficiente de rendimento",
        "texto": (
            "O coeficiente de rendimento é a média das notas finais ponderada pela carga horária "
            "das disciplinas cursadas. Disciplina trancada dentro do prazo não entra no cálculo; "
            "disciplina reprovada entra com a nota obtida."
        ),
    },
    {
        "id": "Art. 60",
        "capitulo": "CAPÍTULO V — DA MONITORIA E DA INICIAÇÃO CIENTÍFICA",
        "titulo": "Da monitoria",
        "texto": (
            "A monitoria é exercida por aluno regularmente matriculado, aprovado na disciplina "
            "objeto da monitoria com nota igual ou superior a sete, mediante seleção realizada "
            "pelo professor responsável. A carga é de até doze horas semanais e não gera vínculo "
            "empregatício."
        ),
    },
    {
        "id": "Edital PRG-2025-014",
        "capitulo": "EDITAIS VIGENTES",
        "titulo": "Aproveitamento de disciplinas cursadas em outra instituição",
        "texto": (
            "O requerimento de aproveitamento deve ser protocolado com ementa e histórico "
            "oficiais da instituição de origem. A análise considera compatibilidade de ementa "
            "igual ou superior a setenta e cinco por cento da carga horária. O resultado é "
            "divulgado no portal do aluno em até trinta dias."
        ),
    },
    {
        "id": "Edital PRG-2025-021",
        "capitulo": "EDITAIS VIGENTES",
        "titulo": "Seleção de monitores remunerados",
        "texto": (
            "Ficam abertas as inscrições para monitoria remunerada nas disciplinas do ciclo "
            "básico. A seleção considera o coeficiente de rendimento e uma entrevista com o "
            "professor responsável. A bolsa é paga mensalmente enquanto durar o vínculo."
        ),
    },
    {
        "id": "Edital PRG-2024-009",
        "capitulo": "EDITAIS VIGENTES",
        "titulo": "Mobilidade acadêmica nacional",
        "texto": (
            "O programa de mobilidade permite cursar até dois períodos letivos em instituição "
            "conveniada. A inscrição exige plano de estudos assinado pela coordenação e "
            "coeficiente de rendimento igual ou superior a seis."
        ),
    },
]


def texto_indexado(doc):
    """Chunking contextual da Aula 18: o prefixo situa o trecho no documento."""
    return f"Regulamento Acadêmico · {doc['capitulo']} · {doc['id']} — {doc['titulo']}: {doc['texto']}"


CHUNKS = [texto_indexado(d) for d in DOCUMENTOS]
IDS = [d["id"] for d in DOCUMENTOS]

# Conjunto rotulado — a maquete, com 3 consultas, do que o Lab 5 faz com 15 a 20.
CONSULTAS = [
    {
        "nome": "C1 (paráfrase pura)",
        "texto": "dá para desistir de uma matéria depois que as aulas já começaram?",
        "relevante": "Art. 42",
    },
    {
        "nome": "C2 (identificador)",
        "texto": "o que diz o edital PRG-2025-014?",
        "relevante": "Edital PRG-2025-014",
    },
    {
        "nome": "C3 (mista)",
        "texto": "prazo do Art. 42 se eu perder a data",
        "relevante": "Art. 42",
    },
]

# ==========================================================================
# 2. Recuperador esparso — BM25 escrito à mão
# ==========================================================================
# Os dois parâmetros do slide 4. Valores usuais: k1 entre 1,2 e 2,0; b = 0,75.
BM25_K1 = 1.5
BM25_B = 0.75


def tokenizar(texto):
    """Minúsculas, acentos removidos, e o token hifenizado preservado inteiro.

    Preservar `prg-2025-014` como um token só é o que dá ao BM25 o IDF altíssimo
    que faz ele cravar a consulta C2. As partes também entram, para robustez.
    """
    t = unicodedata.normalize("NFKD", texto.lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    brutos = re.findall(r"\w+(?:-\w+)+|\w+", t)
    saida = []
    for b in brutos:
        saida.append(b)
        if "-" in b:
            saida.extend(p for p in b.split("-") if p)
    return saida


class BM25:
    def __init__(self, documentos, k1=BM25_K1, b=BM25_B):
        self.k1, self.b = k1, b
        self.docs = [tokenizar(d) for d in documentos]
        self.n_docs = len(self.docs)
        self.avgdl = sum(len(d) for d in self.docs) / self.n_docs
        self.tf = [Counter(d) for d in self.docs]
        self.df = Counter()
        for d in self.docs:
            for termo in set(d):
                self.df[termo] += 1

    def idf(self, termo):
        n = self.df.get(termo, 0)
        return math.log((self.n_docs - n + 0.5) / (n + 0.5) + 1.0)

    def scores(self, consulta):
        q = tokenizar(consulta)
        out = np.zeros(self.n_docs, dtype=np.float32)
        for i in range(self.n_docs):
            dl = len(self.docs[i])
            total = 0.0
            for termo in q:
                f = self.tf[i].get(termo, 0)
                if f == 0:
                    continue
                num = f * (self.k1 + 1)
                den = f + self.k1 * (1 - self.b + self.b * dl / self.avgdl)
                total += self.idf(termo) * num / den
            out[i] = total
        return out


# ==========================================================================
# 3. Recuperador denso — com queda para vetorizador léxico
# ==========================================================================
MODELO_DENSO = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
MODELO_RERANKER = "cross-encoder/mmarco-mMiniLMv2-L12-H384-v1"


class VetorizadorLexico:
    """TF-IDF de n-gramas de caractere, em numpy puro. Só é usado no modo degradado.

    Precisa ser AJUSTADO no corpus e depois aplicado à consulta com o mesmo
    vocabulário — vetorizar consulta e documentos em espaços diferentes é
    exatamente o erro do Conceito 5 da Aula 18.
    """

    def __init__(self, n_min=3, n_max=5):
        self.n_min, self.n_max = n_min, n_max
        self.vocab, self.idf = None, None

    def _ngramas(self, t):
        t = " " + re.sub(r"\s+", " ", t.lower().strip()) + " "
        saida = []
        for n in range(self.n_min, self.n_max + 1):
            saida.extend(t[i:i + n] for i in range(len(t) - n + 1))
        return saida

    def ajustar(self, textos):
        listas = [self._ngramas(t) for t in textos]
        self.vocab = {g: i for i, g in enumerate(sorted({g for l in listas for g in l}))}
        m = self._contar(listas)
        df = (m > 0).sum(axis=0)
        self.idf = np.log((1 + len(textos)) / (1 + df)) + 1.0
        return self

    def _contar(self, listas):
        m = np.zeros((len(listas), len(self.vocab)), dtype=np.float32)
        for i, lista in enumerate(listas):
            for g, c in Counter(lista).items():
                j = self.vocab.get(g)
                if j is not None:
                    m[i, j] = 1.0 + math.log(c)
        return m

    def __call__(self, textos):
        m = self._contar([self._ngramas(t) for t in textos]) * self.idf
        normas = np.linalg.norm(m, axis=1, keepdims=True)
        return m / np.clip(normas, 1e-9, None)


def carregar_denso(corpus):
    """Devolve (funcao_de_embedding, nome, degradado)."""
    try:
        from sentence_transformers import SentenceTransformer
        modelo = SentenceTransformer(MODELO_DENSO)

        def embed(textos):
            return modelo.encode(list(textos), normalize_embeddings=True,
                                 show_progress_bar=False)

        return embed, MODELO_DENSO, False
    except Exception as erro:
        print(f"  [aviso] modelo denso indisponível ({type(erro).__name__}: {erro})")
        return VetorizadorLexico().ajustar(corpus), "TF-IDF char 3-5 (léxico)", True


def carregar_reranker():
    """Cross-encoder multilíngue. Devolve None se não carregar — a demo segue sem ele."""
    try:
        from sentence_transformers import CrossEncoder
        return CrossEncoder(MODELO_RERANKER)
    except Exception as erro:
        print(f"  [aviso] cross-encoder indisponível ({type(erro).__name__}: {erro})")
        return None


# ==========================================================================
# 4. Fusão por posição — Reciprocal Rank Fusion
# ==========================================================================
def ordem(scores):
    """Índices dos documentos ordenados do maior score para o menor."""
    return list(np.argsort(-np.asarray(scores)))


def rrf(rankings, k_rrf):
    """RRF(d) = Σ_i 1 / (k + rank_i(d)). Usa só POSIÇÃO — nenhum score entra aqui."""
    pontos = defaultdict(float)
    for ranking in rankings:
        for posicao, idx in enumerate(ranking, start=1):
            pontos[int(idx)] += 1.0 / (k_rrf + posicao)
    return sorted(pontos, key=lambda i: -pontos[i]), pontos


# ==========================================================================
# 5. Métricas
# ==========================================================================
def recall_em_k(ranking_ids, relevante, k):
    """Cada consulta tem exatamente 1 relevante: recall@k vira 1 se ele entrou no top-k."""
    return 1.0 if relevante in ranking_ids[:k] else 0.0


# ==========================================================================
# 6. Saída
# ==========================================================================
def titulo(txt):
    print("\n" + "=" * 78)
    print(txt)
    print("=" * 78)


def mostrar_ranking(rotulo, ranking, scores=None, relevante=None, k=3):
    print(f"\n  --- {rotulo} ---")
    for posicao, idx in enumerate(ranking[:k], start=1):
        marca = "  <== RELEVANTE" if relevante and IDS[idx] == relevante else ""
        valor = f"  score={scores[idx]:+.3f}" if scores is not None else ""
        print(f"  #{posicao}  {IDS[idx]:<22}{valor}{marca}")
        linha = DOCUMENTOS[idx]["titulo"]
        for l in textwrap.wrap(linha, 66):
            print(f"        {l}")


def main():
    parser = argparse.ArgumentParser(description="Demo da Aula 19 — híbrido e reranking")
    parser.add_argument("--k-rrf", type=int, default=60,
                        help="constante k do RRF (passo 6 da demo: tentar 1)")
    parser.add_argument("--k-ret", type=int, default=8,
                        help="candidatos que o estágio 1 entrega ao reranker")
    args = parser.parse_args()

    titulo("PASSO 1 — corpus e consultas")
    print(f"\n  {len(DOCUMENTOS)} trechos de regulamento FICTÍCIO, um chunk por artigo/edital.")
    for d in DOCUMENTOS:
        print(f"    {d['id']:<22} {d['titulo']}")
    print("\n  consultas rotuladas:")
    for c in CONSULTAS:
        print(f"    {c['nome']:<22} {c['texto']}")
        print(f"    {'':<22} relevante = {c['relevante']}")

    titulo("PASSO 2 — construindo os dois recuperadores")
    bm25 = BM25(CHUNKS)
    print(f"  BM25 pronto: k1={BM25_K1}  b={BM25_B}  avgdl={bm25.avgdl:.1f} tokens")
    embed, nome_denso, degradado = carregar_denso(CHUNKS)
    matriz = embed(CHUNKS)
    print(f"  denso pronto: {nome_denso}  (matriz {matriz.shape})")
    if degradado:
        print("\n  *** MODO DEGRADADO ***")
        print("  Sem modelo denso: o 'denso' aqui é um vetorizador léxico, que também")
        print("  falha na paráfrase. O BM25, o RRF e as métricas continuam válidos.")

    def denso_scores(consulta):
        v = embed([consulta])[0]
        return np.asarray(matriz) @ np.asarray(v)

    resultados = {}

    for c in CONSULTAS[:2]:
        titulo(f"PASSO 3/4 — {c['nome']}: \"{c['texto']}\"")
        s_d = denso_scores(c["texto"])
        s_b = bm25.scores(c["texto"])
        r_d, r_b = ordem(s_d), ordem(s_b)
        mostrar_ranking("denso", r_d, s_d, c["relevante"])
        mostrar_ranking("BM25", r_b, s_b, c["relevante"])
        resultados[c["nome"]] = (r_d, r_b)

    titulo(f"PASSO 5 — fusão por posição (RRF, k={args.k_rrf})")
    print("\n  Nenhum peso foi ajustado. Nenhum score entrou na conta — só a posição.")
    for c in CONSULTAS[:2]:
        r_d, r_b = resultados[c["nome"]]
        r_h, pontos = rrf([r_d, r_b], args.k_rrf)
        print(f"\n  {c['nome']}")
        for posicao, idx in enumerate(r_h[:3], start=1):
            marca = "  <== RELEVANTE" if IDS[idx] == c["relevante"] else ""
            print(f"    #{posicao}  {IDS[idx]:<22} RRF={pontos[idx]:.4f}{marca}")
    print(f"\n  [passo 6 da demo] rodar de novo com --k-rrf 1 e comparar o topo.")

    # ----------------------------------------------------------------------
    c3 = CONSULTAS[2]
    titulo(f"PASSO 7 — dois estágios em {c3['nome']}: \"{c3['texto']}\"")
    s_d, s_b = denso_scores(c3["texto"]), bm25.scores(c3["texto"])
    r_h, pontos = rrf([ordem(s_d), ordem(s_b)], args.k_rrf)
    candidatos = r_h[:args.k_ret]
    print(f"\n  estágio 1 (híbrido) devolveu {len(candidatos)} candidatos:")
    for posicao, idx in enumerate(candidatos, start=1):
        print(f"    #{posicao}  {IDS[idx]:<22} RRF={pontos[idx]:.4f}")

    reranker = carregar_reranker()
    if reranker is None:
        print("\n  Sem cross-encoder: o estágio 2 fica de fora desta execução.")
        print("  O argumento do custo é o mesmo: N documentos = N inferências por consulta,")
        print("  porque o par (consulta, documento) não pode ser pré-computado.")
        ranking_final = candidatos
    else:
        t0 = time.perf_counter()
        pares = [(c3["texto"], CHUNKS[i]) for i in candidatos]
        s_ce = reranker.predict(pares)
        dt = time.perf_counter() - t0
        reordenado = [candidatos[i] for i in np.argsort(-np.asarray(s_ce))]
        print(f"\n  estágio 2 (cross-encoder): {len(pares)} inferências em {dt:.2f}s")
        for posicao, idx in enumerate(reordenado, start=1):
            score = float(s_ce[candidatos.index(idx)])
            antes = candidatos.index(idx) + 1
            print(f"    #{posicao}  {IDS[idx]:<22} score={score:+.3f}   (era #{antes} no RRF)")
        ranking_final = reordenado

    titulo("PASSO 8 — a tabela que o Lab 5 vai construir com 15 a 20 consultas")
    estrategias = {"denso": [], "BM25": [], "híbrido (RRF)": []}
    for c in CONSULTAS:
        s_d, s_b = denso_scores(c["texto"]), bm25.scores(c["texto"])
        r_d, r_b = ordem(s_d), ordem(s_b)
        r_h, _ = rrf([r_d, r_b], args.k_rrf)
        for nome, ranking in (("denso", r_d), ("BM25", r_b), ("híbrido (RRF)", r_h)):
            ids = [IDS[i] for i in ranking]
            estrategias[nome].append((recall_em_k(ids, c["relevante"], 1),
                                      recall_em_k(ids, c["relevante"], 3)))

    print(f"\n  {len(CONSULTAS)} consultas rotuladas, 1 documento relevante cada.\n")
    print(f"  {'estratégia':<18}{'recall@1':>10}{'recall@3':>10}")
    print("  " + "-" * 38)
    for nome, pares_recall in estrategias.items():
        r1 = sum(p[0] for p in pares_recall) / len(pares_recall)
        r3 = sum(p[1] for p in pares_recall) / len(pares_recall)
        print(f"  {nome:<18}{r1:>10.2f}{r3:>10.2f}")
    print("\n  Com 3 consultas, cada uma vale 33 pontos percentuais: esta tabela ilustra")
    print("  o método, não sustenta conclusão. É por isso que o Lab 5 pede 15 a 20.")
    print(f"\n  (ranking final da C3 depois dos dois estágios: {IDS[ranking_final[0]]})")


if __name__ == "__main__":
    main()
