"""
Demonstração da Aula 12 — Leis de escala e alocação compute-optimal.

Grandes Modelos de Linguagem: do Transformer aos Agentes de IA · Aula 12 de 30 · CESAR

O que este script faz, em 8 minutos de aula:

  1. Imprime a tabela de alocação compute-optimal para orçamentos de 1e19 a 1e25 FLOPs.
  2. Plota a perda em função da computação em eixos log-log (a "lei de potência").
  3. Plota as curvas isoFLOP (perda x parâmetros, com o compute fixo) e marca os mínimos.
  4. Calcula o contrafactual do GPT-3: qual seria a alocação ótima do mesmo compute.
  5. Converte horas de GPU em FLOPs e daí em (parâmetros, tokens).

Python puro + matplotlib. Sem GPU, sem rede, sem download.

    python demo-scaling-laws.py
    python demo-scaling-laws.py --gpt3
    python demo-scaling-laws.py --orcamento-gpu 8 168 312e12 0.4
    python demo-scaling-laws.py --salvar          # grava PNGs em vez de abrir janela

-------------------------------------------------------------------------------
AVISO DE PROVENIÊNCIA (leia antes de citar qualquer número deste script)

As constantes da superfície de perda abaixo sao CALIBRADAS PARA FINS DIDATICOS.
Elas foram escolhidas para reproduzir exatamente dois resultados do artigo do
Chinchilla (Hoffmann et al., arXiv 2203.15556), obtidos pelas Abordagens 1 e 2:

    D_opt / N_opt ~ 20          (20 tokens de treino por parâmetro)
    N_opt         ~ sqrt(C/120) (consequência de C ~ 6ND com D = 20N)

Elas NAO sao os coeficientes publicados do ajuste paramétrico (Abordagem 3) do
artigo. As três abordagens do próprio artigo não coincidem perfeitamente entre
si, e essa discordância é a pergunta dirigida do desafio pós-aula.

O expoente da lei de potência de perda x compute vem de Kaplan et al.,
Scaling Laws for Neural Language Models (arXiv 2001.08361): alpha_C ~ 0,050.
-------------------------------------------------------------------------------
"""

import argparse
import math
import sys

# O terminal do Windows costuma vir em cp1252 e engole os caracteres acentuados
# e os símbolos das tabelas; reconfigurar a saída evita UnicodeEncodeError.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# --------------------------------------------------------------------------- #
# Constantes                                                                  #
# --------------------------------------------------------------------------- #

# Custo de treino em FLOPs: 2 FLOPs/parâmetro no forward + 4 no backward.
FLOPS_POR_PARAM_POR_TOKEN = 6

# Razão-alvo de tokens por parâmetro (Chinchilla, Abordagens 1 e 2).
# O desafio pós-aula pede para trocar 20 por 200 e por 2000.
RAZAO_ALVO = 20.0

# Superfície de perda didática: L(N, D) = E + A / N^alpha + B / D^alpha.
# Com o MESMO expoente nos dois termos, o mínimo isoFLOP fica em D/N = (B/A)^(1/alpha).
# Logo, para que o mínimo caia exatamente em RAZAO_ALVO, basta B = A * RAZAO_ALVO^alpha.
PERDA_IRREDUTIVEL = 1.69   # ordem de grandeza da entropia irredutível em nats/token
ALPHA = 0.35
A_TERMO = 400.0
B_TERMO = A_TERMO * RAZAO_ALVO ** ALPHA

# Lei de potência de perda x compute (Kaplan et al.).
ALPHA_C = 0.050

# Referências históricas, em (nome, parâmetros, tokens de treino).
REFERENCIAS = [
    ("GPT-3", 175e9, 300e9),
    ("Gopher", 280e9, 300e9),
    ("Chinchilla", 70e9, 1.4e12),
]

ORCAMENTOS_TABELA = [1e19, 1e20, 1e21, 1e22, 1e23, 1e24, 1e25]


# --------------------------------------------------------------------------- #
# Núcleo: as três contas da aula                                              #
# --------------------------------------------------------------------------- #

def perda(n_params: float, n_tokens: float) -> float:
    """Perda didática em nats/token para um par (parâmetros, tokens)."""
    return (
        PERDA_IRREDUTIVEL
        + A_TERMO / n_params ** ALPHA
        + B_TERMO / n_tokens ** ALPHA
    )


def compute(n_params: float, n_tokens: float) -> float:
    """C ~ 6 * N * D — o custo de treino em FLOPs."""
    return FLOPS_POR_PARAM_POR_TOKEN * n_params * n_tokens


def alocacao_otima(c_flops: float) -> tuple[float, float]:
    """
    Alocação compute-optimal fechada.

    Substituindo D = RAZAO_ALVO * N em C = 6ND:
        C = 6 * RAZAO_ALVO * N^2   =>   N = sqrt(C / (6 * RAZAO_ALVO))
    Com RAZAO_ALVO = 20, o denominador é 120 — a forma que vai ao quadro.
    """
    n_params = math.sqrt(c_flops / (FLOPS_POR_PARAM_POR_TOKEN * RAZAO_ALVO))
    return n_params, RAZAO_ALVO * n_params


def alocacao_otima_numerica(c_flops: float, passos: int = 4000) -> tuple[float, float, float]:
    """
    Mesma resposta, obtida por varredura da curva isoFLOP.

    Existe para provar em sala que o mínimo do U é o ponto da fórmula fechada —
    não é uma coincidência de calibração, é a derivada zerando.
    """
    melhor = None
    n_lo, n_hi = 1e6, 1e13
    for i in range(passos + 1):
        n_params = n_lo * (n_hi / n_lo) ** (i / passos)
        n_tokens = c_flops / (FLOPS_POR_PARAM_POR_TOKEN * n_params)
        if n_tokens < 1e5:
            continue
        valor = perda(n_params, n_tokens)
        if melhor is None or valor < melhor[0]:
            melhor = (valor, n_params, n_tokens)
    return melhor


def flops_de_horas_de_gpu(n_gpus: int, horas: float, pico_flops: float, mfu: float) -> float:
    """
    Converte hora de máquina em orçamento de FLOPs.

    MFU (model FLOPs utilization) é a fração do pico teórico que o treino
    realmente aproveita. Sem ela, o erro é de 2 a 3 vezes.
    """
    return pico_flops * n_gpus * mfu * horas * 3600


# --------------------------------------------------------------------------- #
# Formatação                                                                  #
# --------------------------------------------------------------------------- #

def humano(x: float) -> str:
    """Formata 1.5e9 como '1,50 B'."""
    for limite, sufixo in ((1e12, "T"), (1e9, "B"), (1e6, "M"), (1e3, "k")):
        if abs(x) >= limite:
            return f"{x / limite:,.2f} {sufixo}".replace(".", ",")
    return f"{x:,.0f}"


def titulo(texto: str) -> None:
    print()
    print("=" * 78)
    print(texto)
    print("=" * 78)


# --------------------------------------------------------------------------- #
# Saídas de texto                                                             #
# --------------------------------------------------------------------------- #

def imprimir_aviso() -> None:
    print("AVISO: as constantes da superfície de perda são CALIBRADAS PARA FINS DIDÁTICOS.")
    print(f"       Elas reproduzem a razão {RAZAO_ALVO:.0f} tokens/parâmetro e N = sqrt(C/{FLOPS_POR_PARAM_POR_TOKEN * RAZAO_ALVO:.0f}),")
    print("       resultados das Abordagens 1 e 2 do Chinchilla (arXiv 2203.15556).")
    print("       NÃO são os coeficientes publicados do ajuste paramétrico do artigo.")


def imprimir_tabela_alocacao() -> None:
    titulo("Alocação compute-optimal por orçamento de FLOPs")
    print(f"{'C (FLOPs)':>12} | {'N ótimo':>12} | {'D ótimo':>12} | {'D/N':>6} | {'perda':>7}")
    print("-" * 78)
    for c_flops in ORCAMENTOS_TABELA:
        n_params, n_tokens = alocacao_otima(c_flops)
        print(
            f"{c_flops:>12.1e} | {humano(n_params):>12} | {humano(n_tokens):>12} | "
            f"{n_tokens / n_params:>6.1f} | {perda(n_params, n_tokens):>7.4f}"
        )
    print()
    print("A coluna D/N é constante por construção: é o que 'compute-optimal' significa")
    print("operacionalmente — parâmetros e tokens crescem em proporção, não um só deles.")


def imprimir_lei_de_potencia() -> None:
    titulo("O que o expoente da lei de potência custa em dinheiro")
    print(f"Kaplan et al.: L(C) proporcional a C^(-alpha_C), com alpha_C ~ {ALPHA_C}")
    print()
    for fator in (2, 10, 100, 1000):
        reducao = 100 * (1 - fator ** -ALPHA_C)
        print(f"  {fator:>5}x mais compute  ->  {reducao:5.2f}% menos perda")
    fator_metade = 0.5 ** (-1 / ALPHA_C)
    print()
    print(f"  metade da perda      ->  {fator_metade:.3g}x mais compute")
    print()
    print("A lei de escala não promete barato. Promete previsível.")


def imprimir_referencias() -> None:
    titulo("Modelos históricos: o que foi feito x o que era ótimo para o mesmo compute")
    print(f"{'modelo':>12} | {'N':>10} | {'D':>10} | {'D/N':>7} | {'C':>9} | {'N ótimo':>10} | {'D ótimo':>10}")
    print("-" * 90)
    for nome, n_params, n_tokens in REFERENCIAS:
        c_flops = compute(n_params, n_tokens)
        n_opt, d_opt = alocacao_otima(c_flops)
        print(
            f"{nome:>12} | {humano(n_params):>10} | {humano(n_tokens):>10} | "
            f"{n_tokens / n_params:>7.1f} | {c_flops:>9.2e} | {humano(n_opt):>10} | {humano(d_opt):>10}"
        )
    print()
    print("Leitura da tabela: as três linhas gastaram compute de fronteira e as duas")
    print("primeiras alocaram quase tudo em parâmetro. O Chinchilla, com compute")
    print("equivalente ao Gopher, usou 4x menos parâmetros e 4,7x mais tokens.")


def imprimir_contrafactual_gpt3() -> None:
    n_params, n_tokens = 175e9, 300e9
    c_flops = compute(n_params, n_tokens)
    n_opt, d_opt = alocacao_otima(c_flops)
    perda_real = perda(n_params, n_tokens)
    perda_opt = perda(n_opt, d_opt)

    titulo("Contrafactual do GPT-3: o mesmo cheque, alocado pela regra do Chinchilla")
    print(f"  GPT-3 real          N = {humano(n_params):>10}   D = {humano(n_tokens):>10}   D/N = {n_tokens / n_params:5.1f}")
    print(f"  ótimo no mesmo C    N = {humano(n_opt):>10}   D = {humano(d_opt):>10}   D/N = {d_opt / n_opt:5.1f}")
    print()
    print(f"  orçamento C = 6 x {n_params:.2e} x {n_tokens:.2e} = {c_flops:.3e} FLOPs")
    print(f"  perda (superfície didática): real {perda_real:.4f}  x  ótimo {perda_opt:.4f}")
    print()
    print("  Mesmo dinheiro. Um terço dos parâmetros. Três vezes e meia os tokens.")

    valor, n_num, d_num = alocacao_otima_numerica(c_flops)
    print()
    print(f"  Confirmação por varredura da curva isoFLOP (nada de fórmula fechada):")
    print(f"    mínimo em N = {humano(n_num)}, D = {humano(d_num)}, D/N = {d_num / n_num:.1f}, perda = {valor:.4f}")


def imprimir_orcamento_gpu(n_gpus: int, horas: float, pico_flops: float, mfu: float) -> None:
    c_flops = flops_de_horas_de_gpu(n_gpus, horas, pico_flops, mfu)
    n_params, n_tokens = alocacao_otima(c_flops)
    bytes_por_param = 16  # 2 peso bf16 + 2 grad bf16 + 4 mestre fp32 + 4 Adam m + 4 Adam v
    estados_gib = bytes_por_param * n_params / 2 ** 30

    titulo("De hora de GPU para (parâmetros, tokens)")
    print(f"  {n_gpus} GPUs x {horas:.0f} h x {pico_flops:.3g} FLOP/s x MFU {mfu:.2f}")
    print(f"  = {pico_flops:.3g} x {n_gpus} x {mfu} x {horas * 3600:,.0f} s")
    print(f"  = {c_flops:.3e} FLOPs")
    print()
    print(f"  N ótimo = sqrt(C / {FLOPS_POR_PARAM_POR_TOKEN * RAZAO_ALVO:.0f}) = {humano(n_params)} parâmetros")
    print(f"  D ótimo = {RAZAO_ALVO:.0f} x N          = {humano(n_tokens)} tokens")
    print()
    print(f"  Memória de estados em precisão mista com AdamW ({bytes_por_param} bytes/param):")
    print(f"    {estados_gib:,.1f} GiB, ANTES de qualquer ativação.")
    print(f"    Contra {n_gpus} x 80 GB = {n_gpus * 80 * 1e9 / 2 ** 30:,.0f} GiB agregados.")
    print()
    print("  Se os estados não cabem numa GPU só mas cabem no agregado, o primeiro")
    print("  paralelismo é DADOS com estados particionados (ZeRO/FSDP) — e o que passa")
    print("  no cabo é gradiente, uma vez por passo. Paralelismo de tensor comunica")
    print("  ativação a cada camada e só sobrevive dentro do nó.")


# --------------------------------------------------------------------------- #
# Gráficos                                                                    #
# --------------------------------------------------------------------------- #

def graficos(salvar: bool) -> None:
    try:
        import matplotlib
        if salvar:
            matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print()
        print("matplotlib não encontrado — as saídas de texto acima já contêm todos os números.")
        print("Para instalar:  pip install matplotlib")
        return

    # --- Gráfico 1: perda x compute em log-log ----------------------------- #
    orcamentos = [10 ** e for e in [x / 20 for x in range(360, 520)]]  # 1e18 .. 1e26
    perdas = []
    for c_flops in orcamentos:
        n_params, n_tokens = alocacao_otima(c_flops)
        perdas.append(perda(n_params, n_tokens))

    fig1, ax1 = plt.subplots(figsize=(8, 5))
    ax1.plot(orcamentos, perdas, color="#e2231a", linewidth=2.2)
    ax1.set_xscale("log")
    ax1.set_yscale("log")
    ax1.set_xlabel("computação de treino C (FLOPs)")
    ax1.set_ylabel("perda no ponto compute-optimal (nats/token)")
    ax1.set_title("Lei de potência: perda x compute (eixos log-log)")
    ax1.grid(True, which="both", alpha=0.25)
    for nome, n_params, n_tokens in REFERENCIAS:
        c_ref = compute(n_params, n_tokens)
        n_opt, d_opt = alocacao_otima(c_ref)
        ax1.scatter([c_ref], [perda(n_opt, d_opt)], color="#5b8cff", zorder=5)
        ax1.annotate(nome, (c_ref, perda(n_opt, d_opt)),
                     textcoords="offset points", xytext=(6, 6), fontsize=9)
    reducao = 100 * (1 - 10 ** -ALPHA_C)
    ax1.annotate(f"reta em log-log: cada decada de compute\nvale ~{reducao:.1f}% de perda (alpha_C ~ {ALPHA_C})",
                 xy=(0.05, 0.12), xycoords="axes fraction", fontsize=9)
    fig1.tight_layout()

    # --- Gráfico 2: curvas isoFLOP ---------------------------------------- #
    fig2, ax2 = plt.subplots(figsize=(8, 5))
    minimos_n, minimos_l = [], []
    for expoente in (20, 21, 22, 23, 24):
        c_flops = 10.0 ** expoente
        ns, ls = [], []
        n_opt, _ = alocacao_otima(c_flops)
        for i in range(200):
            n_params = n_opt * (10 ** (-1.5 + 3.0 * i / 199))  # duas ordens em volta do ótimo
            n_tokens = c_flops / (FLOPS_POR_PARAM_POR_TOKEN * n_params)
            ns.append(n_params)
            ls.append(perda(n_params, n_tokens))
        ax2.plot(ns, ls, linewidth=1.6, label=f"C = 1e{expoente}")
        valor, n_min, _ = alocacao_otima_numerica(c_flops)
        minimos_n.append(n_min)
        minimos_l.append(valor)

    ax2.plot(minimos_n, minimos_l, "o--", color="#e2231a", linewidth=2.0,
             markersize=7, label="trilha compute-optimal")
    ax2.set_xscale("log")
    ax2.set_xlabel("N — parâmetros do modelo")
    ax2.set_ylabel("perda (nats/token)")
    ax2.set_title("Curvas isoFLOP: com C fixo, existe um mínimo interior")
    ax2.grid(True, which="both", alpha=0.25)
    ax2.legend(fontsize=8)
    ax2.annotate("modelo grande demais\npara o compute:\nfaltam tokens",
                 xy=(0.72, 0.62), xycoords="axes fraction", fontsize=8)
    ax2.annotate("modelo pequeno demais:\ncapacidade sobrando",
                 xy=(0.05, 0.62), xycoords="axes fraction", fontsize=8)
    fig2.tight_layout()

    # --- Gráfico 3: a razão D/N no mínimo --------------------------------- #
    fig3, ax3 = plt.subplots(figsize=(8, 4.2))
    cs, razoes = [], []
    for expoente in range(19, 26):
        c_flops = 10.0 ** expoente
        _, n_min, d_min = alocacao_otima_numerica(c_flops)
        cs.append(c_flops)
        razoes.append(d_min / n_min)
    ax3.plot(cs, razoes, "o-", color="#e2231a", linewidth=2.0)
    ax3.axhline(RAZAO_ALVO, color="#5b8cff", linestyle=":", linewidth=1.5,
                label=f"{RAZAO_ALVO:.0f} tokens/parâmetro")
    ax3.set_xscale("log")
    ax3.set_xlabel("computação de treino C (FLOPs)")
    ax3.set_ylabel("D/N no mínimo isoFLOP")
    ax3.set_ylim(0, RAZAO_ALVO * 2)
    ax3.set_title("A razão tokens/parâmetro no mínimo (por construção desta calibração)")
    ax3.grid(True, which="both", alpha=0.25)
    ax3.legend(fontsize=9)
    fig3.tight_layout()

    # plt.show() bloqueia até a janela ser fechada. Fora de um terminal interativo
    # (saída redirecionada, SSH, CI) não há janela para fechar e o processo fica
    # pendurado até ser morto. Nesse caso gravamos os PNGs e avisamos.
    backend_grafico = matplotlib.get_backend().lower() not in ("agg", "pdf", "ps", "svg", "template")
    pode_mostrar = backend_grafico and sys.stdout.isatty()

    if salvar or not pode_mostrar:
        if not salvar:
            print("[sem terminal interativo para abrir a janela — gravando PNG]")
        for fig, nome in ((fig1, "perda-x-compute.png"),
                          (fig2, "curvas-isoflop.png"),
                          (fig3, "razao-tokens-por-parametro.png")):
            fig.savefig(nome, dpi=150)
            print(f"gravado: {nome}")
    else:
        plt.show()


# --------------------------------------------------------------------------- #
# Entrada                                                                     #
# --------------------------------------------------------------------------- #

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--gpt3", action="store_true",
                        help="imprime o contrafactual do GPT-3 e encerra")
    parser.add_argument("--orcamento-gpu", nargs=4, metavar=("N_GPUS", "HORAS", "PICO_FLOPS", "MFU"),
                        help="converte hora de GPU em FLOPs e em (N, D). Ex.: 8 168 312e12 0.4")
    parser.add_argument("--sem-graficos", action="store_true", help="só as saídas de texto")
    parser.add_argument("--salvar", action="store_true",
                        help="grava os gráficos em PNG em vez de abrir janela")
    args = parser.parse_args()

    imprimir_aviso()

    if args.gpt3:
        imprimir_contrafactual_gpt3()
        return

    if args.orcamento_gpu:
        n_gpus, horas, pico, mfu = args.orcamento_gpu
        imprimir_orcamento_gpu(int(n_gpus), float(horas), float(pico), float(mfu))
        return

    imprimir_tabela_alocacao()
    imprimir_lei_de_potencia()
    imprimir_referencias()
    imprimir_contrafactual_gpt3()
    imprimir_orcamento_gpu(8, 168, 312e12, 0.40)

    if not args.sem_graficos:
        graficos(args.salvar)


if __name__ == "__main__":
    main()
