"""
Aula 21 — Tool calling e Model Context Protocol (MCP)
Demo do instrutor (12 min, meio do Bloco 1): o loop de tool calling na tela, e a
prova de que o SCHEMA É PARTE DO PROMPT.

A demo tem duas metades:
  PARTE 1 — uma chamada, passo a passo, com o JSON cru na tela: o modelo NÃO
            executa nada; ele pede. Quem executa é este script (o host).
  PARTE 2 — a mesma pergunta, três catálogos de ferramenta diferentes, e a taxa
            de acerto MEDIDA. Só muda o nome, a descrição e o nome do parâmetro.

    python demo-tool-calling.py --parte 1
    python demo-tool-calling.py --parte 2
    python demo-tool-calling.py            # as duas

Modo de execução (variável de ambiente MODO ou --modo):
    api       provedor com free tier compatível com a API de chat da OpenAI.
              A chave vem de API_KEY no ambiente. NUNCA é escrita neste arquivo.
    offline   simulador ROTEIRADO embutido — sem rede, sem chave.
              ATENÇÃO: o modo offline ilustra a MECÂNICA do loop. Ele NÃO mede
              competência de modelo nenhum, e a taxa de acerto que ele imprime é
              um roteiro escrito à mão, marcado como tal em toda saída.

    export API_KEY=...    |    set API_KEY=...    |    python ... --modo offline

Para a aula: rodar em modo `api` na véspera com --salvar-saida e levar o arquivo.
Se a rede da sala cair, projetar a saída salva — nunca inventar número na hora.

Dependências: nenhuma. Só a biblioteca padrão do Python 3.9+.
"""

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

MODO = os.environ.get("MODO", "auto")
MODELO_API = os.environ.get("MODELO", "llama-3.3-70b-versatile")  # conferir a lista do provedor na oferta
URL_API = "https://api.groq.com/openai/v1/chat/completions"
TIMEOUT_S = 60
REPETICOES = 3          # repetições por pergunta, para a taxa não ser de uma amostra só


# ==========================================================================
# 1. As ferramentas de verdade — o que o HOST sabe executar
# ==========================================================================
# Duas propriedades da aula estão aqui: são ESTREITAS (uma coisa cada) e
# VALIDÁVEIS (o host rejeita argumento fora do contrato antes de executar).

OPERADORES_PERMITIDOS = re.compile(r"^[0-9\s\.\+\-\*/\(\)%]+$")


def calcular(expressao):
    """Avalia uma expressão aritmética. Validação ANTES de executar.

    `eval` sobre string vinda de um modelo é a definição de ferramenta insegura.
    Aqui a lista de caracteres permitidos é a permissão da ferramenta.
    """
    if not isinstance(expressao, str) or not OPERADORES_PERMITIDOS.match(expressao):
        return {"erro": "expressão inválida: só dígitos e + - * / ( ) % são aceitos"}
    try:
        return {"resultado": eval(expressao, {"__builtins__": {}}, {})}  # noqa: S307
    except Exception as erro:
        return {"erro": f"{type(erro).__name__}: {erro}"}


def executar(nome, argumentos):
    """O DESPACHO. É esta função — não o modelo — que roda código."""
    if nome in ("calcular_expressao", "calc", "dados", "ferramenta"):
        chave = next((k for k in ("expressao", "q", "query", "entrada", "input")
                      if k in argumentos), None)
        if chave is None:
            return {"erro": f"nenhum parâmetro reconhecido em {list(argumentos)}"}
        return calcular(str(argumentos[chave]).strip())
    return {"erro": f"ferramenta desconhecida: {nome}"}


# ==========================================================================
# 2. Os três catálogos — a variável independente da PARTE 2
# ==========================================================================
# O código executado é IDÊNTICO nos três. O que muda é o que o modelo lê:
# o nome da ferramenta, a descrição e o nome do parâmetro. Ou seja: o prompt.

CATALOGO_BOM = [{
    "type": "function",
    "function": {
        "name": "calcular_expressao",
        "description": (
            "Avalia uma expressão aritmética e devolve o resultado numérico. "
            "Use sempre que a pergunta exigir uma conta, inclusive porcentagem. "
            "A expressão usa ponto como separador decimal."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "expressao": {
                    "type": "string",
                    "description": "Expressão aritmética, ex.: '0.125 * 480' ou '(37+45)/2'",
                },
            },
            "required": ["expressao"],
        },
    },
}]

CATALOGO_SEM_DESCRICAO = [{
    "type": "function",
    "function": {
        "name": "calc",
        "description": "calcula",
        "parameters": {
            "type": "object",
            "properties": {"q": {"type": "string"}},
            "required": ["q"],
        },
    },
}]

CATALOGO_VAGO = [{
    "type": "function",
    "function": {
        "name": "ferramenta",
        "description": "Ferramenta de uso geral. Passe o que precisar.",
        "parameters": {
            "type": "object",
            "properties": {"entrada": {"type": "string"}},
            "required": ["entrada"],
        },
    },
}]

CATALOGOS = [
    ("bom (nome + descrição + parâmetro nomeado)", CATALOGO_BOM),
    ("magro (nome abreviado, descrição de 1 palavra)", CATALOGO_SEM_DESCRICAO),
    ("vago (nome genérico, parâmetro genérico)", CATALOGO_VAGO),
]

# Perguntas com resposta verificável — o gabarito é aritmética, não julgamento.
PERGUNTAS = [
    ("Quanto é 12,5% de 480?", 60.0),
    ("Um lab tem 18 consultas e 14 acertos. Qual a taxa de acerto em porcentagem?",
     77.77777777777779),
    ("Se um reranker faz 10 inferências por consulta, quantas em 350 consultas?", 3500.0),
    ("Qual a média de 37, 45 e 53?", 45.0),
    ("Um chunk tem 512 tokens. Quantos tokens em 47 chunks?", 24064.0),
    ("Quanto é 2 elevado a 10, menos 24?", 1000.0),
]


# ==========================================================================
# 3. O host — o loop de tool calling, na mão
# ==========================================================================
SISTEMA = ("Você responde perguntas curtas. Quando a pergunta exigir uma conta, "
           "use a ferramenta disponível em vez de calcular de cabeça.")


def chamar_api(mensagens, ferramentas):
    chave = os.environ.get("API_KEY")
    if not chave:
        raise RuntimeError("API_KEY ausente no ambiente — use --modo offline.")
    corpo = json.dumps({
        "model": MODELO_API,
        "messages": mensagens,
        "tools": ferramentas,
        "tool_choice": "auto",
        "temperature": 0.0,
    }).encode("utf-8")
    req = urllib.request.Request(
        URL_API, data=corpo,
        headers={"Content-Type": "application/json",
                 "Authorization": f"Bearer {chave}"})
    with urllib.request.urlopen(req, timeout=TIMEOUT_S) as r:
        return json.loads(r.read().decode("utf-8"))


# --------------------------------------------------------------------------
# Simulador ROTEIRADO. Não é modelo. Não mede modelo. Existe para a mecânica
# do loop poder ser mostrada na sala sem rede — e para deixar visível que a
# diferença entre os catálogos é uma diferença de PROMPT.
# --------------------------------------------------------------------------
def chamar_simulado(mensagens, ferramentas):
    fn = ferramentas[0]["function"]
    nome = fn["name"]
    param = list(fn["parameters"]["properties"])[0]
    pergunta = next(m["content"] for m in mensagens if m["role"] == "user")
    ja_tem_resultado = any(m["role"] == "tool" for m in mensagens)

    if ja_tem_resultado:
        resultado = json.loads(next(m["content"] for m in reversed(mensagens)
                                    if m["role"] == "tool"))
        texto = (f"{resultado.get('resultado', resultado.get('erro'))}"
                 if isinstance(resultado, dict) else str(resultado))
        return {"choices": [{"message": {"role": "assistant",
                                         "content": f"O resultado é {texto}."}}]}

    # Roteiro EXPLÍCITO (não é inferência de modelo): o simulado só "entende" a
    # ferramenta quando o nome diz o que ela faz, o parâmetro diz o que recebe e
    # a descrição do parâmetro dá um exemplo. Nos outros catálogos ele manda a
    # PERGUNTA INTEIRA como argumento — chamada bem formada, argumento inútil.
    # É o modo de falha que o schema ruim produz de verdade.
    informativo = (nome == "calcular_expressao"
                   and param == "expressao"
                   and "ex.:" in json.dumps(fn, ensure_ascii=False))
    argumentos = {param: _extrair_expressao(pergunta) if informativo else pergunta}

    return {"choices": [{"message": {
        "role": "assistant", "content": None,
        "tool_calls": [{"id": "call_sim_1", "type": "function",
                        "function": {"name": nome,
                                     "arguments": json.dumps(argumentos)}}]}}]}


def _extrair_expressao(pergunta):
    """Tradução roteirada pergunta -> expressão, só para o modo offline."""
    tabela = {
        "12,5% de 480": "0.125 * 480",
        "14 acertos": "14 / 18 * 100",
        "350 consultas": "10 * 350",
        "média de 37": "(37 + 45 + 53) / 3",
        "47 chunks": "512 * 47",
        "2 elevado a 10": "1024 - 24",
    }
    for pista, expressao in tabela.items():
        if pista in pergunta:
            return expressao
    return pergunta


def conversar(pergunta, ferramentas, modo, verboso=False):
    """O loop completo. Devolve (resposta_final, chamadas, resultados)."""
    mensagens = [{"role": "system", "content": SISTEMA},
                 {"role": "user", "content": pergunta}]
    chamadas, resultados = [], []
    chamar = chamar_api if modo == "api" else chamar_simulado

    for _ in range(3):                      # orçamento de passos: 3 voltas
        resposta = chamar(mensagens, ferramentas)
        msg = resposta["choices"][0]["message"]
        tool_calls = msg.get("tool_calls") or []

        if verboso:
            print("\n  --- o que o MODELO devolveu (JSON cru) ---")
            print(_indentar(json.dumps(msg, ensure_ascii=False, indent=2)))

        if not tool_calls:
            return msg.get("content") or "", chamadas, resultados

        mensagens.append({"role": "assistant", "content": msg.get("content"),
                          "tool_calls": tool_calls})
        for tc in tool_calls:
            nome = tc["function"]["name"]
            try:
                argumentos = json.loads(tc["function"]["arguments"] or "{}")
            except json.JSONDecodeError:
                argumentos = {"__bruto__": tc["function"]["arguments"]}
            chamadas.append((nome, argumentos))

            if verboso:
                print(f"\n  --- o HOST executa (o modelo não executou nada) ---")
                print(f"  ferramenta : {nome}")
                print(f"  argumentos : {argumentos}")

            saida = executar(nome, argumentos)
            resultados.append(saida)
            if verboso:
                print(f"  retorno    : {saida}")
                print("\n  --- o resultado volta como mensagem de papel 'tool' ---")

            mensagens.append({"role": "tool", "tool_call_id": tc["id"],
                              "name": nome,
                              "content": json.dumps(saida, ensure_ascii=False)})
    return "(orçamento de passos esgotado)", chamadas, resultados


def _indentar(texto, prefixo="  "):
    return "\n".join(prefixo + linha for linha in texto.splitlines())


# ==========================================================================
# 4. Avaliação da PARTE 2 — a taxa de acerto de cada catálogo
# ==========================================================================
def acertou(resultados, gabarito):
    """Acerto = o HOST devolveu o número certo. Sem julgar prosa."""
    for r in resultados:
        valor = r.get("resultado") if isinstance(r, dict) else None
        if isinstance(valor, (int, float)) and abs(valor - gabarito) < 1e-6:
            return True
    return False


def medir_catalogo(ferramentas, modo):
    total = acertos = bem_formadas = 0
    for pergunta, gabarito in PERGUNTAS:
        for _ in range(REPETICOES if modo == "api" else 1):
            total += 1
            try:
                _, chamadas, resultados = conversar(pergunta, ferramentas, modo)
            except Exception as erro:
                print(f"    [erro] {type(erro).__name__}: {erro}")
                continue
            if chamadas:
                bem_formadas += 1
            if acertou(resultados, gabarito):
                acertos += 1
            if modo == "api":
                time.sleep(0.5)             # respeito ao rate limit do free tier
    return {"tentativas": total, "chamou_ferramenta": bem_formadas, "acertos": acertos}


# ==========================================================================
# 5. Saída
# ==========================================================================
def titulo(txt):
    print("\n" + "=" * 78)
    print(txt)
    print("=" * 78)


def aviso_modo(modo):
    if modo == "api":
        print(f"  modo API — modelo {MODELO_API} · {REPETICOES} repetições por pergunta")
        print("  Os números abaixo são MEDIDOS nesta execução. Anotar data e modelo.")
    else:
        print("  *** MODO OFFLINE — SIMULADOR ROTEIRADO ***")
        print("  A mecânica do loop é real; os 'acertos' abaixo são um roteiro escrito")
        print("  à mão. NÃO é medição de modelo e NÃO pode ser reportado como tal.")


def parte_1(modo):
    titulo("PARTE 1 — uma chamada, passo a passo: quem pede e quem executa")
    aviso_modo(modo)
    pergunta = PERGUNTAS[0][0]
    print(f"\n  catálogo entregue ao modelo (isto é PROMPT, não configuração):")
    print(_indentar(json.dumps(CATALOGO_BOM, ensure_ascii=False, indent=2), "    "))
    print(f"\n  pergunta do usuário: {pergunta!r}")

    final, chamadas, resultados = conversar(pergunta, CATALOGO_BOM, modo, verboso=True)
    print(f"\n  --- o modelo SINTETIZA a resposta final ---")
    print(f"  {final}")
    print(f"\n  resumo: {len(chamadas)} chamada(s) pedida(s) pelo modelo, "
          f"{len(resultados)} execução(ões) feita(s) pelo host.")
    print("  Em nenhum momento o modelo executou código. Ele emitiu texto —"
          " um JSON — e o host obedeceu.")


def parte_2(modo):
    titulo("PARTE 2 — mesmo código, mesmos exemplos, três catálogos")
    aviso_modo(modo)
    print(f"\n  {len(PERGUNTAS)} perguntas com gabarito aritmético.")
    print("  A FUNÇÃO EXECUTADA É A MESMA nos três catálogos. Muda só o que o")
    print("  modelo lê: nome da ferramenta, descrição e nome do parâmetro.\n")

    linhas = []
    for nome_catalogo, ferramentas in CATALOGOS:
        print(f"  medindo: {nome_catalogo} ...")
        linhas.append((nome_catalogo, medir_catalogo(ferramentas, modo)))

    print(f"\n  {'catálogo':<46}{'chamou':>9}{'acertou':>9}{'taxa':>8}")
    print("  " + "-" * 72)
    for nome_catalogo, m in linhas:
        taxa = m["acertos"] / m["tentativas"] if m["tentativas"] else 0.0
        print(f"  {nome_catalogo:<46}{m['chamou_ferramenta']:>9}"
              f"{m['acertos']:>9}{taxa:>8.2f}")
    print(f"\n  (n = {linhas[0][1]['tentativas']} tentativas por catálogo)")
    print("\n  O schema é parte do prompt. Trocar 'expressao' por 'q' e apagar a")
    print("  descrição não é refatoração: é reescrever o prompt do modelo.")


def main():
    p = argparse.ArgumentParser(description="Demo da Aula 21 — tool calling")
    p.add_argument("--parte", type=int, choices=(1, 2), help="rodar só uma parte")
    p.add_argument("--modo", choices=("auto", "api", "offline"), default=None)
    p.add_argument("--salvar-saida", metavar="ARQUIVO",
                   help="grava toda a saída num arquivo (uso na véspera da aula)")
    args = p.parse_args()

    modo = args.modo or MODO
    if modo == "auto":
        modo = "api" if os.environ.get("API_KEY") else "offline"

    if args.salvar_saida:
        arquivo = open(args.salvar_saida, "w", encoding="utf-8")

        class Duplo:
            def write(self, t):
                sys.__stdout__.write(t)
                arquivo.write(t)

            def flush(self):
                sys.__stdout__.flush()
                arquivo.flush()

        sys.stdout = Duplo()

    if args.parte in (None, 1):
        parte_1(modo)
    if args.parte in (None, 2):
        parte_2(modo)

    titulo("O QUE ESTA DEMO NÃO MOSTROU")
    print("\n  - permissão: nada aqui pediu confirmação para agir;")
    print("  - observabilidade: o registro da trajetória é este print, e não serve;")
    print("  - padronização: as ferramentas estão CRAVADAS neste arquivo. Trocar de")
    print("    host significa reescrever tudo. É esse problema que o MCP resolve,")
    print("    e é o Bloco 2 de hoje.")


if __name__ == "__main__":
    main()
