"""
Demo da Aula 16 — pass@k e consensus@k contra a temperatura.

O que esta demo mostra em 8 minutos: amostrar mais de uma vez muda o que a
métrica diz sobre o mesmo modelo. Temperatura baixa concentra a distribuição e
ganha em pass@1; temperatura alta espalha, perde em pass@1 e ganha em pass@10,
porque diversidade é o que faz aparecer *pelo menos uma* resposta correta.
Esse é o trade-off diversidade x correção — e é a razão pela qual pass@k só faz
sentido quando existe um verificador para escolher a amostra boa.

Duas rotas:

  --api      chama um modelo pequeno num provedor com free tier compatível com
             a API da OpenAI (Groq). A chave vem de GROQ_API_KEY ou de getpass;
             nunca fica no arquivo.
  --offline  amostrador sintético determinístico (seed fixa), sem rede. É a
             contingência da aula: roda no laptop do instrutor com o Wi-Fi
             caído e produz exatamente o mesmo gráfico.

Uso:
  python demo-pass-at-k.py --offline
  python demo-pass-at-k.py --offline --n 20
  python demo-pass-at-k.py --api --modelo llama-3.1-8b-instant --n 8

Como testar a rota --api (não é testável nesta máquina, que não tem chave):
  1. exportar a chave:  export GROQ_API_KEY=...    (PowerShell: $env:GROQ_API_KEY="...")
  2. rodar com n pequeno primeiro: --api --n 2  (5 problemas x 3 temperaturas x 2 = 30 chamadas)
  3. conferir no log "sem resposta extraída" — se aparecer muito, o modelo não
     está respeitando o formato "Resposta: <inteiro>" e o prompt precisa de um
     exemplo few-shot a mais.
"""

import argparse
import json
import math
import os
import random
import re
import statistics
import sys
import urllib.error
import urllib.request
from collections import Counter
from itertools import combinations

# --------------------------------------------------------------------------- #
# Problemas                                                                    #
# --------------------------------------------------------------------------- #
# Cinco problemas de palavra com resposta inteira, escritos para esta aula.
# São *no estilo* do GSM8K (aritmética de várias etapas, enunciado curto em
# linguagem natural) — não são itens do GSM8K.
# `distratores` são erros plausíveis: tipicamente o resultado de esquecer uma
# das etapas. Eles existem para o amostrador sintético gerar respostas erradas
# que se agrupam, que é o que acontece de verdade e o que faz consensus@k ter
# graça.

PROBLEMS = [
    {
        "id": "van",
        "enunciado": (
            "Uma van escolar faz 3 viagens por dia levando 12 crianças em cada viagem. "
            "Em 4 dias, quantos embarques de criança a van registrou?"
        ),
        "resposta": 144,
        "distratores": [36, 48, 12],
    },
    {
        "id": "troco",
        "enunciado": (
            "Um caderno custa R$ 14 e uma caneta custa R$ 6. Comprei 5 cadernos e 8 canetas "
            "e paguei com duas notas de R$ 100. Quanto recebi de troco, em reais?"
        ),
        "resposta": 82,
        "distratores": [118, 30, 18],
    },
    {
        "id": "lab",
        "enunciado": (
            "Numa turma de 40 alunos, 60% entregaram o Lab 1 e, dos que entregaram, "
            "um quarto entregou atrasado. Quantos alunos entregaram em dia?"
        ),
        "resposta": 18,
        "distratores": [24, 6, 30],
    },
    {
        "id": "servidor",
        "enunciado": (
            "Um servidor processa 250 requisições por minuto. Depois de uma otimização, "
            "passou a processar 40% mais. Quantas requisições ele processa em 3 minutos "
            "depois da otimização?"
        ),
        "resposta": 1050,
        "distratores": [750, 350, 300],
    },
    {
        "id": "caixa",
        "enunciado": (
            "Uma caixa d'água de 1200 litros está com 3/4 da capacidade. Vazam 15 litros "
            "por hora. Em quantas horas ela chega a 600 litros?"
        ),
        "resposta": 20,
        "distratores": [40, 60, 30],
    },
]

TEMPERATURAS = [0.2, 0.7, 1.2]
KS = [1, 2, 5, 10]

PROMPT_SISTEMA = (
    "Você resolve problemas de aritmética. Pense passo a passo em poucas linhas e "
    "termine SEMPRE com a última linha no formato exato:\nResposta: <número inteiro>"
)


# --------------------------------------------------------------------------- #
# Extração da resposta final                                                   #
# --------------------------------------------------------------------------- #

PADRAO_RESPOSTA = re.compile(
    r"resposta\s*(?:final)?\s*[:=]\s*\**\s*(-?\d[\d.,]*)", re.IGNORECASE
)
PADRAO_NUMERO = re.compile(r"-?\d[\d.,]*")


def _para_inteiro(bruto):
    """'1.050' -> 1050 ; 'R$ 82,00' -> 82 ; '1.234,56' -> 1234."""
    texto = bruto.strip()
    # separador de milhar: ponto ou vírgula seguidos de exatamente 3 dígitos
    texto = re.sub(r"(?<=\d)[.,](?=\d{3}\b)", "", texto)
    # descarta a parte decimal, se houver
    texto = re.split(r"[.,]", texto)[0]
    try:
        return int(texto)
    except ValueError:
        return None


def extrair_resposta(texto):
    """Devolve o inteiro da linha 'Resposta:' ou, na falta dela, o último número."""
    achados = PADRAO_RESPOSTA.findall(texto)
    if not achados:
        achados = PADRAO_NUMERO.findall(texto)
    if not achados:
        return None
    return _para_inteiro(achados[-1])


# --------------------------------------------------------------------------- #
# Métricas                                                                     #
# --------------------------------------------------------------------------- #

def pass_at_k(n, c, k):
    """
    Estimador não-viesado do pass@k (Chen et al., HumanEval):

        pass@k = 1 - C(n - c, k) / C(n, k)

    n = amostras geradas, c = quantas estão corretas, k = orçamento de tentativas.
    Se c > n - k, não existe subconjunto de tamanho k sem nenhuma correta: 1.0.
    """
    if k > n:
        raise ValueError(f"k={k} maior que n={n}")
    if n - c < k:
        return 1.0
    return 1.0 - math.comb(n - c, k) / math.comb(n, k)


def consensus_at_k(respostas, gabarito, k, rng, max_enumeracao=3000):
    """
    consensus@k = probabilidade de o voto majoritário sobre k amostras acertar.

    Enumera todos os C(n, k) subconjuntos quando isso é barato; caso contrário,
    estima por reamostragem. Empate no topo conta como 1/m (m = modas empatadas),
    que é o valor esperado de desempatar por sorteio.
    """
    n = len(respostas)
    if k > n:
        raise ValueError(f"k={k} maior que n={n}")

    def acerto(subconjunto):
        contagem = Counter(r for r in subconjunto if r is not None)
        if not contagem:
            return 0.0
        maior = max(contagem.values())
        modas = [valor for valor, qtd in contagem.items() if qtd == maior]
        return (1.0 / len(modas)) if gabarito in modas else 0.0

    if math.comb(n, k) <= max_enumeracao:
        subconjuntos = combinations(respostas, k)
        total = 0.0
        quantos = 0
        for sub in subconjuntos:
            total += acerto(sub)
            quantos += 1
        return total / quantos

    sorteios = 500
    return sum(acerto(rng.sample(respostas, k)) for _ in range(sorteios)) / sorteios


# --------------------------------------------------------------------------- #
# Rota offline: amostrador sintético                                           #
# --------------------------------------------------------------------------- #
#
# O amostrador NÃO resolve os problemas — ele simula a distribuição de saídas de
# um modelo pequeno. O modelo tem, para cada problema, uma resposta de maior
# probabilidade (o argmax). Em 3 dos 5 problemas esse argmax está correto; nos
# outros 2 está errado, e a resposta certa só aparece quando a amostragem se
# afasta do argmax.
#
#   temperatura sobe  ->  o argmax perde massa
#                     ->  cai a chance de acertar onde o argmax já acertava
#                     ->  sobe a chance de acertar onde o argmax errava
#
# É essa assimetria que produz o trade-off da aula: T baixa vence em pass@1,
# T alta vence em pass@10.

ARGMAX_CORRETO = {"van": True, "troco": True, "lab": True, "servidor": False, "caixa": False}


def _prob_acerto(problema, temperatura):
    if ARGMAX_CORRETO[problema["id"]]:
        # o argmax está certo: temperatura só atrapalha, e de forma linear
        return max(0.05, 0.92 - 0.45 * temperatura)
    # o argmax está errado: só a cauda da distribuição salva, e ela só engorda
    # de verdade em temperatura alta — daí o expoente
    return min(0.85, 0.22 * temperatura ** 3.1)


def _resposta_errada(problema, temperatura, rng):
    """
    Erro plausível. Com temperatura baixa o modelo repete sempre o mesmo erro
    (a moda errada é forte); com temperatura alta os erros se espalham, o que é
    exatamente o que corrói o consensus@k.
    """
    distratores = problema["distratores"]
    peso_moda = max(0.30, 0.90 - 0.35 * temperatura)
    if rng.random() < peso_moda:
        return distratores[0]
    if rng.random() < 0.75:
        return rng.choice(distratores[1:]) if len(distratores) > 1 else distratores[0]
    # ruído: um inteiro qualquer na vizinhança da resposta
    base = max(2, abs(problema["resposta"]))
    return problema["resposta"] + rng.choice([-1, 1]) * rng.randint(1, max(2, base // 2))


def amostrar_offline(problema, temperatura, n, rng):
    saidas = []
    p = _prob_acerto(problema, temperatura)
    for _ in range(n):
        if rng.random() < p:
            saidas.append(problema["resposta"])
        else:
            saidas.append(_resposta_errada(problema, temperatura, rng))
    return saidas


# --------------------------------------------------------------------------- #
# Rota API: provedor compatível com OpenAI (Groq free tier)                    #
# --------------------------------------------------------------------------- #

URL_API = "https://api.groq.com/openai/v1/chat/completions"


def obter_chave():
    chave = os.environ.get("GROQ_API_KEY")
    if chave:
        return chave
    from getpass import getpass
    return getpass("GROQ_API_KEY: ")


def chamar_modelo(enunciado, temperatura, modelo, chave, max_tokens=400):
    corpo = json.dumps(
        {
            "model": modelo,
            "temperature": temperatura,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "system", "content": PROMPT_SISTEMA},
                {"role": "user", "content": enunciado},
            ],
        }
    ).encode("utf-8")

    requisicao = urllib.request.Request(
        URL_API,
        data=corpo,
        headers={
            "Authorization": f"Bearer {chave}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(requisicao, timeout=60) as resposta:
        dados = json.loads(resposta.read().decode("utf-8"))
    return dados["choices"][0]["message"]["content"]


def amostrar_api(problema, temperatura, n, modelo, chave):
    """n chamadas independentes — a API do Groq não garante `n` > 1 por requisição."""
    saidas = []
    for i in range(n):
        try:
            texto = chamar_modelo(problema["enunciado"], temperatura, modelo, chave)
        except (urllib.error.URLError, urllib.error.HTTPError, KeyError, TimeoutError) as erro:
            print(f"    [falha na amostra {i + 1}: {erro}]", file=sys.stderr)
            saidas.append(None)
            continue
        valor = extrair_resposta(texto)
        if valor is None:
            print(f"    [sem resposta extraída na amostra {i + 1}]", file=sys.stderr)
        saidas.append(valor)
    return saidas


# --------------------------------------------------------------------------- #
# Execução e relatório                                                         #
# --------------------------------------------------------------------------- #

def rodar(args):
    rng = random.Random(args.seed)
    chave = obter_chave() if args.api else None

    resultados = {}  # temperatura -> {"pass": {k: v}, "consensus": {k: v}, "por_problema": [...]}

    for temperatura in args.temperaturas:
        print(f"\n>>> temperatura {temperatura}")
        por_problema = []
        for problema in PROBLEMS:
            if args.api:
                saidas = amostrar_api(problema, temperatura, args.n, args.modelo, chave)
            else:
                saidas = amostrar_offline(problema, temperatura, args.n, rng)
            corretas = sum(1 for r in saidas if r == problema["resposta"])
            por_problema.append({"problema": problema, "saidas": saidas, "c": corretas})
            moda = Counter(r for r in saidas if r is not None).most_common(1)
            moda_txt = moda[0][0] if moda else "—"
            print(
                f"    {problema['id']:<9} corretas {corretas}/{args.n}"
                f"   moda {moda_txt}   gabarito {problema['resposta']}"
            )

        ks_validos = [k for k in args.ks if k <= args.n]
        passos = {}
        consensos = {}
        for k in ks_validos:
            passos[k] = statistics.fmean(
                pass_at_k(args.n, item["c"], k) for item in por_problema
            )
            consensos[k] = statistics.fmean(
                consensus_at_k(item["saidas"], item["problema"]["resposta"], k, rng)
                for item in por_problema
            )
        resultados[temperatura] = {
            "pass": passos,
            "consensus": consensos,
            "por_problema": por_problema,
        }

    return resultados, ks_validos


def imprimir_tabela(resultados, ks_validos, n):
    print("\n" + "=" * 74)
    print(f"pass@k  —  {len(PROBLEMS)} problemas, n = {n} amostras por problema")
    print("=" * 74)
    cabecalho = "temperatura | " + " | ".join(f"pass@{k:<2}" for k in ks_validos)
    print(cabecalho)
    print("-" * len(cabecalho))
    for temperatura, bloco in resultados.items():
        celulas = " | ".join(f"{bloco['pass'][k]:>7.3f}" for k in ks_validos)
        print(f"{temperatura:>11.1f} | {celulas}")

    print("\n" + "=" * 74)
    print("consensus@k  —  voto majoritário, sem verificador")
    print("=" * 74)
    cabecalho = "temperatura | " + " | ".join(f"cons@{k:<2}" for k in ks_validos)
    print(cabecalho)
    print("-" * len(cabecalho))
    for temperatura, bloco in resultados.items():
        celulas = " | ".join(f"{bloco['consensus'][k]:>7.3f}" for k in ks_validos)
        print(f"{temperatura:>11.1f} | {celulas}")

    # a leitura que interessa na aula
    k_max = ks_validos[-1]
    melhor_p1 = max(resultados, key=lambda t: resultados[t]["pass"][ks_validos[0]])
    melhor_pk = max(resultados, key=lambda t: resultados[t]["pass"][k_max])
    print(
        f"\nMelhor pass@{ks_validos[0]}: temperatura {melhor_p1}"
        f"   |   melhor pass@{k_max}: temperatura {melhor_pk}"
    )
    print(
        "pass@k mede o que o modelo PODE fazer (precisa de verificador para colher);\n"
        "consensus@k mede o que ele ENTREGA sem verificador."
    )


def plotar(resultados, ks_validos, destino):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as erro:  # noqa: BLE001 — matplotlib é opcional na demo
        print(f"\n[sem gráfico: {erro}] A tabela acima já é suficiente para a aula.")
        return

    try:
        figura, (esq, dir_) = plt.subplots(1, 2, figsize=(11, 4.4), sharey=True)
        for temperatura, bloco in resultados.items():
            esq.plot(
                ks_validos,
                [bloco["pass"][k] for k in ks_validos],
                marker="o",
                label=f"T = {temperatura}",
            )
            dir_.plot(
                ks_validos,
                [bloco["consensus"][k] for k in ks_validos],
                marker="s",
                label=f"T = {temperatura}",
            )
        esq.set_title("pass@k  (com verificador)")
        dir_.set_title("consensus@k  (voto majoritário)")
        for eixo in (esq, dir_):
            eixo.set_xlabel("k — amostras por problema")
            eixo.set_xticks(ks_validos)
            eixo.set_ylim(0, 1.02)
            eixo.grid(alpha=0.3)
            eixo.legend()
        esq.set_ylabel("fração de problemas resolvidos")
        figura.suptitle("Diversidade x correção: o que a temperatura troca")
        figura.tight_layout()
        figura.savefig(destino, dpi=140)
        print(f"\nGráfico salvo em {destino}")
    except Exception as erro:  # noqa: BLE001
        print(f"\n[falha ao gerar o gráfico: {erro}]")


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    rota = parser.add_mutually_exclusive_group()
    rota.add_argument("--api", action="store_true", help="chamar o modelo de verdade (Groq)")
    rota.add_argument(
        "--offline",
        action="store_true",
        help="amostrador sintético determinístico, sem rede (padrão)",
    )
    parser.add_argument("--n", type=int, default=10, help="amostras por problema (padrão 10)")
    parser.add_argument(
        "--temperaturas",
        type=float,
        nargs="+",
        default=TEMPERATURAS,
        help="temperaturas a comparar (padrão 0.2 0.7 1.2)",
    )
    parser.add_argument("--ks", type=int, nargs="+", default=KS, help="valores de k (padrão 1 2 5 10)")
    parser.add_argument("--modelo", default="llama-3.1-8b-instant", help="modelo na rota --api")
    parser.add_argument("--seed", type=int, default=7, help="seed do amostrador offline")
    parser.add_argument(
        "--saida",
        default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "pass-at-k-vs-temperatura.png"),
        help="caminho do PNG",
    )
    args = parser.parse_args()

    # terminal do Windows costuma vir em cp1252 e engole os acentos da tabela
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    if not args.api:
        args.offline = True
    print("rota:", "API (Groq)" if args.api else "offline (amostrador sintético)")

    resultados, ks_validos = rodar(args)
    imprimir_tabela(resultados, ks_validos, args.n)
    plotar(resultados, ks_validos, args.saida)


if __name__ == "__main__":
    main()
