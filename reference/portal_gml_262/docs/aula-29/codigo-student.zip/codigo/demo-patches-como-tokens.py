"""Aula 29 · demo — patches são tokens, e patch NÃO é compressão.

Esta demo existe para transformar em aritmética uma frase que a turma vai ouvir como
slogan: "uma imagem vale por dez mil tokens de texto". Ela mostra três coisas, nesta
ordem:

    1. O Transformer não sabe de onde vem a sequência. Texto virou token pelo
       tokenizer (Aula 2); imagem vira token pelo patch 16x16 (ViT, 2010.11929).
       A abstração é a mesma: sequência de vetores com posição.

    2. Fatiar em patches NÃO comprime. A mesma página em imagem tem MAIS unidades de
       sequência que em texto — e o número de patches não depende do conteúdo, só da
       resolução e do tamanho do patch. Página em branco custa igual a página cheia.

    3. A compressão de DeepSeek-OCR (2510.18234) mora no ENCODER que reduz a grade de
       patches a poucos tokens visuais, e ela é lossy. O número que importa nunca é a
       taxa de compressão sozinha: é o par (compressão, fidelidade).

Uso:

    python demo-patches-como-tokens.py                  # a demo da aula, na ordem
    python demo-patches-como-tokens.py --dpi 150        # varia a resolução
    python demo-patches-como-tokens.py --patch 32       # varia o tamanho do patch
    python demo-patches-como-tokens.py --reducao 4      # encoder que comprime menos
    python demo-patches-como-tokens.py --arquivo meu_corpus.txt

Dependências: nenhuma. Roda com a biblioteca padrão, offline e determinística.
Se `transformers` estiver instalado, a contagem de tokens usa um tokenizer real e a
saída diz qual; se não estiver, usa um contador por regex documentado abaixo. Nos dois
casos a rota é DECLARADA na saída — a mesma exigência de procedência do Lab 8.
"""

import argparse
import math
import re

# =========================================================================
# A página de texto: trecho de um regulamento acadêmico FICTÍCIO
# =========================================================================
# É o mesmo corpus de referência usado no Lab 5 e no Lab 8, para a turma comparar
# com números que ela já viu. Não é o regulamento de nenhuma instituição real.

PAGINA = """
Art. 41. A matrícula em disciplinas é realizada exclusivamente pelo portal do aluno,
dentro do período divulgado no calendário acadêmico. O aluno pode matricular-se em no
máximo oito disciplinas por período letivo. A matrícula em disciplina que exija
pré-requisito não cumprido é indeferida automaticamente pelo sistema.

Art. 42. O aluno pode solicitar o trancamento de uma disciplina isolada até o
encerramento do prazo de trinta dias corridos contados a partir do primeiro dia de
aula do período letivo. O trancamento não gera devolução do valor pago no período.

§ 1º Após o prazo previsto no caput, a solicitação só é aceita mediante justificativa
documentada de motivo de saúde ou de força maior, protocolada em até dez dias úteis do
fato gerador e analisada pela coordenação do curso, que decide em até quinze dias.

§ 2º O trancamento total do curso é ato distinto do trancamento de disciplina e segue
o rito do Art. 47, com limite de dois períodos letivos consecutivos.

Art. 51. É exigida frequência mínima de setenta e cinco por cento das aulas de cada
disciplina, apurada sobre o total de encontros previstos no plano de ensino da
respectiva disciplina. A frequência é registrada pelo professor a cada encontro.

§ 1º Faltas por motivo de saúde, luto ou convocação legal são justificáveis mediante
documento protocolado em até cinco dias úteis, e a justificativa não abate a falta do
cômputo de frequência, apenas autoriza reposição de avaliação perdida.
""".strip()


# Geometria de página. A4 é o formato do documento que o sistema de OCR renderiza.
LARGURA_A4_POL = 8.27          # 210 mm
ALTURA_A4_POL = 11.69          # 297 mm


# =========================================================================
# Contagem de tokens de texto — duas rotas, e a rota usada é declarada
# =========================================================================

def contar_tokens_texto(texto):
    """Devolve (n_tokens, nome_da_rota).

    Rota A (preferida): tokenizer real do `transformers`, se estiver instalado. Usa um
    modelo pequeno e multilíngue para não depender de download grande; se o download
    falhar por falta de rede, cai para a rota B sem quebrar a demo.

    Rota B (padrão offline): contador determinístico. Ele aproxima o comportamento de
    um BPE em português com duas regras explícitas — separa palavras, números e
    pontuação; e quebra palavra longa em pedaços de até 5 caracteres, porque é o que
    um BPE faz com termo raro. Não é um tokenizer: é uma estimativa declarada.
    """
    try:
        from transformers import AutoTokenizer          # noqa: PLC0415
        tok = AutoTokenizer.from_pretrained("bert-base-multilingual-cased")
        return len(tok.encode(texto, add_special_tokens=False)), \
            "tokenizer real (bert-base-multilingual-cased)"
    except Exception:
        pass

    pecas = re.findall(r"\w+|[^\w\s]", texto, flags=re.UNICODE)
    total = 0
    for peca in pecas:
        total += max(1, math.ceil(len(peca) / 5)) if peca.isalnum() else 1
    return total, "contador por regex (offline, aproxima BPE em ~5 caracteres/token)"


# =========================================================================
# Geometria: quantos patches uma página vale
# =========================================================================

def geometria_pagina(dpi, patch):
    """Quantos patches cabem numa página A4 a `dpi`, com patch quadrado de lado `patch`.

    Este é o ponto da demo: o resultado NÃO depende do conteúdo da página. Página em
    branco e página cheia de texto têm exatamente o mesmo custo em patches.
    """
    largura_px = int(LARGURA_A4_POL * dpi)
    altura_px = int(ALTURA_A4_POL * dpi)
    colunas = largura_px // patch
    linhas = altura_px // patch
    return {
        "largura_px": largura_px,
        "altura_px": altura_px,
        "colunas": colunas,
        "linhas": linhas,
        "patches": colunas * linhas,
    }


# =========================================================================
# Patamares reportados por DeepSeek-OCR (2510.18234)
# =========================================================================
# Faixas aproximadas relatadas no paper, para a leitura em sala. O ponto pedagógico
# não são os valores exatos: é que compressão sem fidelidade do lado não é resultado.

PATAMARES_OCR = [
    ("~10x", "~97%", "reconstrução praticamente íntegra do texto da página"),
    ("~20x", "~60%", "perda alta: já não serve para citação literal"),
]


def _linha(titulo=""):
    print()
    if titulo:
        print(f"  {titulo}")
        print("  " + "-" * max(24, len(titulo)))


def main():
    parser = argparse.ArgumentParser(
        description="Patches como tokens, e onde mora a compressão")
    parser.add_argument("--dpi", type=int, default=96,
                        help="resolução de renderização da página (padrão 96)")
    parser.add_argument("--patch", type=int, default=16,
                        help="lado do patch quadrado em pixels (padrão 16, como no ViT)")
    parser.add_argument("--reducao", type=int, default=16,
                        help="fator de redução do encoder visual (padrão 16)")
    parser.add_argument("--arquivo", default=None,
                        help="usa o texto deste arquivo em vez da página embutida")
    args = parser.parse_args()

    texto = PAGINA
    fonte = "página embutida (regulamento fictício do Lab 5)"
    if args.arquivo:
        with open(args.arquivo, encoding="utf-8") as arquivo:
            texto = arquivo.read()
        fonte = args.arquivo

    print()
    print("=" * 68)
    print("  Aula 29 — patches são tokens, e patch NÃO é compressão")
    print("=" * 68)

    # ---- 1. o texto como sequência de tokens ------------------------------
    _linha("1. A mesma página, contada em tokens de TEXTO")
    n_tokens, rota = contar_tokens_texto(texto)
    print(f"  fonte              : {fonte}")
    print(f"  caracteres         : {len(texto)}")
    print(f"  rota de contagem   : {rota}")
    print(f"  TOKENS DE TEXTO    : {n_tokens}")

    # ---- 2. o texto como sequência de patches ----------------------------
    _linha("2. A mesma página, contada em PATCHES de imagem")
    geo = geometria_pagina(args.dpi, args.patch)
    print(f"  página A4 a {args.dpi} DPI  : {geo['largura_px']} x {geo['altura_px']} px")
    print(f"  patch              : {args.patch} x {args.patch} px")
    print(f"  grade              : {geo['colunas']} x {geo['linhas']}")
    print(f"  PATCHES            : {geo['patches']}")
    razao = geo["patches"] / n_tokens
    print()
    print(f"  >>> a versão em imagem tem {razao:.1f}x MAIS unidades de sequência")
    print("      que a versão em texto. Fatiar em patches é ANTI-compressão.")

    # ---- 3. o custo em patches não depende do conteúdo -------------------
    _linha("3. O número de patches não depende do que está escrito")
    print("  A conta acima usou apenas resolução e tamanho de patch. Uma página em")
    print("  branco custa exatamente os mesmos patches que esta página cheia de texto.")
    print("  Texto não tem essa propriedade: token conta conteúdo.")
    print()
    print("  patches por página, variando resolução e patch:")
    print()
    print("    DPI   patch=16   patch=32   patch=64")
    print("    " + "-" * 40)
    for dpi in (72, 96, 150, 300):
        celulas = "  ".join(
            f"{geometria_pagina(dpi, p)['patches']:>8}" for p in (16, 32, 64))
        print(f"    {dpi:<5} {celulas}")

    # ---- 4. onde mora a compressão --------------------------------------
    _linha("4. A compressão mora no ENCODER, não no corte")
    tokens_visuais = max(1, geo["patches"] // args.reducao)
    print(f"  encoder com redução de {args.reducao}x:")
    print(f"    {geo['patches']} patches  ->  {tokens_visuais} tokens visuais")
    print(f"  razão texto/visual : {n_tokens / tokens_visuais:.2f}x")
    if tokens_visuais < n_tokens:
        print("  >>> AGORA há compressão: menos tokens visuais que tokens de texto.")
        print("      Ela é do codec, não do patch — e ela é lossy.")
    else:
        print("  >>> ainda NÃO há compressão nesta configuração. Aumente --reducao")
        print("      ou reduza o --dpi e veja o ponto de virada.")

    # ---- 5. compressão sem fidelidade não é resultado -------------------
    _linha("5. Compressão × fidelidade — DeepSeek-OCR (arXiv 2510.18234)")
    print("    compressão   precisão de decodificação   leitura")
    print("    " + "-" * 62)
    for taxa, precisao, leitura in PATAMARES_OCR:
        print(f"    {taxa:<12} {precisao:<27} {leitura}")
    print()
    print("  Faixas aproximadas relatadas no paper; os valores exatos dependem do modo")
    print("  e do documento. O ponto não são os números: é que taxa de compressão sem")
    print("  fidelidade do lado não é resultado — é a mesma exigência do Lab 8.")
    print()
    print("  E o instrumento que mede fidelidade de reconstrução é o mesmo do Lab 8:")
    print("  proporção de conteúdo recuperado é recall com outro nome.")
    print()


if __name__ == "__main__":
    main()
