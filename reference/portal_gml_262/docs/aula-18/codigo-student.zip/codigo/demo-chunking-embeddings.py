"""
Aula 18 — RAG I: geração aumentada por recuperação
Demo do instrutor (10 min, fim do Bloco 1): a mesma consulta, o mesmo modelo de
embedding e o mesmo corpus, cortados de três jeitos diferentes.

O ponto da demo é um só: a estratégia de CHUNKING decide o resultado da recuperação
ANTES de existir gerador. Nenhum LLM é chamado neste script.

Roda em CPU, em segundos:
    python demo-chunking-embeddings.py

Sem chave de API. Se `sentence-transformers` não estiver instalado ou o download do
modelo falhar, o script cai automaticamente num vetorizador léxico (TF-IDF de
n-gramas de caractere) e avisa na tela. Esse modo degradado é pedagogicamente útil:
ele ERRA a consulta em paráfrase, que é exatamente a abertura da Aula 19.

Dependências: numpy (obrigatória); sentence-transformers e scikit-learn (opcionais).
"""

import re
import sys
import textwrap

import numpy as np

# --------------------------------------------------------------------------
# Corpus de exemplo — FICTÍCIO
# --------------------------------------------------------------------------
# Texto inventado para a demo. NÃO é o regulamento de nenhuma instituição real.
# Os identificadores (Art. 42, PRG-2025-014) são fictícios e existem para mostrar,
# na Aula 19, o caso em que a busca vetorial perde para a busca por termo exato.

CORPUS = """\
REGULAMENTO ACADÊMICO DA GRADUAÇÃO (documento fictício, uso didático)

CAPÍTULO III — DA MATRÍCULA E DO TRANCAMENTO

Art. 41 — Da matrícula em disciplinas.
A matrícula em disciplinas é realizada exclusivamente pelo portal do aluno, dentro do
período divulgado no calendário acadêmico. O aluno pode matricular-se em no máximo
oito disciplinas por período letivo. A matrícula em disciplina que exija pré-requisito
não cumprido é indeferida automaticamente pelo sistema, sem análise individual.

Art. 42 — Do trancamento de disciplina.
O aluno pode solicitar o trancamento de uma disciplina isolada até o encerramento do
prazo de trinta dias corridos contados a partir do primeiro dia de aula do período
letivo. Após esse prazo, a solicitação só é aceita mediante justificativa documentada
de motivo de saúde ou de força maior, analisada pela coordenação do curso. O
trancamento não gera devolução do valor pago no período e a disciplina trancada
consta no histórico com a anotação de trancamento, sem efeito sobre o coeficiente de
rendimento.

Art. 43 — Do trancamento total do período.
O trancamento total do período letivo suspende o vínculo do aluno com o curso por um
período, renovável uma única vez. O pedido é feito pelo portal e exige entrevista
prévia com a coordenação. O aluno com trancamento total não pode cursar disciplinas
isoladas nem participar de monitoria durante a suspensão.

Edital PRG-2025-014 — Aproveitamento de disciplinas cursadas em outra instituição.
O requerimento de aproveitamento deve ser protocolado com ementa e histórico oficiais.
A análise considera compatibilidade de ementa igual ou superior a setenta e cinco por
cento da carga horária. O resultado é divulgado no portal do aluno.
"""

CONSULTA = "dá pra desistir de uma matéria depois que as aulas já começaram?"

# Frases que a resposta correta precisa conter para estar completa. Servem para
# mostrar, na tela, que o chunk vencedor pode estar "certo" e ainda assim incompleto.
FRAGMENTOS_DA_RESPOSTA = [
    "trinta dias corridos",
    "justificativa documentada",
]


# --------------------------------------------------------------------------
# Três estratégias de chunking
# --------------------------------------------------------------------------
def chunk_fixo(texto, tamanho=220, sobreposicao=0):
    """Corte de tamanho fixo em caracteres. Insensível ao conteúdo."""
    texto = " ".join(texto.split())
    passo = tamanho - sobreposicao
    if passo <= 0:
        raise ValueError("sobreposicao deve ser menor que tamanho")
    return [texto[i:i + tamanho] for i in range(0, len(texto), passo) if texto[i:i + tamanho].strip()]


def chunk_por_artigo(texto):
    """Corte por fronteira semântica: um chunk por artigo/edital, com prefixo contextual.

    Cada chunk carrega o capítulo e o identificador canônico — é o chunking
    'contextual' do slide 7: o termo da seção não se repete no corpo do trecho.
    """
    capitulo = ""
    chunks = []
    atual = None
    for linha in texto.splitlines():
        if linha.startswith("CAPÍTULO"):
            capitulo = linha.strip()
            continue
        cabecalho = re.match(r"^(Art\.\s*\d+|Edital\s+[A-Z]{2,}-\d{4}-\d+)\s*—\s*(.+)$", linha.strip())
        if cabecalho:
            if atual:
                chunks.append(atual)
            id_canonico, titulo = cabecalho.group(1), cabecalho.group(2)
            atual = {
                "id_canonico": id_canonico,
                "titulo": titulo.rstrip("."),
                "capitulo": capitulo,
                "corpo": [],
            }
        elif atual and linha.strip():
            atual["corpo"].append(linha.strip())
    if atual:
        chunks.append(atual)

    formatados = []
    for c in chunks:
        prefixo = f"Regulamento Acadêmico · {c['capitulo']} · {c['id_canonico']} — {c['titulo']}:"
        formatados.append(f"{prefixo} " + " ".join(c["corpo"]))
    return formatados


ESTRATEGIAS = {
    "fixo 220, sem sobreposição": lambda t: chunk_fixo(t, 220, 0),
    "fixo 220, sobreposição 60": lambda t: chunk_fixo(t, 220, 60),
    "por artigo (+ prefixo contextual)": chunk_por_artigo,
}


# --------------------------------------------------------------------------
# Vetorização: modelo denso, com queda para vetorizador léxico
# --------------------------------------------------------------------------
MODELO_DENSO = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"


def carregar_vetorizador():
    """Devolve (funcao_de_embedding, nome, degradado)."""
    try:
        from sentence_transformers import SentenceTransformer
        modelo = SentenceTransformer(MODELO_DENSO)

        def embed(textos):
            return modelo.encode(list(textos), normalize_embeddings=True,
                                 show_progress_bar=False)

        return embed, MODELO_DENSO, False
    except Exception as erro:  # sem pacote, sem rede, sem espaço em disco...
        print(f"  [aviso] modelo denso indisponível ({type(erro).__name__}: {erro})")

    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
    except Exception:
        print("  [erro] nem sentence-transformers nem scikit-learn disponíveis.")
        print("         instale ao menos um: pip install scikit-learn")
        sys.exit(1)

    def embed(textos):
        textos = list(textos)
        vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5))
        m = vec.fit_transform(textos).toarray().astype(np.float32)
        normas = np.linalg.norm(m, axis=1, keepdims=True)
        return m / np.clip(normas, 1e-9, None)

    return embed, "TF-IDF char 3-5 (léxico)", True


def top_k(consulta, chunks, embed, k=3):
    """Vetoriza consulta + chunks juntos e devolve os k melhores por cosseno."""
    vetores = embed([consulta] + list(chunks))
    v_consulta, v_chunks = vetores[0], vetores[1:]
    scores = v_chunks @ v_consulta          # vetores normalizados -> produto = cosseno
    ordem = np.argsort(-scores)[:k]
    return [(int(i), float(scores[i])) for i in ordem]


# --------------------------------------------------------------------------
# Saída
# --------------------------------------------------------------------------
def titulo(txt):
    print("\n" + "=" * 78)
    print(txt)
    print("=" * 78)


def mostrar(texto, largura=74, prefixo="    "):
    for linha in textwrap.wrap(texto, largura):
        print(prefixo + linha)


def cobertura(chunk):
    """Quantos fragmentos obrigatórios da resposta estão dentro deste chunk."""
    presentes = [f for f in FRAGMENTOS_DA_RESPOSTA if f in chunk]
    return len(presentes), presentes


def main():
    titulo("PASSO 1 — o mesmo texto, cortado de três jeitos")
    cortes = {}
    for nome, fn in ESTRATEGIAS.items():
        chunks = fn(CORPUS)
        cortes[nome] = chunks
        print(f"\n  {nome}: {len(chunks)} chunks")
        print("  primeiro chunk:")
        mostrar(chunks[0] + " […]" if len(chunks[0]) > 200 else chunks[0])

    titulo("PASSO 2 — carregando o vetorizador")
    embed, nome_modelo, degradado = carregar_vetorizador()
    if degradado:
        print("\n  *** MODO DEGRADADO ***")
        print("  Sem modelo denso. Usando vetorizador léxico — ele casa CARACTERES,")
        print("  não significado. A consulta desta demo é uma paráfrase de propósito,")
        print("  então espere um resultado ruim. Essa falha é a abertura da Aula 19.")
    print(f"\n  vetorizador: {nome_modelo}")

    titulo("PASSO 3 — a mesma consulta, três rankings")
    print(f'\n  consulta: "{CONSULTA}"')
    print("  (paráfrase: não repete nenhum termo do regulamento — nem 'trancamento',")
    print("   nem 'disciplina', nem 'prazo')")

    for nome, chunks in cortes.items():
        print(f"\n  --- {nome} ---")
        for posicao, (idx, score) in enumerate(top_k(CONSULTA, chunks, embed, k=3), start=1):
            n_frag, _ = cobertura(chunks[idx])
            marca = "resposta COMPLETA" if n_frag == len(FRAGMENTOS_DA_RESPOSTA) else \
                    f"resposta INCOMPLETA ({n_frag}/{len(FRAGMENTOS_DA_RESPOSTA)} fragmentos)"
            print(f"  #{posicao}  cos={score:.3f}  [{marca}]")
            mostrar(chunks[idx][:260] + (" […]" if len(chunks[idx]) > 260 else ""),
                    prefixo="        ")

    titulo("PASSO 4 — o ponto da demo")
    print("""
  O chunk vencedor do corte FIXO pode ter cosseno alto e mesmo assim estar
  cortado no meio da regra: a condição fica num chunk, a exceção fica no
  seguinte, e só um dos dois é recuperado. A recuperação "acertou" — a métrica
  de similaridade está satisfeita — e o gerador recebe meia regra.

  O corte POR ARTIGO devolve a regra inteira mais o identificador canônico,
  que é exatamente o que a citação de fonte vai usar na resposta.

  Nada mudou no modelo. Nada mudou no prompt. Nenhum LLM foi chamado nesta
  tela. Mudou uma função de vinte linhas que decide onde cortar.
""")


if __name__ == "__main__":
    main()
