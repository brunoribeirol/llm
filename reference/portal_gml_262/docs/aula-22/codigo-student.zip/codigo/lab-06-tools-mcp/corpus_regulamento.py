"""corpus_regulamento.py — a base do Lab 5, reduzida, para servir de ferramenta.

Este módulo é importado por três coisas diferentes no Lab 6:
  - o loop de tool calling na mão (Checkpoint 2), como ferramenta `buscar_regulamento`;
  - o servidor MCP próprio (Checkpoint 4), como ferramenta e como recurso;
  - o servidor mínimo do caminho offline (`mcp_minimo.py`).

GANCHO PARA O SEU LAB 5: se existir um `chunks.json` nesta pasta (o arquivo que o
notebook do Lab 5 gravou em `lab05_saida/`), ele é usado no lugar do corpus
embutido — e aí a ferramenta do agente passa a consultar a SUA base. É esse o
caminho que o Lab 7 (Aula 25) vai seguir.

A busca aqui é por termos, de propósito: no Lab 6 o assunto é o protocolo, não a
recuperação. Trocar esta função pelo pipeline híbrido do Lab 5 é o exercício de
extensão — a assinatura não muda.
"""

import json
import pathlib
import re
import unicodedata

# ---------------------------------------------------------------------------
# Corpus embutido — regulamento acadêmico FICTÍCIO (o mesmo das Aulas 18 a 20).
# Texto inventado para a aula. Não é o regulamento de nenhuma instituição real.
# ---------------------------------------------------------------------------
EMBUTIDO = [
    {"dispositivo": "Art. 41", "titulo": "Da matrícula em disciplinas",
     "texto": ("A matrícula em disciplinas é realizada exclusivamente pelo portal do "
               "aluno. O aluno pode matricular-se em no máximo oito disciplinas por "
               "período letivo. Matrícula em disciplina com pré-requisito não cumprido "
               "é indeferida automaticamente pelo sistema.")},
    {"dispositivo": "Art. 42", "titulo": "Do trancamento de disciplina",
     "texto": ("O aluno pode solicitar o trancamento de uma disciplina isolada até o "
               "encerramento do prazo de trinta dias corridos contados a partir do "
               "primeiro dia de aula do período letivo. O trancamento não gera "
               "devolução do valor pago no período.")},
    {"dispositivo": "Art. 42 § 1º", "titulo": "Do trancamento de disciplina",
     "texto": ("Após o prazo previsto no caput, a solicitação só é aceita mediante "
               "justificativa documentada de motivo de saúde ou de força maior, "
               "protocolada em até dez dias úteis do fato gerador.")},
    {"dispositivo": "Art. 51", "titulo": "Da frequência mínima",
     "texto": ("É reprovado por falta o aluno que não alcançar setenta e cinco por "
               "cento de frequência às aulas de cada disciplina, apurada sobre o total "
               "de encontros previstos no plano de ensino.")},
    {"dispositivo": "Art. 52", "titulo": "Da segunda chamada de avaliação",
     "texto": ("O aluno ausente em avaliação pode requerer segunda chamada em até três "
               "dias úteis após a data original, com justificativa documentada. A prova "
               "substitui integralmente a nota da avaliação perdida.")},
    {"dispositivo": "Art. 53", "titulo": "Do coeficiente de rendimento",
     "texto": ("O coeficiente de rendimento é a média das notas finais ponderada pela "
               "carga horária das disciplinas cursadas. Disciplina trancada dentro do "
               "prazo não entra no cálculo.")},
    {"dispositivo": "Art. 60", "titulo": "Da monitoria",
     "texto": ("A monitoria é exercida por aluno regularmente matriculado, aprovado na "
               "disciplina objeto da monitoria com nota igual ou superior a sete. A "
               "carga é de até doze horas semanais e não gera vínculo empregatício.")},
    {"dispositivo": "Edital PRG-2025-014", "titulo": "Aproveitamento de disciplinas",
     "texto": ("O requerimento de aproveitamento deve ser protocolado com ementa e "
               "histórico oficiais da instituição de origem. A análise considera "
               "compatibilidade de ementa igual ou superior a setenta e cinco por cento "
               "da carga horária.")},
]

_AQUI = pathlib.Path(__file__).parent
_LAB5 = _AQUI / "chunks.json"

if _LAB5.exists():
    DISPOSITIVOS = json.loads(_LAB5.read_text(encoding="utf-8"))
    FONTE_DO_CORPUS = f"chunks.json do Lab 5 ({len(DISPOSITIVOS)} chunks)"
else:
    DISPOSITIVOS = EMBUTIDO
    FONTE_DO_CORPUS = f"corpus embutido FICTÍCIO ({len(DISPOSITIVOS)} dispositivos)"


def _normalizar(texto):
    t = unicodedata.normalize("NFKD", str(texto).lower())
    return "".join(c for c in t if not unicodedata.combining(c))


def buscar(termo, k=3):
    """Busca por termos. Devolve [{dispositivo, titulo, texto, score}].

    Esta é a assinatura que o schema da ferramenta declara no Checkpoint 1 e que o
    servidor MCP expõe no Checkpoint 4. Trocar o corpo por retrieval híbrido não
    muda nada para quem chama — é o ponto do Lab 7.
    """
    palavras = [p for p in re.findall(r"\w+", _normalizar(termo)) if len(p) > 2]
    pontuados = []
    for d in DISPOSITIVOS:
        alvo = _normalizar(f"{d['dispositivo']} {d.get('titulo', '')} {d['texto']}")
        score = sum(1 for p in palavras if p in alvo)
        if score:
            pontuados.append((score, d))
    pontuados.sort(key=lambda par: -par[0])
    return [{"dispositivo": d["dispositivo"], "titulo": d.get("titulo", ""),
             "texto": d["texto"], "score": s} for s, d in pontuados[:k]]


def listar_dispositivos():
    """Usado como RECURSO no Checkpoint 4: o índice do acervo, não uma ação."""
    return [{"dispositivo": d["dispositivo"], "titulo": d.get("titulo", "")}
            for d in DISPOSITIVOS]


if __name__ == "__main__":
    print(FONTE_DO_CORPUS)
    for r in buscar("prazo de trancamento", k=3):
        print(f"  {r['score']}  {r['dispositivo']:<22} {r['titulo']}")
