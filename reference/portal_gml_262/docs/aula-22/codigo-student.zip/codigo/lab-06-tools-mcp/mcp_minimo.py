"""mcp_minimo.py — MCP sem SDK: JSON-RPC 2.0 sobre stdio, escrito à mão.

Este arquivo existe por dois motivos.

1. **Caminho offline.** Se a sala não tiver rede para `pip install mcp`, os
   Checkpoints 3 e 4 do Lab 6 rodam aqui: o protocolo é o mesmo (três verbos),
   o transporte é o mesmo (stdio, uma mensagem JSON por linha), e o que falta é
   só o açúcar do SDK.

2. **Desmistificação.** Depois de ler estas ~80 linhas, ninguém mais acha que MCP
   é mágica. Servidor MCP é um processo que lê JSON de uma linha na entrada padrão
   e escreve JSON de uma linha na saída padrão. É isso.

Uso:
    python mcp_minimo.py                 # roda o CLIENTE, que sobe o servidor
    python mcp_minimo.py --servidor      # roda só o SERVIDOR (é o que o cliente invoca)

Os três verbos do diálogo mínimo:
    initialize   -> negocia versão e capacidades
    tools/list   -> descobre o que existe
    tools/call   -> executa

Nenhuma dependência além da biblioteca padrão. Comparar com `servidor_regulamento.py`
(mesma coisa, com o SDK) é o exercício.
"""

import json
import subprocess
import sys

import corpus_regulamento

VERSAO_PROTOCOLO = "2024-11-05"     # revisão do protocolo, versionada por data

# ---------------------------------------------------------------------------
# O catálogo que este servidor expõe. Repare que é o MESMO schema do Checkpoint 1:
# o protocolo não muda o design da ferramenta — ele só muda quem entrega o schema.
# ---------------------------------------------------------------------------
FERRAMENTAS = [{
    "name": "buscar_regulamento",
    "description": ("Busca dispositivos do regulamento acadêmico por palavras-chave e "
                    "devolve os trechos mais relevantes com o identificador de cada um "
                    "(ex.: 'Art. 42'). Use para qualquer pergunta sobre regras, prazos "
                    "ou requisitos acadêmicos."),
    "inputSchema": {
        "type": "object",
        "properties": {
            "termo": {"type": "string",
                      "description": "Palavras-chave da busca, ex.: 'prazo de trancamento'"},
            "k": {"type": "integer", "description": "Quantos trechos devolver (1 a 5)",
                  "minimum": 1, "maximum": 5},
        },
        "required": ["termo"],
    },
}]


# ===========================================================================
# SERVIDOR
# ===========================================================================
def responder(mensagem):
    """Devolve a resposta JSON-RPC para uma mensagem, ou None para notificação."""
    metodo = mensagem.get("method")
    ident = mensagem.get("id")

    if ident is None:                       # notificação: não se responde
        return None

    if metodo == "initialize":
        resultado = {
            "protocolVersion": VERSAO_PROTOCOLO,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "regulamento-minimo", "version": "0.1.0"},
        }
    elif metodo == "tools/list":
        resultado = {"tools": FERRAMENTAS}
    elif metodo == "tools/call":
        params = mensagem.get("params") or {}
        nome = params.get("name")
        argumentos = params.get("arguments") or {}
        if nome != "buscar_regulamento":
            return {"jsonrpc": "2.0", "id": ident,
                    "error": {"code": -32601, "message": f"ferramenta desconhecida: {nome}"}}
        # Validação do lado do SERVIDOR — não se confia no argumento que chegou.
        termo = argumentos.get("termo")
        if not isinstance(termo, str) or not termo.strip():
            return {"jsonrpc": "2.0", "id": ident,
                    "error": {"code": -32602, "message": "'termo' é obrigatório e não vazio"}}
        k = argumentos.get("k", 3)
        k = k if isinstance(k, int) and 1 <= k <= 5 else 3
        achados = corpus_regulamento.buscar(termo, k)
        texto = json.dumps(achados, ensure_ascii=False, indent=1)
        resultado = {"content": [{"type": "text", "text": texto}], "isError": False}
    else:
        return {"jsonrpc": "2.0", "id": ident,
                "error": {"code": -32601, "message": f"método não suportado: {metodo}"}}

    return {"jsonrpc": "2.0", "id": ident, "result": resultado}


def rodar_servidor():
    """Laço do servidor: uma mensagem JSON por linha, na entrada e na saída padrão."""
    for linha in sys.stdin:
        linha = linha.strip()
        if not linha:
            continue
        try:
            mensagem = json.loads(linha)
        except json.JSONDecodeError:
            continue
        resposta = responder(mensagem)
        if resposta is not None:
            sys.stdout.write(json.dumps(resposta, ensure_ascii=False) + "\n")
            sys.stdout.flush()


# ===========================================================================
# CLIENTE
# ===========================================================================
class ClienteMinimo:
    """Sobe o servidor como subprocesso e conversa por stdin/stdout."""

    def __init__(self, comando):
        self.proc = subprocess.Popen(
            comando, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            text=True, encoding="utf-8", bufsize=1)
        self._id = 0

    def pedir(self, metodo, params=None):
        self._id += 1
        pedido = {"jsonrpc": "2.0", "id": self._id, "method": metodo}
        if params is not None:
            pedido["params"] = params
        self.proc.stdin.write(json.dumps(pedido, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()
        linha = self.proc.stdout.readline()
        if not linha:
            raise RuntimeError("o servidor fechou a conexão sem responder")
        return json.loads(linha)

    def notificar(self, metodo, params=None):
        pedido = {"jsonrpc": "2.0", "method": metodo}
        if params is not None:
            pedido["params"] = params
        self.proc.stdin.write(json.dumps(pedido, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()

    def fechar(self):
        self.proc.stdin.close()
        self.proc.terminate()
        self.proc.wait(timeout=5)


def rodar_cliente():
    print("=" * 74)
    print("CLIENTE MÍNIMO — MCP sem SDK, três verbos, stdio")
    print("=" * 74)
    cliente = ClienteMinimo([sys.executable, __file__, "--servidor"])
    try:
        r = cliente.pedir("initialize", {
            "protocolVersion": VERSAO_PROTOCOLO,
            "capabilities": {},
            "clientInfo": {"name": "cliente-minimo", "version": "0.1.0"},
        })
        info = r["result"]["serverInfo"]
        print(f"\n1. initialize   -> servidor '{info['name']}' v{info['version']}, "
              f"protocolo {r['result']['protocolVersion']}")
        cliente.notificar("notifications/initialized")

        r = cliente.pedir("tools/list")
        print(f"\n2. tools/list   -> {len(r['result']['tools'])} ferramenta(s):")
        for t in r["result"]["tools"]:
            obrigatorios = t["inputSchema"].get("required", [])
            print(f"     {t['name']}({', '.join(obrigatorios)})")
            print(f"       {t['description'][:88]}...")

        r = cliente.pedir("tools/call", {"name": "buscar_regulamento",
                                         "arguments": {"termo": "prazo de trancamento",
                                                       "k": 2}})
        print("\n3. tools/call   -> resultado:")
        for bloco in r["result"]["content"]:
            for achado in json.loads(bloco["text"]):
                print(f"     {achado['dispositivo']:<22} {achado['titulo']}")

        r = cliente.pedir("tools/call", {"name": "buscar_regulamento",
                                         "arguments": {"k": 2}})
        print("\n4. tools/call sem 'termo' -> o SERVIDOR recusa:")
        print(f"     erro {r['error']['code']}: {r['error']['message']}")

        print("\n" + "=" * 74)
        print("Oitenta linhas. É isto que o SDK embala: JSON-RPC sobre stdio.")
        print("O servidor nunca viu um modelo de linguagem — ele respondeu a um cliente.")
    finally:
        cliente.fechar()


if __name__ == "__main__":
    if "--servidor" in sys.argv:
        rodar_servidor()
    else:
        rodar_cliente()
