"""
Aula 15 — Alinhamento: RLHF, PPO e DPO
Demo do instrutor (10 min, fim do Bloco 1): um mini reward model de Bradley-Terry
treinado sobre pares de preferência sintéticos.

O ponto da demo é um só: o reward model não aprende qualidade, aprende SEPARAÇÃO.
Ele nunca vê a função de qualidade verdadeira — vê apenas comparações pareadas.
E a acurácia pareada dele em held-out satura no teto do ANOTADOR, não do modelo.

Roda em CPU, em segundos, no Colab free tier:
    python demo-bradley-terry.py

Dependências: torch, matplotlib (ambos já presentes no Colab).
Sem chave de API, sem download de modelo, sem dataset externo.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

# --------------------------------------------------------------------------
# Configuração
# --------------------------------------------------------------------------
D = 8               # número de atributos de uma "resposta"
N_PAIRS = 4000      # pares de preferência de treino
N_HELDOUT = 1000    # pares de preferência de validação
STEPS = 600         # passos de gradiente (full batch — o dataset é minúsculo)
LR = 0.02
LOG_EVERY = 100
NOISE_LEVELS = (0.0, 0.10, 0.25)   # fração de rótulos invertidos (desacordo entre anotadores)
SEED = 7
PNG_NAME = "separacao-bradley-terry.png"


# --------------------------------------------------------------------------
# Gerador sintético de dados de preferência
# --------------------------------------------------------------------------
def make_pairs(n_pairs, w_true, p_flip, generator):
    """Sorteia n_pairs comparações pareadas.

    Cada "resposta" é um vetor de D atributos. A qualidade verdadeira é a
    projeção linear `x @ w_true` — uma função OCULTA: quem anota não a vê,
    só compara dois vetores. Vence quem tem qualidade verdadeira maior.

    `p_flip` inverte o rótulo de uma fração dos pares: é o anotador discordando.
    Devolve o par como o anotador registrou (x_w, x_l) e também o par na ordem
    verdadeira (t_w, t_l), para dar para separar "erro do modelo" de "erro do rótulo".
    """
    a = torch.randn(n_pairs, D, generator=generator)
    b = torch.randn(n_pairs, D, generator=generator)

    a_wins = (a @ w_true) > (b @ w_true)
    mask = a_wins.unsqueeze(1)
    true_w = torch.where(mask, a, b)
    true_l = torch.where(mask, b, a)

    flip = torch.rand(n_pairs, generator=generator) < p_flip
    fmask = flip.unsqueeze(1)
    annot_w = torch.where(fmask, true_l, true_w)
    annot_l = torch.where(fmask, true_w, true_l)

    return annot_w, annot_l, true_w, true_l


# --------------------------------------------------------------------------
# Treino do reward model
# --------------------------------------------------------------------------
def train_reward_model(p_flip, verbose=True):
    """Treina r_phi por máxima verossimilhança de Bradley-Terry.

    O RM é uma cabeça escalar — aqui, um nn.Linear(D, 1). Num LLM de verdade
    é o modelo SFT com a cabeça de linguagem trocada por esta.
    """
    generator = torch.Generator().manual_seed(SEED)

    w_true = torch.randn(D, generator=generator)
    w_true = w_true / w_true.norm()

    train_w, train_l, _, _ = make_pairs(N_PAIRS, w_true, p_flip, generator)
    # O held-out é anotado pelos MESMOS anotadores: carrega o mesmo desacordo.
    # É essa a métrica de sanidade que se acompanha na prática.
    held_w, held_l, held_true_w, held_true_l = make_pairs(
        N_HELDOUT, w_true, p_flip, generator
    )

    reward_model = nn.Linear(D, 1, bias=False)
    optimizer = torch.optim.Adam(reward_model.parameters(), lr=LR)

    history = []
    scores_before = None

    for step in range(STEPS + 1):
        r_w = reward_model(train_w).squeeze(1)
        r_l = reward_model(train_l).squeeze(1)

        # A perda de Bradley-Terry, literalmente a fórmula do slide 5:
        #     L = -E[ log sigma( r(x, y_w) - r(x, y_l) ) ]
        loss = -F.logsigmoid(r_w - r_l).mean()

        with torch.no_grad():
            hr_w = reward_model(held_w).squeeze(1)
            hr_l = reward_model(held_l).squeeze(1)
            # acurácia contra o rótulo do anotador — é o que se mede na prática
            acc_annot = (hr_w > hr_l).float().mean().item()
            # acurácia contra a ordem verdadeira — só existe porque a demo é sintética
            acc_true = (
                reward_model(held_true_w).squeeze(1)
                > reward_model(held_true_l).squeeze(1)
            ).float().mean().item()
            separation = (hr_w - hr_l).mean().item()

            if step == 0:
                scores_before = (hr_w.clone(), hr_l.clone())

        if step % LOG_EVERY == 0:
            history.append(
                {
                    "step": step,
                    "loss": loss.item(),
                    "acc_annot": acc_annot,
                    "acc_true": acc_true,
                    "separation": separation,
                }
            )
            if verbose:
                print(
                    f"  passo {step:4d} | perda {loss.item():.4f} "
                    f"| acc(anotador) {acc_annot:.3f} "
                    f"| acc(verdade) {acc_true:.3f} "
                    f"| separação {separation:+.3f}"
                )

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    with torch.no_grad():
        scores_after = (
            reward_model(held_w).squeeze(1).clone(),
            reward_model(held_l).squeeze(1).clone(),
        )

    return history, scores_before, scores_after


# --------------------------------------------------------------------------
# Execução: os três níveis de ruído
# --------------------------------------------------------------------------
def main():
    torch.manual_seed(SEED)
    results = {}

    for p_flip in NOISE_LEVELS:
        ceiling = 1.0 - p_flip
        print(f"\n=== rótulos invertidos: {p_flip:.0%}   "
              f"(teto do anotador = {ceiling:.2f}) ===")
        history, before, after = train_reward_model(p_flip)
        results[p_flip] = {"history": history, "before": before, "after": after}

    # Tabela-resumo em texto puro: a demo continua funcionando sem gráfico.
    print("\n" + "=" * 72)
    print("RESUMO — estado final do reward model por nível de desacordo")
    print("=" * 72)
    print(f"{'ruído':>7} | {'teto':>5} | {'acc(anotador)':>13} "
          f"| {'acc(verdade)':>12} | {'separação':>9}")
    print("-" * 72)
    for p_flip in NOISE_LEVELS:
        last = results[p_flip]["history"][-1]
        print(f"{p_flip:>6.0%} | {1.0 - p_flip:>5.2f} "
              f"| {last['acc_annot']:>13.3f} | {last['acc_true']:>12.3f} "
              f"| {last['separation']:>+9.3f}")
    print("-" * 72)
    print("Leitura: a acurácia medida encosta no teto do anotador (1 - ruído) e para.")
    print("A coluna acc(verdade) mostra que a ordem verdadeira segue recuperada —")
    print("o teto é do rótulo, não do modelo. E a separação não tem unidade:")
    print("só a DIFERENÇA de recompensa é identificável (Bradley-Terry = Elo).")

    plot_panel(results)


# --------------------------------------------------------------------------
# Painel de gráficos
# --------------------------------------------------------------------------
def plot_panel(results):
    try:
        import matplotlib
        matplotlib.use("Agg")   # salva o PNG mesmo sem display (Colab, servidor)
        import matplotlib.pyplot as plt
    except Exception as exc:     # noqa: BLE001 — a demo não pode morrer por causa do gráfico
        print(f"\n[gráfico indisponível: {exc}]")
        print("A tabela-resumo acima é suficiente para conduzir a demo.")
        return

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))

    clean = results[0.0]
    bins = 40

    # (a) antes do treino: as duas distribuições de score se sobrepõem
    b_w, b_l = clean["before"]
    axes[0].hist(b_w.numpy(), bins=bins, alpha=0.6, label="preferidas (y_w)")
    axes[0].hist(b_l.numpy(), bins=bins, alpha=0.6, label="rejeitadas (y_l)")
    axes[0].set_title("Antes do treino: scores sobrepostos")
    axes[0].set_xlabel("score do RM (unidade arbitrária)")
    axes[0].set_ylabel("nº de respostas")
    axes[0].legend()

    # (b) depois do treino: as distribuições se afastam
    a_w, a_l = clean["after"]
    axes[1].hist(a_w.numpy(), bins=bins, alpha=0.6, label="preferidas (y_w)")
    axes[1].hist(a_l.numpy(), bins=bins, alpha=0.6, label="rejeitadas (y_l)")
    axes[1].set_title("Depois do treino: separação aberta")
    axes[1].set_xlabel("score do RM (unidade arbitrária)")
    axes[1].set_ylabel("nº de respostas")
    axes[1].legend()

    # (c) acurácia pareada por passo, com o teto do anotador tracejado
    for p_flip in NOISE_LEVELS:
        history = results[p_flip]["history"]
        steps = [h["step"] for h in history]
        accs = [h["acc_annot"] for h in history]
        line, = axes[2].plot(steps, accs, marker="o", markersize=3,
                             label=f"{p_flip:.0%} de rótulos invertidos")
        axes[2].axhline(1.0 - p_flip, linestyle="--", linewidth=1,
                        color=line.get_color(), alpha=0.7)
    axes[2].set_title("Acurácia pareada satura no teto do anotador")
    axes[2].set_xlabel("passo de treino")
    axes[2].set_ylabel("acurácia pareada em held-out")
    axes[2].set_ylim(0.0, 1.05)
    axes[2].legend(fontsize=8)

    fig.tight_layout()

    try:
        from pathlib import Path
        out = Path(__file__).with_name(PNG_NAME)
        fig.savefig(out, dpi=130)
        print(f"\n[gráfico salvo em {out}]")
    except Exception as exc:     # noqa: BLE001
        print(f"\n[não foi possível salvar o PNG: {exc}]")

    try:
        plt.show()
    except Exception:           # noqa: BLE001 — ambiente sem display
        pass


if __name__ == "__main__":
    main()
