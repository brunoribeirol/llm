"""demo-orquestrador-vs-agente.py — Aula 24 · demonstração do instrutor (8 min, offline).

A MESMA tarefa resolvida em duas arquiteturas, com três números medidos para cada:

    chamadas ao modelo · tokens enviados no total · passos até a resposta

    python demo-orquestrador-vs-agente.py --unico          # 1 agente, 3 ferramentas
    python demo-orquestrador-vs-agente.py --multi          # orquestrador + 3 trabalhadores
    python demo-orquestrador-vs-agente.py --multi-vazado   # o mesmo, repassando tudo
    python demo-orquestrador-vs-agente.py --comparar       # tabela lado a lado

As três arquiteturas chegam à MESMA resposta final, de propósito: o que muda é o
preço. Sem rede, sem dependência, sem chave: o "modelo" é um simulador ROTEIRADO
determinístico com semente fixa (`SEMENTE = 24`) — ele não mede modelo nenhum.

O que esta demo NÃO mostra: um caso em que multiagente ganha. Esse caso existe (o
deep research do Conceito 12 do plano) e não cabe em oito minutos sem rede. O que
ela mostra é que a arquitetura tem preço, e que o preço é mensurável antes de
escrever o sistema.
"""

import argparse
import json
import random
import re
import sys

SEMENTE = 24
random.seed(SEMENTE)

PERGUNTA = ("Já passaram 10 dias desde o primeiro dia de aula. Ainda dá tempo de "
            "trancar a disciplina, e quantos dias eu tenho?")

RESPOSTA_ESPERADA = ("Sim — o Art. 42 fixa 30 dias corridos desde o primeiro dia de "
                     "aula; como já passaram 10, restam 20 dias.")

# ---------------------------------------------------------------------------
# Corpus FICTÍCIO — o mesmo regulamento inventado das Aulas 18 a 23.
# ---------------------------------------------------------------------------
DISPOSITIVOS = [
    {"dispositivo": "Art. 42", "titulo": "Do trancamento de disciplina",
     "texto": ("O aluno pode solicitar o trancamento de uma disciplina isolada até o "
               "encerramento do prazo de trinta dias corridos contados a partir do "
               "primeiro dia de aula do período letivo.")},
    {"dispositivo": "Art. 51", "titulo": "Da frequência mínima",
     "texto": ("É reprovado por falta o aluno que não alcançar setenta e cinco por "
               "cento de frequência às aulas de cada disciplina.")},
    {"dispositivo": "Art. 53", "titulo": "Do coeficiente de rendimento",
     "texto": ("Disciplina trancada dentro do prazo não entra no cálculo do "
               "coeficiente de rendimento.")},
]


def buscar_regulamento(termo, k=2):
    """FUNÇÃO DETERMINÍSTICA — nos diagramas, caixa de borda tracejada."""
    palavras = [p for p in re.findall(r"\w+", termo.lower()) if len(p) > 3]
    achados = []
    for d in DISPOSITIVOS:
        alvo = f"{d['dispositivo']} {d['titulo']} {d['texto']}".lower()
        score = sum(1 for p in palavras if p in alvo)
        if score:
            achados.append((score, d))
    achados.sort(key=lambda par: -par[0])
    return [{"dispositivo": d["dispositivo"], "texto": d["texto"]}
            for _, d in achados[:k]]


PERMITIDO = re.compile(r"^[0-9\s\.\+\-\*/\(\)]+$")


def calcular(expressao):
    """FUNÇÃO DETERMINÍSTICA — o segundo trabalhador que não precisa ser agente."""
    if not PERMITIDO.match(expressao or ""):
        return {"erro": "expressão inválida"}
    return {"resultado": eval(expressao, {"__builtins__": {}}, {})}  # noqa: S307


# ---------------------------------------------------------------------------
# O medidor. É ele que dá os três números da aula.
# ---------------------------------------------------------------------------
class Medidor:
    def __init__(self, rotulo):
        self.rotulo = rotulo
        self.chamadas = 0
        self.tokens_enviados = 0
        self.passos = 0

    def registrar(self, prompt_enviado):
        self.chamadas += 1
        self.tokens_enviados += len(prompt_enviado) // 4  # ~4 caracteres por token

    def linha(self):
        return (f"{self.rotulo:<28} {self.chamadas:>9} {self.tokens_enviados:>10} "
                f"{self.passos:>7}")


# ---------------------------------------------------------------------------
# O "modelo": simulador ROTEIRADO. Recebe um papel e o texto do prompt; devolve
# a fala daquele papel. Determinístico — a sala vê sempre a mesma saída.
# ---------------------------------------------------------------------------
def chamar_modelo(papel, prompt, medidor):
    medidor.registrar(prompt)

    if papel == "agente-unico":
        if "trinta dias" not in prompt:
            return ('Thought: preciso do dispositivo que fixa o prazo.\n'
                    'Action: buscar_regulamento\n'
                    'Action Input: {"termo": "prazo de trancamento de disciplina"}')
        if '"resultado"' not in prompt:
            return ('Thought: o prazo é 30 e já passaram 10; falta a subtração.\n'
                    'Action: calcular\n'
                    'Action Input: {"expressao": "30 - 10"}')
        return f"Final Answer: {RESPOSTA_ESPERADA}"

    if papel == "orquestrador-plano":
        return ("Plano:\n"
                "1. buscador: achar o dispositivo do prazo de trancamento\n"
                "2. calculista: subtrair os dias já corridos do prazo\n"
                "3. redator: redigir a resposta citando o dispositivo")

    if papel == "orquestrador-delegacao-1":
        return 'Delegar para buscador: {"termo": "prazo de trancamento de disciplina"}'

    if papel == "orquestrador-delegacao-2":
        return 'Delegar para calculista: {"expressao": "30 - 10"}'

    if papel == "redator":
        return RESPOSTA_ESPERADA

    if papel == "orquestrador-sintese":
        return f"Final Answer: {RESPOSTA_ESPERADA}"

    raise ValueError(f"papel desconhecido: {papel}")


SISTEMA_UNICO = (
    "Você é um assistente que responde perguntas sobre o regulamento acadêmico "
    "citando o dispositivo. Ferramentas: buscar_regulamento(termo, k), "
    "calcular(expressao). Responda com Thought/Action/Action Input, ou com "
    "Final Answer quando tiver observação que sustente a resposta."
)

SISTEMA_ORQUESTRADOR = (
    "Você é o orquestrador. Decomponha o objetivo, delegue a um trabalhador por "
    "vez (buscador, calculista, redator), receba o resultado e sintetize. "
    "Trabalhadores não conversam entre si."
)

SISTEMA_REDATOR = (
    "Você é o redator. Recebe fatos já apurados e escreve a resposta final ao "
    "aluno, citando o dispositivo que sustenta cada afirmação."
)


# ---------------------------------------------------------------------------
# ARQUITETURA A — um agente, três ferramentas. É o loop da Aula 23.
# ---------------------------------------------------------------------------
def arquitetura_unico(verboso=True):
    medidor = Medidor("um agente + ferramentas")
    trajetoria = [SISTEMA_UNICO, f"Pergunta: {PERGUNTA}"]

    while medidor.passos < 5:
        medidor.passos += 1
        texto = chamar_modelo("agente-unico", "\n".join(trajetoria), medidor)
        trajetoria.append(texto)
        if verboso:
            print(f"  passo {medidor.passos} · {texto.splitlines()[0]}")

        if "Final Answer:" in texto:
            resposta = texto.split("Final Answer:", 1)[1].strip()
            return resposta, medidor

        acao = re.search(r"Action:\s*(\S+)", texto).group(1)
        argumentos = json.loads(re.search(r"Action Input:\s*(\{.*\})", texto).group(1))
        if acao == "buscar_regulamento":
            observacao = buscar_regulamento(**argumentos)
        else:
            observacao = calcular(**argumentos)
        bruto = json.dumps(observacao, ensure_ascii=False)
        trajetoria.append(f"Observation: {bruto}")
        if verboso:
            print(f"           observação: {bruto[:80]}…")

    return "orçamento esgotado", medidor


# ---------------------------------------------------------------------------
# ARQUITETURA B — orquestrador + três trabalhadores.
# `vazado=True` reproduz o erro do Conceito 2: repassar a trajetória inteira.
# ---------------------------------------------------------------------------
def arquitetura_multi(vazado=False, verboso=True):
    rotulo = "orquestrador (vazado)" if vazado else "orquestrador + trabalhadores"
    medidor = Medidor(rotulo)
    trajetoria = [SISTEMA_ORQUESTRADOR, f"Objetivo: {PERGUNTA}"]

    def contexto_para_trabalhador(instrucao):
        # Esta é A LINHA em que o custo extra nasce. Com `vazado`, o trabalhador
        # recebe o histórico completo do orquestrador — a menor entrada suficiente
        # deixa de ser respeitada e cada trabalhador passa a pagar pelo sistema.
        if vazado:
            return "\n".join(trajetoria) + "\n" + instrucao
        return instrucao

    medidor.passos += 1
    plano = chamar_modelo("orquestrador-plano", "\n".join(trajetoria), medidor)
    trajetoria.append(plano)
    if verboso:
        print("  orquestrador planeja:")
        for linha in plano.splitlines()[1:]:
            print(f"     {linha}")

    medidor.passos += 1
    delegacao = chamar_modelo("orquestrador-delegacao-1", "\n".join(trajetoria), medidor)
    trajetoria.append(delegacao)
    argumentos = json.loads(delegacao.split(":", 1)[1].strip())
    dispositivos = buscar_regulamento(**argumentos)   # trabalhador determinístico
    trajetoria.append(f"Resultado do buscador: {json.dumps(dispositivos, ensure_ascii=False)}")
    if verboso:
        print(f"  delega ao buscador -> {dispositivos[0]['dispositivo']}")

    medidor.passos += 1
    delegacao = chamar_modelo("orquestrador-delegacao-2", "\n".join(trajetoria), medidor)
    trajetoria.append(delegacao)
    argumentos = json.loads(delegacao.split(":", 1)[1].strip())
    conta = calcular(**argumentos)                    # trabalhador determinístico
    trajetoria.append(f"Resultado do calculista: {json.dumps(conta, ensure_ascii=False)}")
    if verboso:
        print(f"  delega ao calculista -> {conta}")

    medidor.passos += 1
    instrucao_redator = (SISTEMA_REDATOR + "\nFatos: "
                         + json.dumps({"dispositivos": dispositivos, "conta": conta},
                                      ensure_ascii=False))
    texto = chamar_modelo("redator", contexto_para_trabalhador(instrucao_redator), medidor)
    trajetoria.append(f"Resultado do redator: {texto}")
    if verboso:
        print("  delega ao redator -> texto com citação")

    # A síntese final é uma chamada de modelo que a arquitetura de um agente não tem.
    medidor.passos += 1
    final = chamar_modelo("orquestrador-sintese", "\n".join(trajetoria), medidor)
    if verboso:
        print("  orquestrador sintetiza -> resposta final")
    return final.split("Final Answer:", 1)[1].strip(), medidor


def cabecalho(titulo):
    print("=" * 78)
    print(titulo)
    print("=" * 78)


def tabela(medidores):
    print(f"{'arquitetura':<28} {'chamadas':>9} {'tokens':>10} {'passos':>7}")
    print("-" * 58)
    for m in medidores:
        print(m.linha())
    print("-" * 58)
    base = medidores[0].tokens_enviados or 1
    for m in medidores[1:]:
        print(f"  {m.rotulo}: {m.tokens_enviados / base:.2f}× os tokens de "
              f"'{medidores[0].rotulo}'")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--unico", action="store_true", help="1 agente, 3 ferramentas")
    parser.add_argument("--multi", action="store_true", help="orquestrador + trabalhadores")
    parser.add_argument("--multi-vazado", action="store_true",
                        help="orquestrador repassando a trajetória inteira")
    parser.add_argument("--comparar", action="store_true", help="as três, lado a lado")
    args = parser.parse_args()

    if not any([args.unico, args.multi, args.multi_vazado, args.comparar]):
        args.comparar = True
        print("Nenhum modo pedido — rodando --comparar.\n")

    print(f"Python {sys.version.split()[0]} · semente fixa {SEMENTE} · "
          "sem rede, sem dependências")
    print(f"Pergunta: {PERGUNTA}\n")

    resultados = []

    if args.unico or args.comparar:
        cabecalho("ARQUITETURA A — um agente, três ferramentas")
        resposta, medidor = arquitetura_unico()
        print(f"  RESPOSTA: {resposta}\n")
        resultados.append(medidor)

    if args.multi or args.comparar:
        cabecalho("ARQUITETURA B — orquestrador + três trabalhadores")
        resposta, medidor = arquitetura_multi(vazado=False)
        print(f"  RESPOSTA: {resposta}\n")
        resultados.append(medidor)

    if args.multi_vazado or args.comparar:
        cabecalho("ARQUITETURA B' — o mesmo, repassando a trajetória inteira")
        resposta, medidor = arquitetura_multi(vazado=True)
        print(f"  RESPOSTA: {resposta}\n")
        resultados.append(medidor)

    if len(resultados) > 1:
        cabecalho("COMPARAÇÃO — mesma resposta, preços diferentes")
        tabela(resultados)
        print("\nO custo extra nasce em duas linhas: `contexto_para_trabalhador` "
              "(o que o orquestrador repassa)\ne a síntese final (uma chamada de "
              "modelo que a arquitetura de um agente não tem).")
