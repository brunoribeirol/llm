"""
Demonstração da Aula 10 — "O mesmo modelo, seis comportamentos".

Grandes Modelos de Linguagem: do Transformer aos Agentes de IA · CESAR
Aula 10 de 30 · Módulo 2 · demonstração guiada de 7 minutos.

Python puro: nenhuma dependência externa, nenhuma rede, nenhuma GPU.
A decisão é deliberada — a matemática de decodificação não precisa de um modelo
de verdade para ser vista, precisa de uma distribuição e de um terminal. O modelo
de verdade entra amanhã, no Lab 3 (Aula 11).

    python demo-decodificacao.py

Para salvar a saída como plano B de projeção:

    python demo-decodificacao.py > saida-demo.txt

As quatro constantes de configuração logo abaixo são as quatro alavancas da aula.
"""

import math
import random
import sys

# O terminal do Windows costuma vir em cp1252 e não consegue imprimir as barras
# de bloco das distribuições — o script morre com UnicodeEncodeError no meio da
# demonstração. Reconfigurar a saída para UTF-8 resolve antes de imprimir nada.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------------------
# Configuração — as alavancas da aula. Mexer aqui é o desafio pós-aula.
# ---------------------------------------------------------------------------
TEMPERATURAS = [0.2, 0.7, 1.0, 1.5]
TOP_K = 3
TOP_P = 0.9
SEMENTE = 1337

LARGURA_BARRA = 34


# ---------------------------------------------------------------------------
# As duas distribuições de próximo token.
#
# DIST_A é concentrada: dois candidatos dominam e existe uma cauda longa.
# DIST_B é achatada: nenhum candidato domina.
# É o contraste entre as duas que justifica top-p contra top-k.
# ---------------------------------------------------------------------------
PROMPT_A = "O laboratório de amanhã vai ser sobre"

DIST_A = [
    ("decodificação", 0.32),
    ("prompting", 0.24),
    ("a", 0.15),
    ("o", 0.09),
    ("como", 0.07),
    ("modelos", 0.05),
    ("temperatura", 0.03),
    ("amostragem", 0.02),
    ("técnicas", 0.02),
    ("isso", 0.01),
]

PROMPT_B = "Escreva uma frase sobre"

DIST_B = [
    ("um", 0.14),
    ("o", 0.13),
    ("a", 0.12),
    ("como", 0.11),
    ("qualquer", 0.10),
    ("este", 0.10),
    ("nosso", 0.09),
    ("aquele", 0.08),
    ("meu", 0.07),
    ("seu", 0.06),
]


# ---------------------------------------------------------------------------
# Árvore de probabilidades para a parte de busca.
#
# Pergunta implícita: "vale a pena usar Mixture of Experts?"
# A chave é o prefixo já gerado; o valor são as continuações possíveis.
# O token "." encerra a sequência.
# ---------------------------------------------------------------------------
ARVORE = {
    (): [("O", 0.36), ("Depende", 0.34), ("Sim", 0.18), ("Vale", 0.12)],

    ("O",): [("modelo", 0.55), ("custo", 0.45)],
    ("O", "modelo"): [("depende", 1.0)],
    ("O", "modelo", "depende"): [(".", 1.0)],
    ("O", "custo"): [("cresce", 1.0)],
    ("O", "custo", "cresce"): [(".", 0.70), ("com", 0.30)],
    ("O", "custo", "cresce", "com"): [("o", 1.0)],
    ("O", "custo", "cresce", "com", "o"): [("contexto", 1.0)],
    ("O", "custo", "cresce", "com", "o", "contexto"): [(".", 1.0)],

    ("Depende",): [(".", 0.80), ("do", 0.20)],
    ("Depende", "do"): [("caso", 1.0)],
    ("Depende", "do", "caso"): [(".", 1.0)],

    ("Sim",): [(".", 0.70), (",", 0.30)],
    ("Sim", ","): [("com", 1.0)],
    ("Sim", ",", "com"): [("ressalvas", 1.0)],
    ("Sim", ",", "com", "ressalvas"): [(".", 1.0)],

    ("Vale",): [("a", 1.0)],
    ("Vale", "a"): [("pena", 1.0)],
    ("Vale", "a", "pena"): [("quando", 1.0)],
    ("Vale", "a", "pena", "quando"): [("a", 1.0)],
    ("Vale", "a", "pena", "quando", "a"): [("memória", 1.0)],
    ("Vale", "a", "pena", "quando", "a", "memória"): [("sobra", 1.0)],
    ("Vale", "a", "pena", "quando", "a", "memória", "sobra"): [(".", 1.0)],
}

FIM = "."


# ---------------------------------------------------------------------------
# Utilidades de apresentação
# ---------------------------------------------------------------------------
def titulo(n, texto):
    print()
    print("=" * 74)
    print(f" BLOCO {n} — {texto}")
    print("=" * 74)


def barra(p, largura=LARGURA_BARRA):
    cheios = int(round(p * largura))
    return "█" * cheios + "·" * (largura - cheios)


def imprime_distribuicao(dist, rotulo=None, acumulada=False):
    if rotulo:
        print(f"\n{rotulo}")
    acum = 0.0
    for token, p in dist:
        acum += p
        sufixo = f"   acum {acum:.2f}" if acumulada else ""
        print(f"  {token:>14s}  {p:6.3f}  {barra(p)}{sufixo}")


# ---------------------------------------------------------------------------
# As alavancas, implementadas na mão
# ---------------------------------------------------------------------------
def aplicar_temperatura(dist, T):
    """p_i = softmax(z_i / T), com z_i = log(p_i).

    A divisão acontece NOS LOGITS, antes do softmax. Dividir a probabilidade
    depois do softmax é outra operação e dá outro resultado.
    """
    if T <= 0:
        # T -> 0 é o limite guloso: toda a massa no argmax.
        maior = max(p for _, p in dist)
        return [(t, 1.0 if p == maior else 0.0) for t, p in dist]

    logits = [(t, math.log(p) / T) for t, p in dist]
    teto = max(z for _, z in logits)          # estabilidade numérica
    exps = [(t, math.exp(z - teto)) for t, z in logits]
    soma = sum(e for _, e in exps)
    return [(t, e / soma) for t, e in exps]


def top_k(dist, k):
    """Mantém os k mais prováveis e renormaliza."""
    mantidos = sorted(dist, key=lambda x: -x[1])[:k]
    soma = sum(p for _, p in mantidos)
    return [(t, p / soma) for t, p in mantidos]


def top_p(dist, p_alvo):
    """Menor conjunto cuja probabilidade acumulada ATINGE p_alvo, renormalizado.

    O token que cruza a linha entra no conjunto — é ele que faz a acumulada
    atingir p_alvo.
    """
    ordenada = sorted(dist, key=lambda x: -x[1])
    mantidos, acum = [], 0.0
    for token, p in ordenada:
        mantidos.append((token, p))
        acum += p
        if acum >= p_alvo:
            break
    soma = sum(p for _, p in mantidos)
    return [(t, p / soma) for t, p in mantidos]


def amostrar(dist, rng):
    """Sorteia um token pela distribuição (amostragem multinomial de 1 item)."""
    r = rng.random()
    acum = 0.0
    for token, p in dist:
        acum += p
        if r < acum:
            return token
    return dist[-1][0]


def greedy(dist):
    return max(dist, key=lambda x: x[1])[0]


# ---------------------------------------------------------------------------
# Busca sobre a árvore
# ---------------------------------------------------------------------------
def todas_as_sequencias(arvore, prefixo=()):
    """Enumera todas as sequências completas e suas probabilidades conjuntas."""
    if prefixo and prefixo[-1] == FIM:
        return [(prefixo, 1.0)]
    saidas = []
    for token, p in arvore.get(prefixo, []):
        for seq, resto in todas_as_sequencias(arvore, prefixo + (token,)):
            saidas.append((seq, p * resto))
    return saidas


def busca_gulosa(arvore):
    prefixo = ()
    prob = 1.0
    while True:
        continuacoes = arvore.get(prefixo)
        if not continuacoes:
            return prefixo, prob
        token, p = max(continuacoes, key=lambda x: x[1])
        prefixo, prob = prefixo + (token,), prob * p
        if token == FIM:
            return prefixo, prob


def busca_em_feixe(arvore, largura):
    """Beam search clássico: mantém `largura` hipóteses vivas, poda por
    probabilidade acumulada, e coleta as que terminaram."""
    feixe = [((), 1.0)]
    completas = []
    while feixe:
        candidatos = []
        for prefixo, prob in feixe:
            for token, p in arvore.get(prefixo, []):
                novo = (prefixo + (token,), prob * p)
                (completas if token == FIM else candidatos).append(novo)
        feixe = sorted(candidatos, key=lambda x: -x[1])[:largura]
    return sorted(completas, key=lambda x: -x[1])


def frase(seq):
    return " ".join(seq[:-1]) + "."


# ---------------------------------------------------------------------------
# Os seis blocos da demonstração
# ---------------------------------------------------------------------------
def bloco_1_distribuicao_crua():
    titulo(1, "A distribuição crua de próximo token")
    print(f'\nPrompt: "{PROMPT_A} ___"')
    imprime_distribuicao(DIST_A, acumulada=True)
    print("\n  Formato típico: dois ou três candidatos dominam e existe uma cauda")
    print("  longa de coisas improváveis mas não impossíveis. Esse formato é a")
    print("  razão de existir de tudo o que vem a seguir.")


def bloco_2_temperatura():
    titulo(2, f"Temperatura — T ∈ {TEMPERATURAS}")
    for T in TEMPERATURAS:
        d = aplicar_temperatura(DIST_A, T)
        imprime_distribuicao(d, rotulo=f"T = {T}")
    print("\n  A ORDEM dos candidatos é idêntica nas quatro. Temperatura não muda")
    print("  quem é o mais provável — muda o quanto ele é mais provável.")


def bloco_3_top_k():
    titulo(3, f"Top-k — k = {TOP_K}")
    cortada = top_k(DIST_A, TOP_K)
    imprime_distribuicao(cortada, rotulo=f"sobreviventes de top-k={TOP_K}, renormalizados")
    original = dict(DIST_A)
    print("\n  antes → depois da renormalização:")
    for token, p in cortada:
        print(f"    {token:>14s}  {original[token]:.3f} → {p:.3f}")
    print("\n  Truncar não é só cortar: é redistribuir. O terceiro colocado tinha")
    print("  uma fatia pequena e ficou com uma fatia respeitável.")


def bloco_4_top_p():
    titulo(4, f"Top-p (nucleus) — p = {TOP_P}")

    a = top_p(DIST_A, TOP_P)
    print(f'\nDistribuição CONCENTRADA — "{PROMPT_A} ___"')
    print(f"  nucleus com {len(a)} de {len(DIST_A)} tokens")
    imprime_distribuicao(a)

    b = top_p(DIST_B, TOP_P)
    print(f'\nDistribuição ACHATADA — "{PROMPT_B} ___"')
    print(f"  nucleus com {len(b)} de {len(DIST_B)} tokens")
    imprime_distribuicao(b)

    print("\n  Mesma linha de código, mesmo parâmetro, conjuntos de tamanhos")
    print(f"  diferentes ({len(a)} × {len(b)}). Um k fixo não faria isso: cortaria")
    print("  material bom no segundo caso ou admitiria lixo no primeiro.")

    print("\n  E o efeito da temperatura sobre o tamanho do nucleus (dist. A):")
    for T in TEMPERATURAS:
        n = len(top_p(aplicar_temperatura(DIST_A, T), TOP_P))
        print(f"    T = {T:<4}  →  nucleus de {n} token(s)")
    print("\n  Temperatura alta achata a distribuição, e distribuição achatada")
    print("  precisa de mais tokens para acumular a mesma massa. O nucleus CRESCE.")
    print("  Temperatura e top-p não são controles independentes.")


def bloco_5_busca():
    titulo(5, "Busca: gulosa × feixe × feixe normalizado por comprimento")
    print('\nPergunta implícita: "vale a pena usar Mixture of Experts?"')

    seqs = todas_as_sequencias(ARVORE)
    print(f"\n  A árvore tem {len(seqs)} sequências completas. Todas elas:")
    print(f"\n  {'sequência':<44s} {'P conjunta':>10s} {'len':>4s} {'P^(1/len)':>10s}")
    for seq, p in sorted(seqs, key=lambda x: -x[1]):
        print(f"  {frase(seq):<44s} {p:>10.4f} {len(seq):>4d} {p ** (1 / len(seq)):>10.4f}")

    g_seq, g_p = busca_gulosa(ARVORE)
    print(f"\n  GULOSA           → {frase(g_seq):<44s} P = {g_p:.4f}")

    feixe = busca_em_feixe(ARVORE, largura=3)
    b_seq, b_p = feixe[0]
    print(f"  FEIXE (B=3)      → {frase(b_seq):<44s} P = {b_p:.4f}")

    norm = max(seqs, key=lambda x: x[1] ** (1 / len(x[0])))
    n_seq, n_p = norm
    print(f"  FEIXE normalizado→ {frase(n_seq):<44s} P = {n_p:.4f}  "
          f"P^(1/len) = {n_p ** (1 / len(n_seq)):.4f}")

    print("\n  Três critérios, três respostas diferentes, mesmo modelo:")
    print("  · a gulosa é MÍOPE — escolheu o primeiro token de maior probabilidade")
    print("    e por isso perdeu a sequência de maior probabilidade conjunta;")
    print("  · o feixe ACHOU o máximo de probabilidade conjunta, e o máximo é a")
    print("    resposta curta e genérica. Ele fez o trabalho dele corretamente —")
    print("    o problema é que o trabalho dele não é o que a gente queria;")
    print("  · a normalização por comprimento inverte o resultado e traz a resposta")
    print("    longa e informativa. É um remendo com expoente ajustado à mão,")
    print("    e é exatamente isso que ela é.")


def bloco_6_amostragem_vs_greedy():
    titulo(6, "Amostragem × greedy — diversidade contra reprodutibilidade")
    rng = random.Random(SEMENTE)

    print(f'\nPrompt: "{PROMPT_A} ___"   (semente fixa = {SEMENTE})\n')
    print("  amostragem (T=1,0, sem truncamento):")
    for i in range(5):
        print(f"    execução {i + 1}: {PROMPT_A} {amostrar(DIST_A, rng)}")

    print("\n  greedy:")
    for i in range(5):
        print(f"    execução {i + 1}: {PROMPT_A} {greedy(DIST_A)}")

    print("\n  Mesma distribuição nos dois casos. Reprodutibilidade e diversidade")
    print("  são a mesma escolha vista de dois lados — e escolher uma custa a outra.")


def main():
    print()
    print("  AULA 10 — Do Transformer ao LLM")
    print("  Demonstração: uma distribuição, seis algoritmos, nenhum peso tocado.")
    bloco_1_distribuicao_crua()
    bloco_2_temperatura()
    bloco_3_top_k()
    bloco_4_top_p()
    bloco_5_busca()
    bloco_6_amostragem_vs_greedy()
    print()
    print("=" * 74)
    print("  As quatro constantes no topo deste arquivo são as quatro alavancas.")
    print("  No Lab 3 (Aula 11) elas passam a valer contra um modelo de verdade,")
    print("  com medição de tokens e de latência.")
    print("=" * 74)
    print()


if __name__ == "__main__":
    main()
