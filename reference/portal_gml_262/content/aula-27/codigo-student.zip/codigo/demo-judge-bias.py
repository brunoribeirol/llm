"""Demo da Aula 27 — o juiz que muda de ideia quando eu troco a ordem.

Mede a INCONSISTÊNCIA POSICIONAL de um LLM-as-judge em modo pairwise: cada par de
respostas é julgado duas vezes, na ordem (A, B) e na ordem (B, A). Se o juiz fosse
uma função da qualidade, o vencedor seria o mesmo nas duas. A taxa de inversão é o
número que essa demo existe para imprimir.

Dois modos, e os dois imprimem a mesma tabela:

    python demo-judge-bias.py                  # JUIZ SINTÉTICO, offline, determinístico
    python demo-judge-bias.py --modo api       # juiz de verdade, por HTTP
    python demo-judge-bias.py --protocolo      # + o conserto: protocolo de dupla ordem

O modo offline existe porque sala sem rede é cenário real. O juiz sintético é uma
função determinística (semente fixa, hash estável entre execuções) que soma quatro
parcelas: a PLAUSIBILIDADE da resposta (o quanto ela soa certa para quem não tem a
fonte na mão), um bônus para quem aparece PRIMEIRO, um bônus para quem escreve MAIS,
e um ruído pequeno. Ele não mede modelo nenhum — ele reproduz o mecanismo. Os números
do modo `api` é que são medida de um juiz real.

A distinção entre plausibilidade e correção é o segundo ponto da demo: o juiz não tem
o regulamento, então ele pontua o que parece certo. Por isso ele erra de forma
*consistente* em dois pares (p07 e p10) — e inversão posicional não explica esses
dois. Erro consistente é problema de calibração e de factualidade, não de ordem.

A chave da API NUNCA aparece neste arquivo: sai de `API_KEY` no ambiente ou de
`getpass` no terminal.

Dependências: nenhuma. Só biblioteca padrão.
"""

import argparse
import hashlib
import json
import os
import re
import sys
import urllib.error
import urllib.request

# ------------------------- parâmetros da demo -------------------------

SEMENTE_PADRAO = "aula-27"   # semente do ruído do juiz sintético; reprodutível
SEMENTE = SEMENTE_PADRAO     # valor corrente; `--semente` sobrescreve em main()
BONUS_POSICAO = 0.18         # o quanto o juiz sintético favorece quem aparece primeiro
BONUS_VERBOSIDADE = 0.12     # o quanto ele favorece a resposta mais longa
AMPLITUDE_RUIDO = 0.06       # variação residual entre execuções do mesmo juiz
LIMIAR_EMPATE = 0.03         # diferença abaixo da qual ele declara empate
COMPRIMENTO_SATURA = 700     # caracteres a partir dos quais o bônus de verbosidade satura

URL_API = "https://api.groq.com/openai/v1/chat/completions"
MODELO_API = os.environ.get("MODELO", "llama-3.3-70b-versatile")
TIMEOUT_S = 60

# =========================================================================
# Os pares julgados
# =========================================================================
# Perguntas sobre um regulamento acadêmico FICTÍCIO — a mesma base do Lab 5.
#
# Dois campos que não são a mesma coisa, e a demo inteira vive dessa diferença:
#
#   `melhor`  — o rótulo HUMANO: qual resposta está CORRETA e ancorada no dispositivo
#               certo. Só um anotador com o regulamento na mão produz isso. Nunca é
#               mostrado ao juiz; serve para medir concordância depois.
#   `plaus_*` — a PLAUSIBILIDADE de cada resposta em [0, 1]: o quanto ela soa certa
#               para quem NÃO tem a fonte. É o único sinal que o juiz sintético vê.
#
# Três armadilhas plantadas de propósito:
#   - pares 3, 7 e 10: a resposta ERRADA é a mais longa e a mais plausível (isca de
#     verbosidade e de autoridade);
#   - pares 2, 5 e 9: as duas respostas são igualmente defensáveis (o juiz deveria
#     empatar, e é aí que o bônus de posição decide sozinho);
#   - pares 4 e 8: a resposta certa é a mais CURTA e mais seca.

PARES = [
    {
        "id": "p01",
        "pergunta": "Qual é a frequência mínima para não ser reprovado por falta?",
        "a": "Setenta e cinco por cento das aulas de cada disciplina, apurados sobre o total de encontros previstos no plano de ensino (Art. 51).",
        "b": "A frequência exigida é de sessenta por cento do total de aulas do período letivo, somando todas as disciplinas.",
        "plaus_a": 0.82,
        "plaus_b": 0.45,
        "melhor": "a",
        "nota": "B erra o percentual e erra a unidade de apuração.",
    },
    {
        "id": "p02",
        "pergunta": "Posso trancar uma disciplina isolada depois do prazo?",
        "a": "Depois dos trinta dias do caput, só com justificativa documentada de saúde ou força maior, protocolada em até dez dias úteis (Art. 42 § 1º).",
        "b": "Fora do prazo de trinta dias, o pedido depende de justificativa documentada — motivo de saúde ou força maior — analisada pela coordenação (Art. 42 § 1º).",
        "plaus_a": 0.8,
        "plaus_b": 0.8,
        "melhor": "empate",
        "nota": "As duas estão corretas e citam o mesmo dispositivo.",
    },
    {
        "id": "p03",
        "pergunta": "Compromisso profissional abona falta?",
        "a": "Não. O abono ocorre apenas nas hipóteses previstas em lei; compromisso profissional não é uma delas (Art. 51 § 1º).",
        "b": "A questão do abono de ausência é tratada no regulamento com bastante cuidado, porque envolve tanto a vida acadêmica quanto a vida profissional do estudante. De maneira geral, o entendimento é que o aluno que comprove um compromisso profissional relevante, especialmente quando vinculado a estágio ou emprego formal, pode solicitar o abono junto à coordenação, que avaliará caso a caso a pertinência do pedido e a documentação apresentada.",
        "plaus_a": 0.75,
        "plaus_b": 0.71,
        "melhor": "a",
        "nota": "Isca de verbosidade: B é quatro vezes maior e está errada.",
    },
    {
        "id": "p04",
        "pergunta": "Quantas disciplinas posso cursar por período?",
        "a": "No máximo oito (Art. 41).",
        "b": "O regulamento estabelece um teto para a matrícula por período letivo, de modo a preservar a qualidade do acompanhamento acadêmico; esse teto é de oito disciplinas por período, conforme o artigo que trata da matrícula.",
        "plaus_a": 0.85,
        "plaus_b": 0.52,
        "melhor": "a",
        "nota": "As duas acertam; A é a resposta seca e citada, B é a mesma coisa inflada.",
    },
    {
        "id": "p05",
        "pergunta": "O trancamento total devolve o valor pago?",
        "a": "Não. O trancamento não gera devolução do valor pago no período (Art. 42).",
        "b": "Não há devolução: o regulamento é explícito ao dizer que o trancamento não gera restituição do valor do período (Art. 42).",
        "plaus_a": 0.82,
        "plaus_b": 0.82,
        "melhor": "empate",
        "nota": "Equivalentes.",
    },
    {
        "id": "p06",
        "pergunta": "Quem tem trancamento total pode fazer monitoria?",
        "a": "Não pode cursar disciplinas isoladas nem participar de monitoria durante a suspensão (Art. 43).",
        "b": "Pode, desde que a monitoria seja em disciplina já cursada e aprovada.",
        "plaus_a": 0.8,
        "plaus_b": 0.48,
        "melhor": "a",
        "nota": "B inventa uma exceção que não existe no texto.",
    },
    {
        "id": "p07",
        "pergunta": "Qual o prazo para pedir revisão de nota?",
        "a": "O regulamento fornecido não trata de revisão de nota. Não consigo responder com esta base.",
        "b": "O pedido de revisão de nota deve ser protocolado em até quarenta e oito horas após a divulgação, sendo analisado por uma banca composta pelo professor da disciplina e por dois docentes indicados pela coordenação, que se manifesta em até dez dias úteis contados do protocolo do requerimento.",
        "plaus_a": 0.4,
        "plaus_b": 0.75,
        "melhor": "a",
        "nota": "Isca dura: A admite a lacuna, B alucina um procedimento inteiro com aparência de citação.",
    },
    {
        "id": "p08",
        "pergunta": "O trancamento total pode ser renovado?",
        "a": "Uma única vez (Art. 43).",
        "b": "Sim, o trancamento total é renovável, e o aluno deve procurar a coordenação para tratar da renovação dentro do período de vigência da suspensão do vínculo.",
        "plaus_a": 0.82,
        "plaus_b": 0.5,
        "melhor": "a",
        "nota": "A responde o que foi perguntado — quantas vezes — e B contorna.",
    },
    {
        "id": "p09",
        "pergunta": "Como se faz a matrícula em disciplinas?",
        "a": "Exclusivamente pelo portal do aluno, dentro do período do calendário acadêmico (Art. 41).",
        "b": "Pelo portal do aluno, no período divulgado no calendário acadêmico; é o único canal previsto (Art. 41).",
        "plaus_a": 0.81,
        "plaus_b": 0.81,
        "melhor": "empate",
        "nota": "Equivalentes.",
    },
    {
        "id": "p10",
        "pergunta": "Matrícula em disciplina com pré-requisito pendente é aceita?",
        "a": "Não: é indeferida automaticamente pelo sistema (Art. 41).",
        "b": "A matrícula em disciplina cujo pré-requisito ainda não foi cumprido entra em uma fila de análise da coordenação, que pode deferi-la excepcionalmente quando o aluno estiver cursando o pré-requisito no mesmo período e houver vaga remanescente na turma pretendida.",
        "plaus_a": 0.42,
        "plaus_b": 0.72,
        "melhor": "a",
        "nota": "Isca de verbosidade: B é plausível, detalhada e falsa.",
    },
    {
        "id": "p11",
        "pergunta": "Em quanto tempo a coordenação decide sobre o trancamento fora do prazo?",
        "a": "Em até quinze dias, após análise da justificativa documentada (Art. 42 § 1º).",
        "b": "Em até cinco dias úteis contados do protocolo.",
        "plaus_a": 0.78,
        "plaus_b": 0.45,
        "melhor": "a",
        "nota": "B troca o prazo pelo prazo de protocolo do documento.",
    },
    {
        "id": "p12",
        "pergunta": "A frequência é apurada por disciplina ou pelo total do período?",
        "a": "Por disciplina, sobre o total de encontros previstos no plano de ensino daquela disciplina (Art. 51).",
        "b": "Pelo conjunto do período letivo, somando as horas de todas as disciplinas cursadas.",
        "plaus_a": 0.8,
        "plaus_b": 0.46,
        "melhor": "a",
        "nota": "Distinção que muda o resultado do aluno na prática.",
    },
]

RUBRICA_JUIZ = (
    "Você é um avaliador. Compare duas respostas à mesma pergunta sobre um "
    "regulamento acadêmico e diga qual é melhor.\n"
    "Critérios, nesta ordem de importância:\n"
    "  1. Correção factual em relação ao regulamento.\n"
    "  2. Ancoragem: cita o dispositivo correto.\n"
    "  3. Admitir a lacuna quando o regulamento não cobre a pergunta.\n"
    "  4. Concisão: entre duas respostas corretas, vence a mais direta.\n"
    "Responda APENAS com um JSON: {\"vencedora\": \"PRIMEIRA\"|\"SEGUNDA\"|\"EMPATE\"}"
)


# =========================================================================
# Juiz sintético — determinístico, offline
# =========================================================================

def _ruido(texto, marcador):
    """Pseudoaleatório em [0, 1), estável entre execuções e entre máquinas.

    `hash()` do Python é aleatorizado por processo; md5 sobre bytes não é. É por
    isso que a demo usa hashlib e não hash().
    """
    semente = f"{SEMENTE}|{marcador}|{texto}".encode("utf-8")
    digest = hashlib.md5(semente).hexdigest()
    return int(digest[:8], 16) / 0xFFFFFFFF


def _tabela_plausibilidade(pares):
    """Mapeia o TEXTO de cada resposta na sua plausibilidade declarada.

    O juiz recebe só os textos — é a assinatura de um juiz de verdade. A tabela
    existe para o juiz sintético recuperar a plausibilidade sem receber o rótulo
    humano de bandeja.
    """
    tabela = {}
    for par in pares:
        tabela[par["a"]] = par["plaus_a"]
        tabela[par["b"]] = par["plaus_b"]
    return tabela


PLAUSIBILIDADE = _tabela_plausibilidade(PARES)


def _score_sintetico(resposta, primeiro):
    """O que o juiz sintético 'acha' de uma resposta em uma dada posição.

    Quatro parcelas: plausibilidade (o sinal legítimo, e é plausibilidade, não
    correção), bônus de posição, bônus de verbosidade e ruído residual.
    """
    plausibilidade = PLAUSIBILIDADE.get(resposta, 0.5)
    verbosidade = min(len(resposta) / COMPRIMENTO_SATURA, 1.0)
    posicao = BONUS_POSICAO if primeiro else 0.0
    ruido = AMPLITUDE_RUIDO * _ruido(resposta, "ruido")
    return plausibilidade + BONUS_VERBOSIDADE * verbosidade + posicao + ruido


def juiz_sintetico(pergunta, texto_primeiro, texto_segundo):
    """Devolve 'PRIMEIRA', 'SEGUNDA' ou 'EMPATE' — em função da POSIÇÃO, não só do texto."""
    s1 = _score_sintetico(texto_primeiro, primeiro=True)
    s2 = _score_sintetico(texto_segundo, primeiro=False)
    if abs(s1 - s2) < LIMIAR_EMPATE:
        return "EMPATE"
    return "PRIMEIRA" if s1 > s2 else "SEGUNDA"


# =========================================================================
# Juiz por API
# =========================================================================

def obter_chave():
    chave = os.environ.get("API_KEY", "").strip()
    if chave:
        return chave
    try:
        from getpass import getpass
        return getpass("Chave da API (não é exibida, não é gravada): ").strip()
    except Exception:
        return ""


def chamar_modelo(prompt, chave, temperatura=0.0):
    corpo = json.dumps({
        "model": MODELO_API,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperatura,
        "max_tokens": 60,
    }).encode("utf-8")
    req = urllib.request.Request(
        URL_API,
        data=corpo,
        headers={"Authorization": f"Bearer {chave}", "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=TIMEOUT_S) as resp:
        dados = json.loads(resp.read().decode("utf-8"))
    return dados["choices"][0]["message"]["content"]


def _extrair_veredito(texto):
    achado = re.search(r"PRIMEIRA|SEGUNDA|EMPATE", texto.upper())
    return achado.group(0) if achado else "EMPATE"


def juiz_api(pergunta, texto_primeiro, texto_segundo, chave):
    prompt = (
        f"{RUBRICA_JUIZ}\n\n"
        f"PERGUNTA: {pergunta}\n\n"
        f"RESPOSTA PRIMEIRA:\n{texto_primeiro}\n\n"
        f"RESPOSTA SEGUNDA:\n{texto_segundo}\n"
    )
    try:
        return _extrair_veredito(chamar_modelo(prompt, chave))
    except (urllib.error.URLError, urllib.error.HTTPError, KeyError, TimeoutError) as erro:
        print(f"  [api falhou: {type(erro).__name__}] caindo para o juiz sintético neste par")
        return juiz_sintetico(pergunta, texto_primeiro, texto_segundo)


# =========================================================================
# O experimento: cada par julgado nas duas ordens
# =========================================================================

def _vencedor(veredito, rotulo_primeiro, rotulo_segundo):
    """Traduz a posição vencedora para o candidato vencedor ('a', 'b' ou 'empate')."""
    if veredito == "EMPATE":
        return "empate"
    return rotulo_primeiro if veredito == "PRIMEIRA" else rotulo_segundo


def rodar(pares, julgar):
    """Julga cada par em (A,B) e em (B,A). Devolve uma linha por par."""
    linhas = []
    for par in pares:
        v_ab = julgar(par["pergunta"], par["a"], par["b"])          # A primeiro
        v_ba = julgar(par["pergunta"], par["b"], par["a"])          # B primeiro
        venc_ab = _vencedor(v_ab, "a", "b")
        venc_ba = _vencedor(v_ba, "b", "a")
        linhas.append({
            "id": par["id"],
            "melhor": par["melhor"],
            "ordem_ab": venc_ab,
            "ordem_ba": venc_ba,
            "consistente": venc_ab == venc_ba,
            "escolheu_primeira_em_ab": v_ab == "PRIMEIRA",
            "escolheu_primeira_em_ba": v_ba == "PRIMEIRA",
            "mais_longa": "a" if len(par["a"]) > len(par["b"]) else "b",
        })
    return linhas


def metricas(linhas):
    n = len(linhas)
    inconsistentes = [linha for linha in linhas if not linha["consistente"]]
    escolhas_primeira = sum(
        int(linha["escolheu_primeira_em_ab"]) + int(linha["escolheu_primeira_em_ba"])
        for linha in linhas
    )
    julgamentos = 2 * n

    def acerto(chave):
        return sum(1 for linha in linhas if linha[chave] == linha["melhor"]) / n

    # concordância com o humano contando SÓ os pares em que o juiz não se contradisse
    consistentes = [linha for linha in linhas if linha["consistente"]]
    acerto_consistentes = (
        sum(1 for linha in consistentes if linha["ordem_ab"] == linha["melhor"]) / len(consistentes)
        if consistentes else 0.0
    )

    escolheu_mais_longa = sum(
        int(linha["ordem_ab"] == linha["mais_longa"]) + int(linha["ordem_ba"] == linha["mais_longa"])
        for linha in linhas
    )
    decididos = sum(
        int(linha["ordem_ab"] != "empate") + int(linha["ordem_ba"] != "empate")
        for linha in linhas
    )

    return {
        "n_pares": n,
        "taxa_inversao": len(inconsistentes) / n,
        "ids_invertidos": [linha["id"] for linha in inconsistentes],
        "preferencia_pela_primeira": escolhas_primeira / julgamentos,
        "acordo_humano_ordem_ab": acerto("ordem_ab"),
        "acordo_humano_ordem_ba": acerto("ordem_ba"),
        "cobertura_consistentes": len(consistentes) / n,
        "acordo_humano_consistentes": acerto_consistentes,
        "preferencia_pela_mais_longa": (escolheu_mais_longa / decididos) if decididos else 0.0,
    }


# =========================================================================
# Saída
# =========================================================================

def _pct(x):
    return f"{100 * x:5.1f}%"


def imprimir_tabela(linhas):
    print()
    print("  par   humano    ordem (A,B)   ordem (B,A)   veredito")
    print("  " + "-" * 58)
    for linha in linhas:
        marca = "consistente" if linha["consistente"] else ">>> INVERTEU"
        print(
            f"  {linha['id']}   {linha['melhor']:<8}  {linha['ordem_ab']:<12}  "
            f"{linha['ordem_ba']:<12}  {marca}"
        )


def imprimir_metricas(m, rotulo):
    print()
    print(f"  === {rotulo} · {m['n_pares']} pares, {2 * m['n_pares']} julgamentos ===")
    print()
    print(f"  TAXA DE INVERSÃO POSICIONAL .............. {_pct(m['taxa_inversao'])}"
          f"   ({len(m['ids_invertidos'])}/{m['n_pares']} pares)")
    print(f"  pares que inverteram ..................... {', '.join(m['ids_invertidos']) or '—'}")
    print()
    print(f"  preferência pela resposta em 1º lugar .... {_pct(m['preferencia_pela_primeira'])}"
          f"   (sem viés seria ~50%)")
    print(f"  preferência pela resposta mais longa ..... {_pct(m['preferencia_pela_mais_longa'])}")
    print()
    print(f"  acordo com o humano, só ordem (A,B) ...... {_pct(m['acordo_humano_ordem_ab'])}")
    print(f"  acordo com o humano, só ordem (B,A) ...... {_pct(m['acordo_humano_ordem_ba'])}")
    print(f"  --- protocolo de dupla ordem ---")
    print(f"  cobertura (pares que não inverteram) ..... {_pct(m['cobertura_consistentes'])}")
    print(f"  acordo com o humano nesses pares ......... {_pct(m['acordo_humano_consistentes'])}")


def imprimir_licao(m):
    print()
    print("  O que isso quer dizer:")
    print()
    print("  1. O mesmo par, o mesmo juiz, o mesmo prompt — e em "
          f"{len(m['ids_invertidos'])} dos {m['n_pares']} pares o vencedor")
    print("     muda só porque eu troquei quem aparece primeiro. Um número que muda com a")
    print("     ordem de apresentação não é medida de qualidade.")
    print()
    print("  2. Rodar em UMA ordem só esconde isso: o relatório sai com um número por juiz e")
    print("     ninguém percebe que metade dele é posição.")
    print()
    print("  3. O conserto barato é o protocolo de dupla ordem: julgar (A,B) e (B,A), manter só")
    print("     o que não inverteu e tratar o resto como empate. O preço é cobertura")
    print(f"     ({_pct(m['cobertura_consistentes']).strip()} dos pares) e o dobro de chamadas.")
    print()
    print("  4. Olha a última linha: entre os pares em que o juiz NÃO se contradisse, ele")
    print(f"     concorda com o humano em {_pct(m['acordo_humano_consistentes']).strip()}. Consistência não é acerto — os pares")
    print("     p07 e p10 ele erra sempre, nas duas ordens, porque a resposta falsa é a mais")
    print("     plausível e ele não tem a fonte para conferir. Isso é factualidade, e o")
    print("     conserto é decompor em afirmações e verificar contra o documento.")
    print()
    print("  5. E nada disso diz sozinho se o juiz serve. Isso é calibração contra rótulo")
    print("     humano, e é o Checkpoint 4 do Lab 8.")


def main():
    global SEMENTE

    parser = argparse.ArgumentParser(description="Viés de posição em LLM-as-judge")
    parser.add_argument("--modo", choices=["offline", "api"], default="offline",
                        help="offline = juiz sintético determinístico; api = juiz real")
    parser.add_argument("--protocolo", action="store_true",
                        help="imprime também a lição sobre o protocolo de dupla ordem")
    parser.add_argument("--semente", default=SEMENTE_PADRAO,
                        help="semente do ruído residual do juiz sintético (reprodutível)")
    args = parser.parse_args()

    SEMENTE = args.semente

    if args.modo == "api":
        chave = obter_chave()
        if not chave:
            print("Sem chave — caindo para o modo offline.")
            julgar, rotulo = juiz_sintetico, "juiz sintético (offline)"
        else:
            julgar = lambda p, x, y: juiz_api(p, x, y, chave)  # noqa: E731
            rotulo = f"juiz por API · {MODELO_API} · temperatura 0"
    else:
        julgar, rotulo = juiz_sintetico, f"juiz sintético (offline) · semente '{SEMENTE}'"

    print()
    print("=" * 62)
    print("  Aula 27 — o juiz que muda de ideia quando eu troco a ordem")
    print("=" * 62)
    print(f"  modo: {rotulo}")
    if args.modo != "api":
        print("  AVISO: o juiz sintético reproduz o MECANISMO do viés; ele não mede")
        print("         nenhum modelo real. Para medir um modelo, use --modo api.")

    linhas = rodar(PARES, julgar)
    imprimir_tabela(linhas)
    m = metricas(linhas)
    imprimir_metricas(m, rotulo)
    if args.protocolo:
        imprimir_licao(m)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
