"""Isola o efeito de multiplicar o gradiente por um ganho a cada passo."""

import sys

import numpy as np


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


DIMENSAO = 32
COMPRIMENTOS = (10, 50, 200)
GANHOS = (0.9, 1.1)


def norma_produto_repetido(ganho: float, passos: int) -> float:
    """Retorna ||(ganho I)^passos||_2 para um caso controlado e determinístico."""
    transformacao = ganho * np.eye(DIMENSAO, dtype=np.float64)
    produto = np.eye(DIMENSAO, dtype=np.float64)

    for _ in range(passos):
        produto = produto @ transformacao

    return float(np.linalg.norm(produto, ord=2))


def main() -> None:
    print("Produto repetido no caminho do gradiente")
    print(f"dimensão fixa: {DIMENSAO}")

    for ganho in GANHOS:
        for passos in COMPRIMENTOS:
            norma = norma_produto_repetido(ganho, passos)
            esperado = ganho**passos
            print(
                f"ganho={ganho:.1f}  T={passos:3d}  "
                f"norma={norma:.3e}  esperado={esperado:.3e}"
            )
            assert np.isclose(norma, esperado, rtol=1e-12, atol=0.0)


if __name__ == "__main__":
    main()
