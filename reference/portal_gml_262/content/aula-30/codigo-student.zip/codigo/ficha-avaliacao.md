# Ficha de avaliação — Projeto Final · Aula 30

> **Instrumento do instrutor.** Uma ficha por equipe, preenchida **ao vivo**, durante o slot de 15 min.
> Os quatro pesos são os da seção 8 da ementa e não são reinventados aqui: funcionamento e adequação
> técnica 40%, rigor da avaliação quantitativa 30%, relatório técnico 20%, apresentação e demo 10%.
> A soma dá uma nota de 0 a 100 para o projeto; ela alimenta os 30 pontos percentuais de
> *sistema/relatório (20%) + apresentação (10%)* da média final. Proposta (5%) e checkpoint (5%) já
> foram lançados nas Aulas 22 e 26 e **não** são reavaliados aqui.
>
> Regra de uso: marcar o nível **enquanto a equipe apresenta**, não depois. Ficha preenchida de memória
> no fim da sessão converge para "todos medianos" e perde o poder de discriminar — que é exatamente o
> defeito que o Lab 8 ensinou a evitar.

---

## Identificação

| Campo | Preenchimento |
|---|---|
| Equipe | ____________________________________________ |
| Integrantes presentes | ____________________________________________ |
| Integrantes ausentes | ____________________________________________ |
| Tema / domínio | ____________________________________________ |
| Repositório | ____________________________________________ |
| Ordem na sessão | ____ de ____ |
| Início do slot | ____:____ · Fim: ____:____ |
| Duração real da apresentação | ______ min (limite 12) |
| Estourou o tempo? | ☐ não ☐ sim, ______ min |

## Pré-requisitos de entrega (checagem binária, antes de pontuar)

Cada item ausente é registrado aqui e **cobrado no item correspondente**. Nenhum destes zera o projeto
sozinho, exceto onde indicado.

- ☐ Repositório entregue e acessível
- ☐ README reproduzível (passos que um terceiro executa)
- ☐ Relatório técnico de 4 a 6 páginas presente
- ☐ Harness de avaliação do Lab 8 no repositório e **executável**
- ☐ `relatorio-avaliacao.md` gerado pelo código, não redigido à mão
- ☐ Pelo menos **2 técnicas centrais do curso** combinadas (requisito 1 da seção 9 da ementa)
- ☐ Custo zero ou próximo de zero declarado (free tier, modelo local, Colab)
- ☐ **Declaração de uso de IA** presente — *ausência zera o item de relatório e habilita defesa oral obrigatória*
- ☐ Demo ao vivo executada nesta sessão

Técnicas centrais identificadas: ____________________________________________

---

## Item 1 · Funcionamento e adequação técnica — **40%**

O que se avalia: o sistema **roda** na demo ao vivo, faz o que a proposta disse que faria, e a arquitetura
é adequada ao problema — não sobre-engenheirada nem subdimensionada.

| Nível | Faixa | Descritor observável |
|---|---|---|
| **Pleno** | 34–40 | A demo roda ao vivo, sem gravação e sem "aqui normalmente funciona". Executa pelo menos um caso **difícil** (paráfrase, multi-fonte, fora do escopo ou adversarial), não só o caminho felizeado. As duas ou mais técnicas do curso estão de fato integradas, não justapostas. A equipe explica por que escolheu cada componente e o que considerou e descartou. Trata falha graciosamente: quando o caso escolhido falha na frente da turma, a equipe **nomeia a camada** e segue. |
| **Parcial** | 20–33 | A demo roda, mas só no caminho felizeado, ou com um componente simulado que a equipe não declarou de imediato. As técnicas estão presentes e pouco integradas (dois scripts que não conversam). A justificativa de arquitetura é genérica ("é o padrão", "todo mundo usa"). Ou: roda com falha em um caso e a equipe não consegue localizar a camada. |
| **Insuficiente** | 0–19 | A demo não roda ao vivo e é substituída por vídeo/prints sem contingência combinada previamente. Ou só uma técnica do curso está presente. Ou o sistema demonstrado não é o descrito no relatório. |

Nota do item: **______ / 40**

Evidência observada (uma linha, escrita durante a demo):
_______________________________________________________________________

## Item 2 · Rigor da avaliação quantitativa — **30%**

O que se avalia: o padrão estabelecido nas Aulas 27 e 28. **Número por camada, com denominador e
procedência.** Este é o item que mais separa as equipes, e é onde a nota se decide.

| Nível | Faixa | Descritor observável |
|---|---|---|
| **Pleno** | 26–30 | Conjunto de teste próprio com **20+ casos** e composição justificada (pares de paráfrase, casos fora do escopo, regressões) — casos que discriminam, não casos fáceis. Tabela com **uma linha por camada** do sistema e o `n` de cada métrica visível. Juiz **declarado** (heurístico ou modelo, família, temperatura, rubrica) e **calibrado** contra amostra anotada pela equipe, com **kappa** reportado — não só acordo bruto. Desacordos inspecionados, com a decisão escrita. Análise de falhas atribuindo cada uma à **menor camada que a explica**, e priorização com custo declarado. Limitações reconhecidas. |
| **Parcial** | 15–25 | Conjunto existe mas é pequeno, homogêneo ou visivelmente escrito depois de ver a saída do sistema. Métricas existem mas sem `n`, ou só na camada final. Juiz usado sem declarar quem julgou, ou calibrado só com acordo bruto. Falhas listadas sem atribuição de camada. Priorização ausente ou sem custo. |
| **Insuficiente** | 0–14 | **"O sistema respondeu bem em N de M perguntas"** e nada mais. Nenhum número por camada. Nenhuma concordância de juiz medida. Avaliação feita por impressão global, por print de conversa, ou ausente. Vale mesmo quando o sistema funciona perfeitamente na demo — e este é o caso mais comum de nota baixa aqui. |

Nota do item: **______ / 30**

Números que a equipe apresentou (transcrever ao vivo, com o `n`):

| Camada | Métrica | Valor | `n` |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

Juiz declarado: ☐ heurístico ☐ LLM (modelo: __________________, temperatura: ______)
Kappa reportado: ______ · Acordo bruto: ______ · Amostra anotada: ______ casos

## Item 3 · Relatório técnico — **20%**

O que se avalia: clareza, justificativa das decisões e limitações reconhecidas. Formato de artigo curto:
problema, arquitetura, experimentos, resultados, limitações.

| Nível | Faixa | Descritor observável |
|---|---|---|
| **Pleno** | 17–20 | 4 a 6 páginas, com as cinco seções. Cada decisão de arquitetura vem com a alternativa considerada e o critério de escolha. Resultados apresentados com denominador e ligados à tabela do harness — sem número no texto que não exista no relatório de avaliação. Seção de limitações **específica** (o que o conjunto de teste não cobre, viés da anotação da própria equipe, execução única sem variância) e não genérica. README reproduzível de fato: um terceiro roda seguindo os passos. Declaração de uso de IA presente e específica. |
| **Parcial** | 10–16 | Seções presentes mas desiguais: arquitetura descrita sem justificativa, ou resultados sem ligação com o harness. Limitações genéricas ("o sistema pode melhorar", "faltou tempo"). README incompleto — falta a chave, o dado ou uma etapa. Declaração de uso de IA presente mas vaga. |
| **Insuficiente** | 0–9 | Fora do formato (slides no lugar do relatório, ou texto sem resultados). Números no texto que não existem em nenhuma medição. Sem limitações. README que não reproduz. **Sem declaração de uso de IA** — item zerado e defesa oral obrigatória. |

Nota do item: **______ / 20**

Limitação mais bem reconhecida pela equipe: ____________________________________
Limitação óbvia que a equipe **não** reconheceu: ________________________________

## Item 4 · Apresentação e demo — **10%**

O que se avalia: uso do tempo, clareza da comunicação e **defesa** — a capacidade de responder por
aquilo que a equipe construiu.

| Nível | Faixa | Descritor observável |
|---|---|---|
| **Pleno** | 9–10 | Fecha em 12 min sem ser interrompida. Estrutura legível: problema, arquitetura, demo, números, limitações. Os números aparecem na tela, não são narrados de cabeça. **Responde as perguntas do instrutor sobre qualquer camada**, incluindo a que a equipe não construiu em nenhum lab: sabe por que aquela peça existe e que número prova que ela funciona. Mais de um integrante fala. |
| **Parcial** | 5–8 | Estoura o tempo e precisa ser cortada, ou sobra tempo por falta de conteúdo. Slides densos ou números só narrados. Responde parte das perguntas; em uma delas, transfere a resposta para "quem fez essa parte não veio". Um integrante fala e os outros assistem. |
| **Insuficiente** | 0–4 | Não fecha o essencial no tempo (demo ou números ficam de fora). Nenhum integrante consegue explicar uma camada central do sistema — o sinal clássico de código não compreendido, que aciona a política de defesa da ementa. |

Nota do item: **______ / 10**

## Defesa — perguntas feitas e qualidade da resposta

Registrar a pergunta e classificar a resposta: **S** (sólida) · **P** (parcial) · **N** (não respondida).

| # | Pergunta feita | Quem respondeu | S/P/N |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |

☐ Caso de defesa oral adicional fora da sessão — motivo: _______________________

---

## Fechamento da ficha

| Item | Peso | Nota |
|---|---|---|
| 1 · Funcionamento e adequação técnica | 40 | ______ |
| 2 · Rigor da avaliação quantitativa | 30 | ______ |
| 3 · Relatório técnico | 20 | ______ |
| 4 · Apresentação e demo | 10 | ______ |
| **Total do projeto** | **100** | **______** |

Feedback devolvido à equipe (duas linhas, escritas ao vivo — uma coisa que funcionou, uma coisa a
consertar; é o que a equipe leva):

1. Funcionou: _______________________________________________________________
2. Consertar: _______________________________________________________________

Assinatura do instrutor: ______________________  Data: `[definir na oferta]`
