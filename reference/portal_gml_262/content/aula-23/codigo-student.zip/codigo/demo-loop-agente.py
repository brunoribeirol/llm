"""demo-loop-agente.py — Aula 23 · demonstração do instrutor (13 min, offline).

As CINCO PEÇAS da definição operacional de agente, cada uma marcada no código com
um comentário `# PEÇA n`:

    agente = modelo + ferramentas + loop + objetivo + critério de parada

Quatro modos, para a aula mostrar o que acontece quando uma peça é removida:

    python demo-loop-agente.py --normal          # tudo no lugar
    python demo-loop-agente.py --sem-parada      # sem critério de parada
    python demo-loop-agente.py --sem-orcamento   # sem max_passos (detector salva)
    python demo-loop-agente.py --parada-precoce  # parada fácil demais
    python demo-loop-agente.py --todos           # os quatro em sequência

Sem rede, sem dependência, sem chave de API: o "modelo" aqui é um SIMULADOR
ROTEIRADO determinístico com semente fixa (`SEMENTE = 23`). Ele não mede modelo
nenhum — ele existe para a saída ser idêntica em casa e na sala. A parte que
importa pedagogicamente é o `loop_agente`, e essa é real.

No Lab 7 (Aula 25) o aluno escreve este loop na mão, com um modelo de verdade.
"""

import argparse
import json
import random
import re
import sys

SEMENTE = 23
random.seed(SEMENTE)

# ---------------------------------------------------------------------------
# PEÇA 4 — OBJETIVO. Ele entra no prompt de sistema, e é a única coisa que dá
# direção ao loop. Sem esta string, o que sobra é um chat.
# ---------------------------------------------------------------------------
OBJETIVO = (
    "Responder à pergunta do aluno sobre o regulamento acadêmico, citando o "
    "dispositivo que sustenta a resposta e fazendo as contas necessárias."
)

FORMATO = """Responda SEMPRE em uma destas duas formas.

Para agir:
Thought: <por que este passo>
Action: <nome da ferramenta>
Action Input: <JSON com os argumentos>

Para encerrar:
Thought: <o que a evidência sustenta>
Final Answer: <resposta, citando o dispositivo observado>
"""

# Regra de parada exigida no modo normal e ausente no modo --parada-precoce.
REGRA_DE_PARADA = (
    "NUNCA use Final Answer antes de ter pelo menos uma Observation que sustente "
    "a resposta. Resposta final sem observação é considerada errada."
)

# ---------------------------------------------------------------------------
# Corpus FICTÍCIO — o mesmo regulamento inventado das Aulas 18 a 22.
# Não é o regulamento de nenhuma instituição real.
# ---------------------------------------------------------------------------
DISPOSITIVOS = [
    {"dispositivo": "Art. 42",
     "titulo": "Do trancamento de disciplina",
     "texto": ("O aluno pode solicitar o trancamento de uma disciplina isolada até o "
               "encerramento do prazo de trinta dias corridos contados a partir do "
               "primeiro dia de aula do período letivo.")},
    {"dispositivo": "Art. 51",
     "titulo": "Da frequência mínima",
     "texto": ("É reprovado por falta o aluno que não alcançar setenta e cinco por "
               "cento de frequência às aulas de cada disciplina.")},
    {"dispositivo": "Art. 53",
     "titulo": "Do coeficiente de rendimento",
     "texto": ("Disciplina trancada dentro do prazo não entra no cálculo do "
               "coeficiente de rendimento.")},
]


def ferramenta_buscar_regulamento(termo, k=2):
    """Busca por termos no corpus fictício. Devolve os k dispositivos mais pontuados."""
    if not isinstance(termo, str) or not termo.strip():
        return {"erro": "'termo' é obrigatório"}
    palavras = [p for p in re.findall(r"\w+", termo.lower()) if len(p) > 3]
    achados = []
    for d in DISPOSITIVOS:
        alvo = f"{d['dispositivo']} {d['titulo']} {d['texto']}".lower()
        score = sum(1 for p in palavras if p in alvo)
        if score:
            achados.append((score, d))
    achados.sort(key=lambda par: -par[0])
    if not achados:
        return {"achados": [], "aviso": "nenhum dispositivo casou com o termo"}
    return {"achados": [{"dispositivo": d["dispositivo"], "texto": d["texto"]}
                        for _, d in achados[:k]]}


PERMITIDO = re.compile(r"^[0-9\s\.\+\-\*/\(\)]+$")


def ferramenta_calcular(expressao):
    """Aritmética com lista de caracteres permitidos. `eval` sobre string de modelo
    sem essa barreira é a definição de ferramenta insegura."""
    if not isinstance(expressao, str) or not PERMITIDO.match(expressao):
        return {"erro": "expressão inválida: só dígitos e + - * / ( ) são aceitos"}
    try:
        return {"resultado": eval(expressao, {"__builtins__": {}}, {})}  # noqa: S307
    except Exception as erro:
        return {"erro": f"{type(erro).__name__}: {erro}"}


# ---------------------------------------------------------------------------
# PEÇA 2 — FERRAMENTAS. Nome -> função. É a única ponte entre o texto que o
# modelo escreveu e o código que roda. Nada fora deste dicionário é executável.
# ---------------------------------------------------------------------------
FERRAMENTAS = {
    "buscar_regulamento": ferramenta_buscar_regulamento,
    "calcular": ferramenta_calcular,
}

CATALOGO = (
    "buscar_regulamento(termo: str, k: int = 2) — busca dispositivos do regulamento\n"
    "calcular(expressao: str) — avalia uma expressão aritmética simples"
)


# ---------------------------------------------------------------------------
# PEÇA 1 — MODELO. Aqui é um simulador roteirado; num agente real esta função é
# uma chamada HTTP. A assinatura é a mesma: entra a trajetória, sai texto.
# ---------------------------------------------------------------------------
def chamar_modelo(trajetoria, modo):
    """Simulador ROTEIRADO e determinístico. Decide a próxima fala olhando quais
    observações já existem na trajetória — é a política que a aula quer exibir,
    não uma medida de capacidade de modelo nenhum."""
    observacoes = [m for m in trajetoria if m["papel"] == "observacao"]
    achou_prazo = any("trinta dias" in m["texto"] for m in observacoes)
    achou_conta = any('"resultado"' in m["texto"] for m in observacoes)

    if modo == "parada-precoce":
        # Sem a REGRA_DE_PARADA no prompt, o modelo encerra na primeira volta.
        return ("Thought: eu acho que sei a resposta de cabeça.\n"
                "Final Answer: o prazo de trancamento costuma ser de trinta dias, "
                "então ainda deve dar tempo.")

    if modo in ("sem-parada", "sem-orcamento"):
        # Sem critério de parada, a mesma ação volta indefinidamente.
        return ("Thought: preciso confirmar o prazo de trancamento.\n"
                "Action: buscar_regulamento\n"
                'Action Input: {"termo": "prazo de trancamento"}')

    if not achou_prazo:
        return ("Thought: a pergunta depende do prazo previsto no regulamento; "
                "vou buscar o dispositivo.\n"
                "Action: buscar_regulamento\n"
                'Action Input: {"termo": "prazo de trancamento de disciplina"}')
    if not achou_conta:
        return ("Thought: o prazo é de trinta dias e já passaram dez; falta a "
                "subtração.\n"
                "Action: calcular\n"
                'Action Input: {"expressao": "30 - 10"}')
    return ("Thought: tenho o dispositivo e a conta; posso encerrar citando a fonte.\n"
            "Final Answer: sim, ainda dá tempo — o Art. 42 fixa trinta dias corridos "
            "desde o primeiro dia de aula, e como já passaram dez, restam 20 dias.")


def parsear(texto):
    """Extrai (pensamento, acao, argumentos, resposta_final) do texto do modelo."""
    pensamento = re.search(r"Thought:\s*(.+)", texto)
    final = re.search(r"Final Answer:\s*(.+)", texto, re.S)
    acao = re.search(r"Action:\s*(\S+)", texto)
    entrada = re.search(r"Action Input:\s*(\{.*\})", texto, re.S)
    argumentos = {}
    if entrada:
        try:
            argumentos = json.loads(entrada.group(1))
        except json.JSONDecodeError as erro:
            # Erro de parsing é INFORMAÇÃO, não exceção: volta como observação.
            return (pensamento.group(1) if pensamento else "",
                    None, {"erro_de_parsing": str(erro)}, None)
    return (pensamento.group(1).strip() if pensamento else "",
            acao.group(1).strip() if acao else None,
            argumentos,
            final.group(1).strip() if final else None)


def tokens_aprox(trajetoria):
    """Aproximação grosseira e honesta: 1 token ~ 4 caracteres."""
    return sum(len(m["texto"]) for m in trajetoria) // 4


def montar_prompt(pergunta, modo):
    partes = [OBJETIVO, "", "Ferramentas disponíveis:", CATALOGO, "", FORMATO]
    if modo != "parada-precoce":
        partes += ["", REGRA_DE_PARADA]
    return "\n".join(partes)


# ---------------------------------------------------------------------------
# PEÇA 3 — LOOP. É este `while` que separa tool calling de agente.
# PEÇA 5 — CRITÉRIO DE PARADA. Duas linhas, marcadas abaixo: a que reconhece a
# resposta final e o teto de passos. Uma protege a resposta, a outra a fatura.
# ---------------------------------------------------------------------------
def loop_agente(pergunta, modo="normal", max_passos=4, teto_absoluto=12):
    sistema = montar_prompt(pergunta, modo)
    trajetoria = [{"papel": "sistema", "texto": sistema},
                  {"papel": "pergunta", "texto": pergunta}]

    print(f"[OBSERVAR ] pergunta do usuário: {pergunta}")
    print(f"            prompt de sistema: {len(sistema)} caracteres "
          f"(~{len(sistema)//4} tokens)\n")

    passo = 0
    ultima_acao = None
    repeticoes = 0

    while True:
        passo += 1

        # PEÇA 5a — teto de passos. Ausente no modo --sem-orcamento.
        if modo != "sem-orcamento" and passo > max_passos:
            print(f"[PARADA   ] orçamento esgotado em {max_passos} passos — "
                  "devolvendo fallback declarado")
            return ("Não consegui responder com segurança. Tentei: "
                    f"{ultima_acao} (repetida {repeticoes + 1}x).", trajetoria)

        if passo > teto_absoluto:
            print("[PARADA   ] teto absoluto do script — em produção, isto seria "
                  "um laço infinito")
            return "Abortado pelo teto absoluto.", trajetoria

        texto = chamar_modelo(trajetoria, modo)
        trajetoria.append({"papel": "modelo", "texto": texto})
        pensamento, acao, argumentos, resposta = parsear(texto)

        print(f"[PLANEJAR ] passo {passo} · {pensamento}")

        # PEÇA 5b — reconhecimento da resposta final.
        if resposta is not None:
            acoes = sum(1 for m in trajetoria if m["papel"] == "acao")
            print(f"[PARADA   ] resposta final no passo {passo}, "
                  f"após {acoes} ação(ões) executada(s)")
            print(f"            trajetória: {len(trajetoria)} mensagens, "
                  f"~{tokens_aprox(trajetoria)} tokens acumulados\n")
            return resposta, trajetoria

        if acao is None or acao not in FERRAMENTAS:
            observacao = {"erro": f"ferramenta desconhecida: {acao!r}. "
                                 f"Disponíveis: {sorted(FERRAMENTAS)}"}
        else:
            print(f"[AGIR     ] {acao}({json.dumps(argumentos, ensure_ascii=False)})")
            trajetoria.append({"papel": "acao", "texto": f"{acao} {argumentos}"})
            observacao = FERRAMENTAS[acao](**argumentos)

        bruto = json.dumps(observacao, ensure_ascii=False)
        trajetoria.append({"papel": "observacao", "texto": bruto})
        print(f"[REFLETIR ] observação: {bruto[:96]}{'…' if len(bruto) > 96 else ''}")
        print(f"            trajetória: {len(trajetoria)} mensagens, "
              f"~{tokens_aprox(trajetoria)} tokens acumulados (é isto que a próxima "
              "chamada reenvia)\n")

        # Detector de repetição — a proteção que salva o modo --sem-orcamento.
        # Ligado só ali, de propósito: no --sem-parada é o orçamento que segura,
        # e a aula compara as duas formas de parar.
        assinatura = (acao, json.dumps(argumentos, sort_keys=True))
        repeticoes = repeticoes + 1 if assinatura == ultima_acao else 0
        ultima_acao = assinatura
        if modo == "sem-orcamento" and repeticoes >= 2:
            print("[PARADA   ] mesma ação com o mesmo argumento 3x — abortando. "
                  "Sem esta linha, aqui começaria o laço infinito com fatura.")
            return ("Não consegui responder: a mesma ação foi repetida sem "
                    "progresso.", trajetoria)


PERGUNTA = ("Já passaram 10 dias desde o primeiro dia de aula. Ainda dá tempo de "
            "trancar a disciplina, e quantos dias eu tenho?")

MODOS = {
    "normal": "as cinco peças no lugar",
    "sem-parada": "PEÇA 5 removida do prompt: o modelo nunca encerra",
    "sem-orcamento": "max_passos removido: só o detector de repetição segura",
    "parada-precoce": "regra de parada removida: encerra sem nenhuma observação",
}


def rodar(modo):
    print("=" * 78)
    print(f"MODO --{modo}  ·  {MODOS[modo]}")
    print("=" * 78)
    resposta, trajetoria = loop_agente(PERGUNTA, modo=modo)
    acoes = sum(1 for m in trajetoria if m["papel"] == "acao")
    print(f"RESPOSTA: {resposta}")
    print(f"RESUMO  : {len(trajetoria)} mensagens · {acoes} ação(ões) · "
          f"~{tokens_aprox(trajetoria)} tokens na última chamada\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    for nome in MODOS:
        parser.add_argument(f"--{nome}", action="store_true", help=MODOS[nome])
    parser.add_argument("--todos", action="store_true", help="os quatro modos")
    args = parser.parse_args()

    escolhidos = [n for n in MODOS if getattr(args, n.replace("-", "_"))]
    if args.todos or not escolhidos:
        escolhidos = list(MODOS)
        if not args.todos:
            print("Nenhum modo pedido — rodando os quatro. "
                  "Use --normal, --sem-parada, --sem-orcamento ou --parada-precoce.\n")

    print(f"Python {sys.version.split()[0]} · semente fixa {SEMENTE} · "
          "sem rede, sem dependências\n")
    for modo in escolhidos:
        rodar(modo)
