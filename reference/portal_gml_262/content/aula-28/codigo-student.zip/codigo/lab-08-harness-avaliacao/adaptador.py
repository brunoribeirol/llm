"""Lab 8 · ADAPTADOR — a única peça que muda de projeto para projeto.

O harness inteiro conversa com o sistema da equipe por UMA função: `executar`.
Tudo o mais (métricas, juiz, calibração, relatório) já está escrito e não sabe nada
sobre o seu projeto.

O que fazer aqui:
    1. Importar o seu sistema (o do Lab 5, do Lab 6, do Lab 7, ou o do projeto).
    2. Implementar `executar` devolvendo o dicionário do contrato abaixo.
    3. Preencher `SISTEMA` com a descrição honesta do que está sendo avaliado.

Enquanto o passo 2 não estiver feito, o harness roda com o STUB: um sistema que
recusa tudo. O relatório sai inteiro em zero — e é justamente isso que mostra que o
harness está de pé antes de o seu sistema entrar.

CONTRATO DE `executar(entrada, k)` — devolve um dicionário com:

    resposta        str    o texto que o usuário final leria
    fontes_citadas  list   ids das fontes que a resposta CITA ([] se não cita)
    ranking         list   ids recuperados, em ordem, tamanho >= k ([] se não há
                           camada de retrieval no seu sistema)
    trajetoria      list   um dict por passo: {"passo", "acao", "argumentos", "ok"}
                           ([] se o seu sistema não tem loop)
    parou_por       str    "resposta" | "recusa" | "limite_de_passos" | "erro"
    recusou         bool   True quando o sistema admite que não sabe responder

Regras que o harness assume e que vocês não podem violar:
    - UMA chamada por caso de teste. Nada de chamar o sistema de novo para calcular
      outra métrica: todas as camadas saem desta mesma execução.
    - Chave de API por variável de ambiente ou `getpass`. Nunca no arquivo.
    - Se uma camada não existe no seu projeto, devolva a lista vazia. O harness
      remove essa camada do denominador em vez de contar zero.
"""

import os

# =========================================================================
# TODO 1 — descreva o sistema avaliado
# =========================================================================
# Isto vai no cabeçalho do relatório. Descrição honesta, não peça de marketing:
# quem lê precisa saber o que produziu os números.

SISTEMA = {
    "nome": "TODO: nome do sistema da equipe",
    "camadas": ["retrieval", "resposta", "trajetoria"],   # remova as que não existem
    "gerador": "TODO: modelo e temperatura, ou 'extrativo/determinístico'",
    "juiz": "TODO: heurístico offline, ou modelo e família do LLM-as-judge",
}

# Se o seu sistema usa API, a chave sai daqui. NUNCA hardcoded.
CHAVE_API = os.environ.get("API_KEY", "")


# =========================================================================
# STUB — sistema que recusa tudo. Serve para o harness rodar hoje.
# =========================================================================

def executar_stub(entrada, k=5):
    """Sistema de mentira: recusa qualquer pergunta, não recupera nada.

    Com ele o harness fecha de ponta a ponta e o relatório sai com zero em quase
    tudo — menos em `recusa_correta`, que sai alta porque o stub acerta por acidente
    todos os casos fora do escopo. Esse detalhe é uma lição de graça: métrica isolada
    engana, e é por isso que o relatório exige a tabela inteira.
    """
    return {
        "resposta": "Não consigo responder com esta base.",
        "fontes_citadas": [],
        "ranking": [],
        "trajetoria": [{"passo": 1, "acao": "recusar", "argumentos": {}, "ok": True}],
        "parou_por": "recusa",
        "recusou": True,
    }


# =========================================================================
# TODO 2 — o adaptador de verdade
# =========================================================================

def executar_meu_sistema(entrada, k=5):
    """TODO: chame o SEU sistema aqui e traduza a saída para o contrato do módulo.

    Esqueleto de referência para um projeto de RAG (adapte para o seu caso):

        from meu_projeto import buscar, responder      # o seu código

        trajetoria = []
        ranking = buscar(entrada, k=k)                 # -> lista de ids
        trajetoria.append({"passo": 1, "acao": "buscar",
                           "argumentos": {"consulta": entrada, "k": k},
                           "ok": bool(ranking)})

        saida = responder(entrada, ranking[:3])        # -> texto + fontes
        trajetoria.append({"passo": 2, "acao": "responder",
                           "argumentos": {"fontes": ranking[:3]}, "ok": True})

        return {
            "resposta": saida.texto,
            "fontes_citadas": saida.fontes,
            "ranking": ranking,
            "trajetoria": trajetoria,
            "parou_por": "resposta",
            "recusou": saida.recusou,
        }

    Para projeto de AGENTE, a `trajetoria` é o log real do loop do Lab 7: um dict por
    iteração, com a ação escolhida, os argumentos e se o passo deu certo. É esse log
    que sustenta a métrica de trajetória — sem ele, essa camada não é medível.

    Para projeto SEM retrieval (por exemplo, fine-tuning com avaliação comparativa),
    devolva `ranking=[]` e tire "retrieval" de `SISTEMA["camadas"]`.
    """
    raise NotImplementedError(
        "TODO 2: implemente executar_meu_sistema() e troque a linha "
        "`executar = executar_stub` por `executar = executar_meu_sistema`."
    )


# =========================================================================
# A ligação. Trocar esta linha é o Checkpoint 0 do lab.
# =========================================================================

executar = executar_stub          # TODO: -> executar_meu_sistema


def teste_adaptador(entradas_de_amostra=("pergunta de teste do meu domínio",)):
    """Confere que `executar` respeita o contrato. Roda antes de qualquer métrica."""
    obrigatorias = {"resposta", "fontes_citadas", "ranking", "trajetoria",
                    "parou_por", "recusou"}
    for entrada in entradas_de_amostra:
        saida = executar(entrada, k=3)
        faltando = obrigatorias - set(saida)
        assert not faltando, f"executar() não devolveu as chaves {sorted(faltando)}"
        assert isinstance(saida["resposta"], str), "resposta precisa ser str"
        assert isinstance(saida["fontes_citadas"], list), "fontes_citadas precisa ser list"
        assert isinstance(saida["ranking"], list), "ranking precisa ser list"
        assert isinstance(saida["trajetoria"], list), "trajetoria precisa ser list"
        assert isinstance(saida["recusou"], bool), "recusou precisa ser bool"
        assert saida["parou_por"] in {"resposta", "recusa", "limite_de_passos", "erro"}, \
            f"parou_por inválido: {saida['parou_por']!r}"
    print("Adaptador OK — contrato respeitado.")
    if executar is executar_stub:
        print("  AVISO: ainda rodando com o STUB. O relatório vai sair em zero.")
    return True


if __name__ == "__main__":
    teste_adaptador()
