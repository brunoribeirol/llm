"""Lab 8 · CHECKPOINT 2 — métricas por camada.

A regra da Aula 27: avaliar a menor camada que explica a falha. Aqui ela vira código.
Cada função mede UMA camada e devolve um número entre 0 e 1 — ou `None` quando a
métrica não se aplica àquele caso.

`None` não é zero. Um caso fora do escopo não tem `recall@k`: ele não declara fonte
relevante, então ele sai do denominador em vez de contar como erro. Confundir esses
dois é o erro que mais estraga tabela de avaliação.
"""

import re
import unicodedata


def _sem_acento(texto):
    normal = unicodedata.normalize("NFD", str(texto).lower())
    return "".join(c for c in normal if unicodedata.category(c) != "Mn")


# =========================================================================
# Camada RETRIEVAL
# =========================================================================

def recall_em_k(ranking, relevantes, k):
    """|relevantes ∩ top-k| / |relevantes|. Devolve None se não há relevante declarado.

    TODO 1 — implemente. Duas linhas.
    Cuidado: `relevantes` é uma LISTA porque um caso pode exigir dois dispositivos.
    Recall com denominador 1 é um caso particular, não o caso geral.
    """
    if not relevantes:
        return None
    raise NotImplementedError("TODO 1: recall_em_k")


def precisao_em_k(ranking, relevantes, k):
    """|relevantes ∩ top-k| / k.

    TODO 2 — implemente.
    Pergunta para o relatório: por que `precision@k` cai quando k sobe, mesmo num
    retriever perfeito? A resposta explica por que não se compara precisão entre ks.
    """
    if not relevantes or k == 0:
        return None
    raise NotImplementedError("TODO 2: precisao_em_k")


def rr(ranking, relevantes):
    """Reciprocal rank: 1/posição do primeiro relevante; 0 se nenhum aparece.

    TODO 3 — implemente. A média dos rr sobre os casos é o MRR.
    """
    if not relevantes:
        return None
    raise NotImplementedError("TODO 3: rr")


# =========================================================================
# Camada RESPOSTA
# =========================================================================

def acerto_por_termos(resposta, caso):
    """Todos os `termos_exigidos` aparecem na resposta? 1.0 ou 0.0.

    Grosseira de propósito: não julga qualidade, só presença do fato. É a primeira
    linha de defesa e é o único número da camada de resposta que ninguém pode
    contestar, porque não passa por juiz nenhum.

    TODO 4 — implemente usando `_sem_acento` nos dois lados da comparação.
    """
    if caso["deve_recusar"]:
        return None
    raise NotImplementedError("TODO 4: acerto_por_termos")


def citacao_valida(execucao, caso):
    """A fonte citada está entre as relevantes? 1.0, 0.0 ou None.

    Já implementada: serve de modelo de como ler o dicionário da `execucao`.
    """
    if caso["deve_recusar"]:
        return None
    citadas = set(execucao.get("fontes_citadas") or [])
    if not citadas:
        return 0.0
    return float(bool(citadas & set(caso["fontes_relevantes"])))


def recusa_correta(execucao, caso):
    """Recusou quando devia, e só quando devia. Aplica-se a TODOS os casos.

    TODO 5 — implemente. Uma linha.
    Atenção ao caso que ninguém lembra: recusar uma pergunta que a base cobre é falha
    tão real quanto responder uma que ela não cobre.
    """
    raise NotImplementedError("TODO 5: recusa_correta")


# =========================================================================
# Camada TRAJETÓRIA
# =========================================================================

def trajetoria_bem_formada(execucao, orcamento=6):
    """Sucesso = terminou por decisão própria, dentro do orçamento, sem passo com erro.

    Devolve None quando o sistema não tem loop (trajetória vazia) — projeto sem agente
    não deve ser punido por não ter agente.

    TODO 6 — implemente as três condições:
        dentro   -> número de passos <= orcamento
        sem_erro -> todo passo tem "ok" verdadeiro
        parou_bem-> `parou_por` em {"resposta", "recusa"}
    """
    trajetoria = execucao.get("trajetoria") or []
    if not trajetoria:
        return None
    raise NotImplementedError("TODO 6: trajetoria_bem_formada")


# =========================================================================
# Agregação — já vem escrita
# =========================================================================

def media(valores):
    """Devolve (média, n) ignorando os None. O n é parte da métrica, não enfeite."""
    limpos = [v for v in valores if v is not None]
    if not limpos:
        return (None, 0)
    return (sum(limpos) / len(limpos), len(limpos))


def teste_checkpoint_2():
    """Testes com valores fixos. Passar aqui é o critério do Checkpoint 2."""
    ranking = ["A", "B", "C", "D"]

    assert recall_em_k(ranking, ["B"], 1) == 0.0, "recall@1 com relevante na posição 2"
    assert recall_em_k(ranking, ["B"], 2) == 1.0, "recall@2 com relevante na posição 2"
    assert recall_em_k(ranking, ["A", "C"], 3) == 1.0, "recall@3 com dois relevantes"
    assert recall_em_k(ranking, ["A", "D"], 2) == 0.5, "recall@2 achando 1 de 2"
    assert recall_em_k(ranking, [], 3) is None, "sem relevante -> None, não 0.0"

    assert precisao_em_k(ranking, ["A"], 1) == 1.0
    assert abs(precisao_em_k(ranking, ["A"], 4) - 0.25) < 1e-9
    assert rr(ranking, ["C"]) == 1 / 3, "rr = 1/posição do primeiro relevante"
    assert rr(ranking, ["Z"]) == 0.0, "nenhum relevante no ranking -> 0.0"

    caso_ok = {"deve_recusar": False, "termos_exigidos": ["quinze dias"],
               "fontes_relevantes": ["A"]}
    assert acerto_por_termos("decide em até quinze dias (A)", caso_ok) == 1.0
    assert acerto_por_termos("decide rápido (A)", caso_ok) == 0.0
    assert acerto_por_termos("prazo de QUINZE DIAS", caso_ok) == 1.0, "comparar sem caixa"

    caso_recusa = {"deve_recusar": True, "termos_exigidos": [], "fontes_relevantes": []}
    assert acerto_por_termos("não sei", caso_recusa) is None

    assert recusa_correta({"recusou": True}, caso_recusa) == 1.0
    assert recusa_correta({"recusou": False}, caso_recusa) == 0.0
    assert recusa_correta({"recusou": True}, caso_ok) == 0.0, \
        "recusar pergunta coberta também é falha"

    boa = {"trajetoria": [{"ok": True}, {"ok": True}], "parou_por": "resposta"}
    ruim = {"trajetoria": [{"ok": True}, {"ok": False}], "parou_por": "resposta"}
    estourou = {"trajetoria": [{"ok": True}] * 9, "parou_por": "limite_de_passos"}
    assert trajetoria_bem_formada(boa) == 1.0
    assert trajetoria_bem_formada(ruim) == 0.0
    assert trajetoria_bem_formada(estourou) == 0.0
    assert trajetoria_bem_formada({"trajetoria": [], "parou_por": "resposta"}) is None

    assert media([1.0, 0.0, None]) == (0.5, 2), "None sai do denominador"
    assert media([None, None]) == (None, 0)

    print("Checkpoint 2 OK")
    return True


if __name__ == "__main__":
    teste_checkpoint_2()
