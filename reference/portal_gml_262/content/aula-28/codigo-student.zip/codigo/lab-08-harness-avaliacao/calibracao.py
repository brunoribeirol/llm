"""Lab 8 · CHECKPOINT 4 — calibrar o juiz contra a anotação da equipe.

Um juiz não calibrado não é uma métrica: é uma opinião com aparência de número. Este
checkpoint é o que autoriza vocês a usar o juiz no relatório.

O procedimento, na ordem:
    1. Cada pessoa da equipe anota à mão uma amostra do conjunto de teste, olhando a
       saída real do sistema contra a fonte. Sem olhar o veredito do juiz.
    2. Duas pessoas anotam os MESMOS casos, para medir o kappa entre humanos primeiro.
       Esse número é a referência: exigir do juiz mais acordo do que dois humanos
       conseguem entre si é exigir do juiz mais do que a tarefa permite.
    3. Rodar o juiz nos mesmos casos e medir o kappa juiz × humano.
    4. Ler os desacordos UM POR UM. É aqui que o lab acontece — na maioria das vezes o
       conserto é a rubrica, não o modelo.

Por que kappa e não acordo bruto: se 90% das respostas do sistema estão corretas, dois
anotadores que marcam "aprovada" no automático concordam em 90% sem ter lido nada. O
kappa desconta esse acaso e nesse caso dá zero.

    κ = (p_o − p_e) / (1 − p_e)          p_e = Σ_c P₁(c) · P₂(c)
"""

from collections import Counter

# =========================================================================
# TODO 1 — a anotação humana da equipe
# =========================================================================
# id do caso -> "aprovada" | "reprovada", olhando a SAÍDA REAL do sistema.
#
# Mínimo do lab: 12 casos, e a amostra tem de incluir os casos de FRONTEira — aqueles
# em que a equipe hesitou. Calibrar só em caso óbvio produz kappa alto e inútil,
# porque a decisão do relatório é tomada justamente nos casos difíceis.
#
# Escreva o motivo em comentário ao lado de cada "reprovada". No Checkpoint 4 vocês
# vão precisar desse motivo para decidir se o desacordo é da rubrica ou do sistema.

ANOTACAO_HUMANA = {
    # "c01": "aprovada",
    # "c02": "reprovada",   # recuperou a fonte certa e devolveu a frase errada
}

# Opcional e recomendado: a mesma amostra anotada por uma SEGUNDA pessoa da equipe.
# Com ela, `kappa_entre_humanos()` devolve a referência do passo 2 acima.
ANOTACAO_HUMANA_2 = {}


# =========================================================================
# As contas — já vêm escritas, menos o kappa
# =========================================================================

def matriz_confusao(pares):
    """pares: lista de (rotulo_1, rotulo_2)."""
    return Counter(pares)


def acordo_bruto(pares):
    if not pares:
        return 0.0
    return sum(1 for a, b in pares if a == b) / len(pares)


def kappa_cohen(pares):
    """TODO 2 — implemente o kappa de Cohen.

    Passos:
        n           = número de pares
        p_o         = acordo_bruto(pares)
        marginal_1  = Counter dos rótulos do anotador 1
        marginal_2  = Counter dos rótulos do anotador 2
        p_e         = soma, sobre cada classe c, de (marginal_1[c]/n) * (marginal_2[c]/n)
        κ           = (p_o − p_e) / (1 − p_e)

    Cuidado com a divisão por zero: se os dois anotadores usaram uma classe só,
    `p_e` é 1 e o kappa não é definido. Devolva 0.0 nesse caso — e entenda o que
    aconteceu: concordância degenerada, a anotação não discriminou nada.
    """
    if not pares:
        return 0.0
    raise NotImplementedError("TODO 2: kappa_cohen")


def kappa_entre_humanos(anotacao_1=None, anotacao_2=None):
    """A referência do passo 2: quanto dois humanos concordam nesta tarefa."""
    anotacao_1 = ANOTACAO_HUMANA if anotacao_1 is None else anotacao_1
    anotacao_2 = ANOTACAO_HUMANA_2 if anotacao_2 is None else anotacao_2
    comuns = sorted(set(anotacao_1) & set(anotacao_2))
    if not comuns:
        return None
    pares = [(anotacao_1[cid], anotacao_2[cid]) for cid in comuns]
    return {"n": len(pares), "acordo_bruto": acordo_bruto(pares),
            "kappa": kappa_cohen(pares)}


def calibrar(resultados, anotacao=None):
    """Compara o veredito do juiz com o rótulo humano na amostra anotada.

    `resultados` é a lista produzida pelo runner: cada item tem "caso", "execucao" e
    "juiz". Só os casos presentes em `anotacao` entram na conta.
    """
    anotacao = ANOTACAO_HUMANA if anotacao is None else anotacao
    pares, desacordos = [], []
    for resultado in resultados:
        cid = resultado["caso"]["id"]
        if cid not in anotacao:
            continue
        humano, maquina = anotacao[cid], resultado["juiz"]["veredito"]
        pares.append((humano, maquina))
        if humano != maquina:
            desacordos.append({
                "id": cid,
                "humano": humano,
                "juiz": maquina,
                "nota_juiz": resultado["juiz"]["nota"],
                "justificativa": resultado["juiz"]["justificativa"],
                "resposta": resultado["execucao"]["resposta"],
            })
    return {
        "n": len(pares),
        "cobertura": len(pares) / len(resultados) if resultados else 0.0,
        "acordo_bruto": acordo_bruto(pares),
        "kappa": kappa_cohen(pares),
        "matriz": matriz_confusao(pares),
        "desacordos": desacordos,
    }


def teste_checkpoint_4():
    """Três cenários canônicos. Se os três passarem, o kappa está correto."""
    perfeito = [("aprovada", "aprovada")] * 6 + [("reprovada", "reprovada")] * 6
    assert abs(kappa_cohen(perfeito) - 1.0) < 1e-9, "acordo total -> κ = 1"

    # o caso do slide 6 da Aula 27: dois anotadores automáticos, tarefa 90/10
    preguicosos = [("aprovada", "aprovada")] * 9 + [("reprovada", "aprovada")]
    assert abs(kappa_cohen(preguicosos)) < 1e-9, \
        "acordo bruto 0,90 com κ = 0: eles coincidiram, não concordaram"
    assert abs(acordo_bruto(preguicosos) - 0.9) < 1e-9

    # discordância total é kappa negativo — pior que sorteio
    invertido = [("aprovada", "reprovada")] * 5 + [("reprovada", "aprovada")] * 5
    assert kappa_cohen(invertido) < 0, "discordância sistemática -> κ negativo"

    # caso intermediário, com número conferível à mão
    misto = ([("aprovada", "aprovada")] * 4 + [("reprovada", "reprovada")] * 6
             + [("reprovada", "aprovada")] * 2)
    # p_o = 10/12; marginais humano 4/12 e 8/12, juiz 6/12 e 6/12
    # p_e = (4/12)(6/12) + (8/12)(6/12) = 0,5  ->  κ = (0,8333 − 0,5)/0,5 = 0,6667
    assert abs(kappa_cohen(misto) - 2 / 3) < 1e-6, "conta do caso intermediário"

    assert len(ANOTACAO_HUMANA) >= 12, \
        (f"ANOTACAO_HUMANA tem {len(ANOTACAO_HUMANA)} casos; o mínimo do lab é 12, "
         "incluindo os casos de fronteira")

    print("Checkpoint 4 OK")
    return True


if __name__ == "__main__":
    teste_checkpoint_4()
