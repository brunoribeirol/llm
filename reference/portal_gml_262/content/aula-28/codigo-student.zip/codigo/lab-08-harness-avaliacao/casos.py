"""Lab 8 · CHECKPOINT 1 — o conjunto de teste.

O conjunto de teste é o artefato mais valioso deste lab. Ele sobrevive ao modelo, ao
framework e ao prompt de vocês: quando qualquer um desses trocar, é ele que diz se
melhorou. Vinte casos é o mínimo do lab, não a meta.

ESQUEMA DE UM CASO

    id                 str   identificador estável (c01, c02...). A análise de falhas
                             cita por id, então id não muda depois de escrito.
    entrada            str   o que entra no sistema, escrito como o USUÁRIO escreveria
                             — com erro de digitação, gíria e pergunta dupla, se for
                             assim que ele escreve.
    categoria          str   uma de CATEGORIAS_VALIDAS. Serve para a tabela de falha
                             por categoria: é ela que mostra que o sistema vai bem no
                             fácil e mal no que importa.
    referencia         str   o que uma resposta correta precisa afirmar. Curto. Não é
                             a resposta ideal redigida — é o conteúdo obrigatório.
    termos_exigidos    list  termos/números que a resposta correta contém. É a métrica
                             mais barata que existe e ela não passa por juiz nenhum.
                             Use a forma sem acento; a comparação normaliza.
    fontes_relevantes  list  ids que o retrieval DEVE trazer. [] para caso fora do
                             escopo. Sem isto não existe recall@k.
    deve_recusar       bool  True quando a resposta correta é admitir a lacuna.
    nota               str   por que este caso está no conjunto. Um caso sem essa
                             frase costuma ser um caso redundante.

REGRA DE COMPOSIÇÃO (o que separa conjunto bom de conjunto inútil)

    - Nunca só casos fáceis. Se o sistema acerta 100%, o conjunto está errado.
    - No mínimo 3 casos FORA DO ESCOPO. Sem eles não se mede recusa, e recusa é
      metade da qualidade de um sistema com citação.
    - No mínimo 3 categorias diferentes.
    - Inclua os casos que vocês já viram falhar. Um bug que não entra no conjunto de
      teste volta.
    - Escreva o caso ANTES de olhar a saída do sistema. Caso escrito depois tende a
      ser escrito para passar.
"""

CATEGORIAS_VALIDAS = {
    "fato_simples",        # um fato, uma fonte
    "multi_dispositivo",   # exige combinar duas ou mais fontes
    "fora_do_escopo",      # a base não cobre: a resposta correta é admitir
    "parafrase",           # o usuário usa outro vocabulário que o da fonte
    "adversarial",         # injeção, pergunta capciosa, instrução contraditória
}


# =========================================================================
# TODO 1 — escreva os 20+ casos do SEU projeto
# =========================================================================
# Os três casos abaixo são só o formato preenchido. Apague-os e escreva os seus.
# Sugestão de distribuição para 20 casos: 8 fato_simples, 3 multi_dispositivo,
# 4 parafrase, 4 fora_do_escopo, 1 adversarial.

CASOS = [
    {
        "id": "c01",
        "categoria": "fato_simples",
        "entrada": "TODO: uma pergunta do seu domínio com resposta única e verificável",
        "referencia": "TODO: o que a resposta correta precisa afirmar",
        "termos_exigidos": ["TODO"],
        "fontes_relevantes": ["TODO: id da fonte no seu corpus"],
        "deve_recusar": False,
        "nota": "TODO: por que este caso existe",
    },
    {
        "id": "c02",
        "categoria": "parafrase",
        "entrada": "TODO: a mesma pergunta do c01 com o vocabulário do usuário, não o "
                   "da fonte",
        "referencia": "TODO: a mesma referência do c01",
        "termos_exigidos": ["TODO"],
        "fontes_relevantes": ["TODO: a mesma fonte do c01"],
        "deve_recusar": False,
        "nota": "Par de paráfrase: se c01 passa e c02 falha, a falha é do retrieval, e "
                "o par prova isso sem precisar de mais nada.",
    },
    {
        "id": "c03",
        "categoria": "fora_do_escopo",
        "entrada": "TODO: pergunta plausível no seu domínio que a sua base NÃO cobre",
        "referencia": "A base não trata desse assunto.",
        "termos_exigidos": [],
        "fontes_relevantes": [],
        "deve_recusar": True,
        "nota": "Lacuna real. O melhor caso desta família é o que usa uma palavra que "
                "aparece na base num sentido diferente — assim ele engana o retrieval.",
    },
]


# =========================================================================
# Validador — já vem escrito. O Checkpoint 1 fecha quando ele passa.
# =========================================================================

def validar_conjunto(casos, corpus_ids=None, minimo=20):
    """Devolve a lista de problemas do conjunto. Lista vazia = conjunto válido.

    `corpus_ids` é o conjunto de ids válidos do seu corpus. Se vocês passarem None, a
    checagem de fonte inexistente é pulada — e vocês perdem o erro mais comum do
    checkpoint, que é escrever `Art. 42 §1` onde o corpus tem `Art. 42 § 1º`.
    """
    from collections import Counter

    problemas = []
    if len(casos) < minimo:
        problemas.append(f"conjunto tem {len(casos)} casos; o mínimo do lab é {minimo}")

    vistos = set()
    for caso in casos:
        cid = caso.get("id", "<sem id>")
        if cid in vistos:
            problemas.append(f"{cid}: id duplicado")
        vistos.add(cid)

        for campo in ("entrada", "categoria", "referencia", "fontes_relevantes",
                      "deve_recusar", "termos_exigidos"):
            if campo not in caso:
                problemas.append(f"{cid}: falta o campo '{campo}'")

        if caso.get("categoria") not in CATEGORIAS_VALIDAS:
            problemas.append(f"{cid}: categoria '{caso.get('categoria')}' fora do vocabulário")

        if "TODO" in str(caso.get("entrada", "")):
            problemas.append(f"{cid}: ainda é o exemplo do template (contém TODO)")

        if corpus_ids is not None:
            for fonte in caso.get("fontes_relevantes", []):
                if fonte not in corpus_ids:
                    problemas.append(f"{cid}: fonte '{fonte}' não existe no corpus")

        if caso.get("deve_recusar") and caso.get("fontes_relevantes"):
            problemas.append(f"{cid}: marcado para recusar mas declara fonte relevante")
        if not caso.get("deve_recusar") and not caso.get("fontes_relevantes"):
            problemas.append(f"{cid}: não recusa e não declara nenhuma fonte relevante")

    distribuicao = Counter(caso.get("categoria") for caso in casos)
    if distribuicao.get("fora_do_escopo", 0) < 3:
        problemas.append("menos de 3 casos fora do escopo: o conjunto não mede recusa")
    if len(distribuicao) < 3:
        problemas.append("menos de 3 categorias: conjunto pouco diverso")

    return problemas


def teste_checkpoint_1(corpus_ids=None):
    from collections import Counter

    problemas = validar_conjunto(CASOS, corpus_ids=corpus_ids)
    distribuicao = Counter(caso.get("categoria") for caso in CASOS)
    print(f"{len(CASOS)} casos · " +
          " · ".join(f"{cat}={n}" for cat, n in sorted(distribuicao.items())))
    if problemas:
        print("Checkpoint 1 PENDENTE:")
        for problema in problemas:
            print(f"  - {problema}")
        return False
    print("Checkpoint 1 OK")
    return True


if __name__ == "__main__":
    teste_checkpoint_1()
