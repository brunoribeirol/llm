"""Lab 8 · CHECKPOINT 5 — runner, análise de falhas, priorização e relatório.

Este é o arquivo que se roda:

    python rodar.py                  # tudo, e escreve relatorio-avaliacao.md
    python rodar.py --testes         # só os testes dos checkpoints 1 a 4
    python rodar.py --juiz llm       # usa LLM-as-judge em vez do heurístico
    python rodar.py --sem-relatorio

O entregável do lab é o `relatorio-avaliacao.md` que sai daqui, com número por camada.
"O sistema respondeu bem" não é resultado. `recall@3 = 0,88 sobre 17 casos` é.
"""

import argparse
import os
import sys
from collections import Counter, defaultdict

import adaptador
import calibracao as calib
import casos as mod_casos
import judge
import metricas as met


# =========================================================================
# Runner — uma chamada ao sistema por caso, todas as camadas da mesma execução
# =========================================================================

def rodar_conjunto(lista_casos, julgar, ks=(1, 3)):
    resultados = []
    for caso in lista_casos:
        execucao = adaptador.executar(caso["entrada"], k=max(ks))
        resultados.append({
            "caso": caso,
            "execucao": execucao,
            "recall": {k: met.recall_em_k(execucao["ranking"], caso["fontes_relevantes"], k)
                       for k in ks},
            "precisao": {k: met.precisao_em_k(execucao["ranking"],
                                              caso["fontes_relevantes"], k) for k in ks},
            "rr": met.rr(execucao["ranking"], caso["fontes_relevantes"]),
            "acerto": met.acerto_por_termos(execucao["resposta"], caso),
            "citacao": met.citacao_valida(execucao, caso),
            "recusa": met.recusa_correta(execucao, caso),
            "trajetoria_ok": met.trajetoria_bem_formada(execucao),
            "juiz": julgar(caso, execucao),
        })
    return resultados


def metricas_por_camada(resultados, ks=(1, 3)):
    """camada -> métrica -> (valor, n). O n é parte da métrica."""
    tabela = defaultdict(dict)
    for k in ks:
        tabela["retrieval"][f"recall@{k}"] = met.media([r["recall"][k] for r in resultados])
        tabela["retrieval"][f"precision@{k}"] = met.media(
            [r["precisao"][k] for r in resultados])
    tabela["retrieval"]["MRR"] = met.media([r["rr"] for r in resultados])

    tabela["resposta"]["acerto_por_termos"] = met.media([r["acerto"] for r in resultados])
    tabela["resposta"]["citacao_valida"] = met.media([r["citacao"] for r in resultados])
    tabela["resposta"]["recusa_correta"] = met.media([r["recusa"] for r in resultados])
    tabela["resposta"]["nota_juiz_media"] = met.media([r["juiz"]["nota"] for r in resultados])
    tabela["resposta"]["aprovacao_juiz"] = met.media(
        [float(r["juiz"]["veredito"] == "aprovada") for r in resultados])

    tabela["trajetoria"]["sucesso"] = met.media([r["trajetoria_ok"] for r in resultados])
    tabela["trajetoria"]["passos_media"] = met.media(
        [float(len(r["execucao"]["trajetoria"])) for r in resultados])
    return dict(tabela)


# =========================================================================
# Análise de falhas — a regra da Aula 27 em código
# =========================================================================

def classificar_falha(resultado, k_referencia=3):
    """TODO 1 — devolva (camada, motivo) da MENOR camada que explica a falha, ou None.

    A ordem dos testes é a ordem da pilha, de baixo para cima, e o PRIMEIRO que falha é
    o responsável. É isso que impede o relatório de culpar o gerador por um erro do
    retriever. Ordem sugerida:

        0. juiz aprovou           -> None (não é falha)
        1. recall incompleto      -> ("retrieval", "não recuperou X no top-k")
        2. recusa errada, nos dois sentidos
                                  -> ("escopo", "respondeu o que a base não cobre")
                                  -> ("escopo", "recusou o que a base cobre")
        3. citação inválida       -> ("citacao", "citou fonte que não sustenta")
        4. fato ausente           -> ("geracao", "tinha a fonte e não extraiu o fato")
        5. trajetória mal formada -> ("trajetoria", ...)
        6. sobrou                 -> ("resposta", justificativa do juiz)

    Cuidado com o `None` das métricas: `recall` é None em caso fora do escopo, e
    `None < 1.0` levanta TypeError em Python 3. Teste o None antes de comparar.
    """
    if resultado["juiz"]["veredito"] == "aprovada":
        return None
    raise NotImplementedError("TODO 1: classificar_falha")


def analisar_falhas(resultados):
    por_camada = defaultdict(list)
    por_categoria = defaultdict(lambda: {"total": 0, "falhas": 0})
    for resultado in resultados:
        categoria = resultado["caso"]["categoria"]
        por_categoria[categoria]["total"] += 1
        falha = classificar_falha(resultado)
        if falha:
            camada, motivo = falha
            por_categoria[categoria]["falhas"] += 1
            por_camada[camada].append({
                "id": resultado["caso"]["id"],
                "categoria": categoria,
                "motivo": motivo,
                "entrada": resultado["caso"]["entrada"],
                "resposta": resultado["execucao"]["resposta"],
            })
    return dict(por_camada), dict(por_categoria)


# =========================================================================
# TODO 2 — o custo estimado de consertar cada camada NO SEU projeto
# =========================================================================
# Escala 1 (barato: mudar um limiar, um prompt) a 3 (caro: trocar o modelo, refazer o
# pipeline). É estimativa DECLARADA da equipe, não medida — e é ela que transforma a
# tabela de falhas num plano de trabalho.

CUSTO_CONSERTO = {
    "retrieval": 2,
    "escopo": 1,
    "citacao": 1,
    "geracao": 3,
    "trajetoria": 2,
    "resposta": 2,
}


def priorizar(por_camada, total_casos):
    """Ordena os consertos por impacto/custo."""
    linhas = []
    for camada, falhas in por_camada.items():
        impacto = len(falhas) / total_casos if total_casos else 0.0
        custo = CUSTO_CONSERTO.get(camada, 2)
        linhas.append({"camada": camada, "casos": len(falhas), "impacto": impacto,
                       "custo": custo, "prioridade": impacto / custo,
                       "ids": [f["id"] for f in falhas]})
    linhas.sort(key=lambda linha: -linha["prioridade"])
    return linhas


# =========================================================================
# Relatório
# =========================================================================

def _fmt(valor):
    if valor is None:
        return "—"
    return f"{valor:.2f}" if isinstance(valor, float) else str(valor)


def gerar_relatorio(resultados, tabela, calibragem, por_camada, por_categoria,
                    prioridades, caminho):
    total = len(resultados)
    linhas = []
    ad = linhas.append

    ad("# Relatório de avaliação — Lab 8")
    ad("")
    ad(f"**Sistema avaliado:** {adaptador.SISTEMA['nome']}  ")
    ad(f"**Gerador:** {adaptador.SISTEMA['gerador']}  ")
    ad(f"**Juiz:** {adaptador.SISTEMA['juiz']}  ")
    ad(f"**Camadas medidas:** {', '.join(adaptador.SISTEMA['camadas'])}  ")
    ad(f"**Casos de teste:** {total}")
    ad("")
    ad(f"> {judge.ADVERTENCIA_JUIZ}")
    ad("")

    ad("## 1. Métricas por camada")
    ad("")
    ad("| Camada | Métrica | Valor | n |")
    ad("|---|---|---|---|")
    for camada, valores in tabela.items():
        for nome, (valor, n) in valores.items():
            ad(f"| {camada} | `{nome}` | {_fmt(valor)} | {n} |")
    ad("")
    ad("TODO: um parágrafo lendo esta tabela. Qual camada é o gargalo, e como vocês "
       "sabem que é ela e não a de cima.")
    ad("")

    ad("## 2. Calibração do juiz")
    ad("")
    ad(f"- Amostra anotada à mão: **{calibragem['n']} casos** "
       f"({calibragem['cobertura']:.0%} do conjunto).")
    ad(f"- Acordo bruto: **{calibragem['acordo_bruto']:.2f}**")
    ad(f"- Kappa de Cohen: **{calibragem['kappa']:.2f}**")
    entre_humanos = calib.kappa_entre_humanos()
    if entre_humanos:
        ad(f"- Kappa entre dois humanos da equipe (a referência): "
           f"**{entre_humanos['kappa']:.2f}** sobre {entre_humanos['n']} casos")
    ad("")
    ad("| humano | juiz | casos |")
    ad("|---|---|---|")
    for (humano, maquina), quantos in sorted(calibragem["matriz"].items()):
        ad(f"| {humano} | {maquina} | {quantos} |")
    ad("")
    if calibragem["desacordos"]:
        ad("### Desacordos, um por um")
        ad("")
        for d in calibragem["desacordos"]:
            ad(f"- **{d['id']}** — humano: `{d['humano']}`, juiz: `{d['juiz']}` "
               f"(nota {d['nota_juiz']:.0f}/{judge.NOTA_MAXIMA}). "
               f"Juiz alegou: {d['justificativa']}")
            ad(f"  - resposta: \"{d['resposta']}\"")
            ad("  - TODO: o conserto é na RUBRICA ou no SISTEMA? Justifique.")
    else:
        ad("Sem desacordos na amostra. Com amostra pequena isso é motivo de suspeita, "
           "não de comemoração: provavelmente a amostra não inclui casos de fronteira.")
    ad("")

    ad("## 3. Falhas por camada — a menor camada que explica")
    ad("")
    for camada, falhas in sorted(por_camada.items(), key=lambda item: -len(item[1])):
        ad(f"### {camada} — {len(falhas)} de {total} casos")
        ad("")
        for falha in falhas:
            ad(f"- `{falha['id']}` ({falha['categoria']}) — {falha['motivo']}")
            ad(f"  - entrada: \"{falha['entrada']}\"")
            ad(f"  - resposta: \"{falha['resposta']}\"")
        ad("")

    ad("## 4. Falhas por categoria de caso")
    ad("")
    ad("| Categoria | Casos | Falhas | Taxa |")
    ad("|---|---|---|---|")
    for categoria, dados in sorted(por_categoria.items()):
        taxa = dados["falhas"] / dados["total"] if dados["total"] else 0.0
        ad(f"| {categoria} | {dados['total']} | {dados['falhas']} | {taxa:.0%} |")
    ad("")

    ad("## 5. Priorização dos consertos")
    ad("")
    ad("Impacto = fração de casos que a camada explica. Custo é estimativa declarada da "
       "equipe (1 barato, 3 caro). Prioridade = impacto / custo.")
    ad("")
    ad("| # | Camada | Casos | Impacto | Custo | Prioridade | IDs |")
    ad("|---|---|---|---|---|---|---|")
    for posicao, linha in enumerate(prioridades, start=1):
        ad(f"| {posicao} | {linha['camada']} | {linha['casos']} | {linha['impacto']:.0%} | "
           f"{linha['custo']} | {linha['prioridade']:.2f} | {', '.join(linha['ids'])} |")
    ad("")
    ad("TODO: o que a equipe vai consertar antes da entrega final, e o que fica "
       "declarado como limitação conhecida.")
    ad("")

    ad("## 6. Limitações desta avaliação")
    ad("")
    ad("TODO: escreva as limitações reais. Quatro que quase sempre se aplicam:")
    ad(f"- Conjunto de {total} casos escrito pela própria equipe: mede o que a equipe "
       "imaginou, e nada do que ela não imaginou.")
    ad(f"- Anotação humana de {calibragem['n']} casos, feita por quem construiu o "
       "sistema: há risco de viés de expectativa.")
    ad("- Número de execuções por caso, e se há variância a reportar.")
    ad("- Vieses do juiz que ficaram sem medição.")

    with open(caminho, "w", encoding="utf-8", newline="\n") as arquivo:
        arquivo.write("\n".join(linhas) + "\n")
    return caminho


# =========================================================================
# main
# =========================================================================

def rodar_testes():
    """Checkpoints 1 a 4 na ordem. Para no primeiro que não passa."""
    etapas = [
        ("adaptador", adaptador.teste_adaptador),
        ("Checkpoint 1 · conjunto de teste", mod_casos.teste_checkpoint_1),
        ("Checkpoint 2 · métricas por camada", met.teste_checkpoint_2),
        ("Checkpoint 3 · juiz com rubrica", judge.teste_checkpoint_3),
        ("Checkpoint 4 · calibração", calib.teste_checkpoint_4),
    ]
    for nome, teste in etapas:
        print(f"\n--- {nome}")
        try:
            if teste() is False:
                return False
        except (NotImplementedError, AssertionError) as erro:
            print(f"  PENDENTE: {erro}")
            return False
    print("\nTodos os checkpoints de 1 a 4 passaram.")
    return True


def teste_checkpoint_5(caminho):
    """O CP5 fecha quando o relatório existe e tem as cinco seções com número."""
    assert os.path.exists(caminho), "o relatório não foi escrito"
    with open(caminho, encoding="utf-8") as arquivo:
        texto = arquivo.read()
    for secao in ("Métricas por camada", "Calibração do juiz", "Falhas por camada",
                  "Falhas por categoria", "Priorização"):
        assert secao in texto, f"o relatório não tem a seção '{secao}'"
    assert "recall@" in texto or "retrieval" not in adaptador.SISTEMA["camadas"], \
        "sistema com retrieval e relatório sem recall@k"
    assert "Kappa de Cohen" in texto, "relatório sem a concordância do juiz"
    print("Checkpoint 5 OK")
    return True


def main():
    parser = argparse.ArgumentParser(description="Harness de avaliação — Lab 8")
    parser.add_argument("--testes", action="store_true",
                        help="roda só os testes dos checkpoints 1 a 4")
    parser.add_argument("--juiz", choices=["heuristico", "llm"], default="heuristico")
    parser.add_argument("--sem-relatorio", action="store_true")
    args = parser.parse_args()

    print()
    print("=" * 64)
    print("  Lab 8 — harness de avaliação do projeto")
    print("=" * 64)
    print(f"  sistema: {adaptador.SISTEMA['nome']}")
    print(f"  camadas: {', '.join(adaptador.SISTEMA['camadas'])}")

    if args.testes:
        return 0 if rodar_testes() else 1

    if not rodar_testes():
        print("\nCorrija o checkpoint pendente antes de rodar o conjunto inteiro.")
        return 1

    julgar = judge.juiz_llm if args.juiz == "llm" else judge.juiz_heuristico
    resultados = rodar_conjunto(mod_casos.CASOS, julgar)

    print("\n  [CP2] métricas por camada")
    tabela = metricas_por_camada(resultados)
    print()
    print("  camada        métrica                valor   sobre n casos")
    print("  " + "-" * 56)
    for camada, valores in tabela.items():
        for nome, (valor, n) in valores.items():
            print(f"  {camada:<12}  {nome:<21}  {_fmt(valor):>5}   {n}")

    print("\n  [CP4] calibração contra a anotação humana")
    calibragem = calib.calibrar(resultados)
    print(f"    amostra: {calibragem['n']} casos ({calibragem['cobertura']:.0%})")
    print(f"    acordo bruto: {calibragem['acordo_bruto']:.2f}")
    print(f"    KAPPA DE COHEN: {calibragem['kappa']:.2f}")
    for desacordo in calibragem["desacordos"]:
        print(f"      {desacordo['id']}  humano={desacordo['humano']:<10} "
              f"juiz={desacordo['juiz']}")

    print("\n  [CP5] análise de falhas e priorização")
    por_camada, por_categoria = analisar_falhas(resultados)
    prioridades = priorizar(por_camada, len(resultados))
    print()
    print("    camada        casos  impacto  custo  prioridade")
    print("    " + "-" * 48)
    for linha in prioridades:
        print(f"    {linha['camada']:<12}  {linha['casos']:>5}  {linha['impacto']:>6.0%}"
              f"  {linha['custo']:>5}  {linha['prioridade']:>10.2f}")

    if not args.sem_relatorio:
        destino = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "relatorio-avaliacao.md")
        gerar_relatorio(resultados, tabela, calibragem, por_camada, por_categoria,
                        prioridades, destino)
        print(f"\n  relatório escrito em: {os.path.basename(destino)}")
        teste_checkpoint_5(destino)

    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
