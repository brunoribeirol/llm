"""Lab 8 · CHECKPOINT 3 — juiz com rubrica.

Duas rotas, e o harness funciona com as duas:

    juiz_heuristico   determinístico, offline, sem chave. Aplica a rubrica por regra.
    juiz_llm          LLM-as-judge por HTTP, chave por ambiente ou getpass.

A rota heurística existe porque o lab tem de fechar sem rede. Ela não é um LLM e o
relatório precisa dizer isso — está em `ADVERTENCIA_JUIZ`. A rota LLM é a que vocês
vão querer no projeto, e ela só vale depois de calibrada (Checkpoint 4).

A rubrica é o instrumento. Se dois anotadores discordam, o defeito está aqui, não nas
pessoas: nível descrito por COMPORTAMENTO OBSERVÁVEL, nunca por adjetivo. "Cita o
dispositivo correto" discrimina. "Boa" não discrimina.
"""

import json
import os
import re
import unicodedata
import urllib.error
import urllib.request

# =========================================================================
# TODO 1 — a rubrica do SEU projeto
# =========================================================================
# Três critérios, três níveis (0, 1, 2). Três é o teto do que duas pessoas
# distinguem de forma reprodutível; escala de 1 a 10 é ilusão de precisão.
#
# Os critérios abaixo servem para sistema com citação de fonte. Se o seu projeto é
# outra coisa (tutor socrático, triagem de issues, agente de dados), troque os três
# critérios pelo que decide a qualidade NO SEU domínio — e mantenha a forma.

RUBRICA = {
    "correcao": {
        "descricao": "A resposta afirma o que a fonte afirma.",
        2: "Todos os fatos pedidos estão corretos e completos.",
        1: "O fato principal está correto, falta um detalhe pedido.",
        0: "Contradiz a fonte, inventa informação ou deixa a pergunta sem resposta.",
    },
    "ancoragem": {
        "descricao": "A resposta cita a fonte de onde o fato saiu.",
        2: "Cita a fonte correta.",
        1: "Cita fonte relacionada, mas não a que sustenta o fato.",
        0: "Não cita, ou cita fonte que não sustenta nada do que foi dito.",
    },
    "escopo": {
        "descricao": "A resposta admite a lacuna quando a base não cobre a pergunta.",
        2: "Admite a lacuna quando devia, e não admite quando não devia.",
        1: "Responde com ressalva onde devia recusar de forma limpa.",
        0: "Inventa resposta fora do escopo, ou recusa pergunta que a base cobre.",
    },
}

NOTA_MAXIMA = 2 * len(RUBRICA)
LIMIAR_APROVACAO = 5        # TODO: justifique este número no relatório

ADVERTENCIA_JUIZ = (
    "TODO: uma frase declarando QUEM julgou. Se for o juiz heurístico: 'juiz "
    "heurístico determinístico, não LLM, aplica a rubrica por regra'. Se for LLM: "
    "modelo, família, temperatura e a rubrica literal usada no prompt."
)


def _sem_acento(texto):
    normal = unicodedata.normalize("NFD", str(texto).lower())
    return "".join(c for c in normal if unicodedata.category(c) != "Mn")


# =========================================================================
# Rota A — juiz heurístico (offline, determinístico)
# =========================================================================

def juiz_heuristico(caso, execucao):
    """Aplica a RUBRICA por regra. Devolve notas, total, veredito e justificativa.

    TODO 2 — implemente os três critérios. O de `escopo` já está pronto como modelo.

    Contrato de retorno (o resto do harness depende dele):
        {"notas": {"correcao": 0..2, "ancoragem": 0..2, "escopo": 0..2},
         "nota": float, "veredito": "aprovada"|"reprovada", "justificativa": str}

    A justificativa não é enfeite: é ela que vocês vão ler um por um no Checkpoint 4
    para descobrir se o desacordo com o humano é defeito da rubrica ou do sistema.
    """
    texto = _sem_acento(execucao.get("resposta", ""))
    citadas = set(execucao.get("fontes_citadas") or [])
    relevantes = set(caso["fontes_relevantes"])
    notas, motivos = {}, []

    # --- correção  (TODO 2a)
    # Caso deve_recusar: 2 se recusou, 0 se não recusou.
    # Caso normal: 2 se todos os termos_exigidos aparecem, 1 se alguns, 0 se nenhum.
    raise NotImplementedError("TODO 2a: critério de correção")

    # --- ancoragem  (TODO 2b)
    # Caso deve_recusar: 2 se NÃO citou nada, 0 se citou (citar fonte para pergunta
    # sem base é pior que não responder).
    # Caso normal: 2 se citadas ∩ relevantes, 1 se citou outra coisa, 0 se não citou.

    # --- escopo  (pronto, serve de modelo)
    notas["escopo"] = 2.0 if bool(execucao.get("recusou")) == caso["deve_recusar"] else 0.0
    if notas["escopo"] == 0.0:
        motivos.append("devia admitir a lacuna e não admitiu" if caso["deve_recusar"]
                       else "recusou pergunta que a base cobre")

    total = sum(notas.values())
    return {
        "notas": notas,
        "nota": total,
        "veredito": "aprovada" if total >= LIMIAR_APROVACAO else "reprovada",
        "justificativa": "; ".join(motivos) or "atende os três critérios",
    }


# =========================================================================
# Rota B — LLM-as-judge
# =========================================================================

URL_API = "https://api.groq.com/openai/v1/chat/completions"
MODELO_JUIZ = os.environ.get("MODELO_JUIZ", "llama-3.3-70b-versatile")
TIMEOUT_S = 60


def obter_chave():
    """Chave por ambiente ou getpass. NUNCA no arquivo, nunca no notebook."""
    chave = os.environ.get("API_KEY", "").strip()
    if chave:
        return chave
    try:
        from getpass import getpass
        return getpass("Chave da API (não é exibida, não é gravada): ").strip()
    except Exception:
        return ""


def _prompt_juiz(caso, execucao):
    criterios = "\n".join(
        f"  {nome}: {niveis['descricao']}\n"
        f"     2 = {niveis[2]}\n     1 = {niveis[1]}\n     0 = {niveis[0]}"
        for nome, niveis in RUBRICA.items()
    )
    return (
        "Você é um avaliador. Pontue a RESPOSTA segundo a rubrica, critério por "
        "critério.\n\n"
        f"RUBRICA:\n{criterios}\n\n"
        f"PERGUNTA: {caso['entrada']}\n"
        f"O QUE UMA RESPOSTA CORRETA PRECISA AFIRMAR: {caso['referencia']}\n"
        f"FONTES CITADAS PELA RESPOSTA: {execucao.get('fontes_citadas') or 'nenhuma'}\n"
        f"RESPOSTA:\n{execucao.get('resposta', '')}\n\n"
        "Responda APENAS com JSON: "
        '{"correcao": 0|1|2, "ancoragem": 0|1|2, "escopo": 0|1|2, "motivo": "..."}'
    )


def juiz_llm(caso, execucao, chave=None, temperatura=0.0):
    """LLM-as-judge com a mesma rubrica. Cai para o heurístico se a chamada falhar.

    Temperatura 0 dá reprodutibilidade, NÃO ausência de viés — a demo da Aula 27
    existe para provar isso. Se vocês usarem esta rota no relatório, o número vem
    acompanhado da taxa de inversão e da concordância com o humano.
    """
    chave = chave or obter_chave()
    if not chave:
        return juiz_heuristico(caso, execucao)

    corpo = json.dumps({
        "model": MODELO_JUIZ,
        "messages": [{"role": "user", "content": _prompt_juiz(caso, execucao)}],
        "temperature": temperatura,
        "max_tokens": 200,
    }).encode("utf-8")
    requisicao = urllib.request.Request(
        URL_API, data=corpo,
        headers={"Authorization": f"Bearer {chave}", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(requisicao, timeout=TIMEOUT_S) as resposta:
            dados = json.loads(resposta.read().decode("utf-8"))
        conteudo = dados["choices"][0]["message"]["content"]
        achado = re.search(r"\{.*\}", conteudo, re.DOTALL)
        bruto = json.loads(achado.group(0))
        notas = {nome: float(bruto.get(nome, 0)) for nome in RUBRICA}
        total = sum(notas.values())
        return {
            "notas": notas,
            "nota": total,
            "veredito": "aprovada" if total >= LIMIAR_APROVACAO else "reprovada",
            "justificativa": str(bruto.get("motivo", ""))[:300],
        }
    except (urllib.error.URLError, urllib.error.HTTPError, KeyError, ValueError,
            AttributeError, TimeoutError) as erro:
        print(f"  [juiz LLM falhou: {type(erro).__name__}] caindo para o heurístico")
        return juiz_heuristico(caso, execucao)


# =========================================================================
# Pairwise e viés de posição (opcional, mas é o que fecha a Aula 27)
# =========================================================================

def juiz_pairwise(caso, execucao_primeira, execucao_segunda, julgar=None):
    """Qual das duas é melhor. Devolve 'primeira', 'segunda' ou 'empate'."""
    julgar = julgar or juiz_heuristico
    nota_1 = julgar(caso, execucao_primeira)["nota"]
    nota_2 = julgar(caso, execucao_segunda)["nota"]
    if abs(nota_1 - nota_2) < 0.5:
        return "empate"
    return "primeira" if nota_1 > nota_2 else "segunda"


def taxa_inversao(casos, execucoes_a, execucoes_b, julgar=None):
    """Fração de casos em que o vencedor muda quando a ordem muda.

    TODO 3 (opcional, vale ponto no relatório) — julgue cada caso em (A,B) e em (B,A),
    espelhe o segundo veredito e conte as divergências. Se vocês usarem juiz
    determinístico derivado de nota absoluta, este número sai 0% por construção — e
    essa é uma propriedade do instrumento, não uma virtude do sistema. Diga isso no
    relatório em vez de comemorar o zero.
    """
    raise NotImplementedError("TODO 3: taxa_inversao (opcional)")


def teste_checkpoint_3():
    """A rubrica tem de DISCRIMINAR: resposta boa e resposta ruim não podem empatar."""
    caso = {"id": "t01", "entrada": "qual o prazo?", "categoria": "fato_simples",
            "referencia": "quinze dias", "termos_exigidos": ["quinze dias"],
            "fontes_relevantes": ["F1"], "deve_recusar": False, "nota": "teste"}
    caso_recusa = {"id": "t02", "entrada": "assunto ausente", "categoria": "fora_do_escopo",
                   "referencia": "a base não cobre", "termos_exigidos": [],
                   "fontes_relevantes": [], "deve_recusar": True, "nota": "teste"}

    otima = {"resposta": "O prazo é de quinze dias (F1).", "fontes_citadas": ["F1"],
             "ranking": ["F1"], "trajetoria": [], "parou_por": "resposta", "recusou": False}
    fonte_errada = {"resposta": "O prazo é de quinze dias (F9).", "fontes_citadas": ["F9"],
                    "ranking": ["F9"], "trajetoria": [], "parou_por": "resposta",
                    "recusou": False}
    inventada = {"resposta": "O prazo é de quarenta e oito horas.", "fontes_citadas": [],
                 "ranking": ["F1"], "trajetoria": [], "parou_por": "resposta",
                 "recusou": False}
    recusa_limpa = {"resposta": "Não consigo responder com esta base.",
                    "fontes_citadas": [], "ranking": [], "trajetoria": [],
                    "parou_por": "recusa", "recusou": True}

    nota_otima = juiz_heuristico(caso, otima)
    nota_fonte = juiz_heuristico(caso, fonte_errada)
    nota_inventada = juiz_heuristico(caso, inventada)

    assert nota_otima["nota"] == NOTA_MAXIMA, "resposta correta e citada tira nota máxima"
    assert nota_otima["veredito"] == "aprovada"
    assert nota_inventada["nota"] < nota_fonte["nota"] < nota_otima["nota"], \
        "a rubrica precisa ORDENAR: inventada < fonte errada < correta"
    assert nota_inventada["veredito"] == "reprovada"

    assert juiz_heuristico(caso_recusa, recusa_limpa)["nota"] == NOTA_MAXIMA, \
        "recusar quando devia é acerto, não meia resposta"
    assert juiz_heuristico(caso_recusa, otima)["veredito"] == "reprovada", \
        "responder pergunta fora do escopo é reprovação"
    assert juiz_heuristico(caso, recusa_limpa)["veredito"] == "reprovada", \
        "recusar pergunta coberta é reprovação"

    assert "TODO" not in ADVERTENCIA_JUIZ, \
        "preencha ADVERTENCIA_JUIZ: o relatório tem de declarar quem julgou"

    print("Checkpoint 3 OK")
    return True


if __name__ == "__main__":
    teste_checkpoint_3()
