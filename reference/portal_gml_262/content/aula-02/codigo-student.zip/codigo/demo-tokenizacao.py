"""
Demo da Aula 2 — Tokenização
Grandes Modelos de Linguagem: do Transformer aos Agentes de IA · CESAR

O que este script faz, na ordem da aula:
  Parte 1 — mostra os tokens literais do mesmo conteúdo em PT e em EN, em quatro tokenizadores reais
  Parte 2 — mede fertilidade (tokens por palavra) e calcula a razão PT/EN
  Parte 3 — roda os casos difíceis: palavra longa, números, código com indentação, emoji
  Parte 4 — treina um BPE mínimo escrito do zero no mini-corpus do quadro e imprime os merges na ordem

Instalação:
    pip install transformers sentencepiece

IMPORTANTE — preparação na véspera da aula:
Rodar este script uma vez com rede boa para que os quatro tokenizadores fiquem no cache
local do Hugging Face (~/.cache/huggingface). A demo é ao vivo e o download da primeira
execução leva minutos. A Parte 4 não depende de rede nem de biblioteca externa: ela roda
mesmo com a rede caída.

Nenhuma chave de API é usada aqui — os tokenizadores são artefatos públicos.
"""

from __future__ import annotations

import os
import sys
import textwrap
from collections import Counter

# Silencia os avisos de inicialização do transformers: em demo ao vivo eles poluem a tela.
os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")


# --------------------------------------------------------------------------------------
# Configuração da demo
# --------------------------------------------------------------------------------------

# Quatro tokenizadores, cada um representando uma família diferente da aula.
TOKENIZER_SPECS = [
    ("gpt2", "BPE byte-level (GPT-2)"),
    ("bert-base-uncased", "WordPiece — corpus EN (BERT)"),
    ("neuralmind/bert-base-portuguese-cased", "WordPiece — corpus PT (BERTimbau)"),
    ("xlm-roberta-base", "Unigram/SentencePiece (XLM-R)"),
]

# Par paralelo: o mesmo conteúdo nas duas línguas. A razão de fertilidade sai daqui.
TEXT_PT = (
    "A tokenização é a primeira decisão de engenharia de um modelo de linguagem: "
    "alguém precisa definir o que conta como unidade de texto antes de qualquer treino começar. "
    "Essa decisão determina o custo de cada chamada de API, o tamanho útil da janela de contexto "
    "e a qualidade do modelo nas línguas pouco representadas no corpus."
)

TEXT_EN = (
    "Tokenization is the first engineering decision in a language model: "
    "someone has to define what counts as a unit of text before any training begins. "
    "This decision determines the cost of every API call, the usable size of the context window, "
    "and the model quality in the languages that are underrepresented in the corpus."
)

# Casos difíceis do Bloco 2. O comentário descreve o fenômeno; o número sai da execução.
HARD_CASES = [
    ("palavra longa", "inconstitucionalissimamente"),
    ("números", "O contrato de 2024 substitui o de 2027 e vence em 2031."),
    ("código com indentação", "def soma(a, b):\n    if a > b:\n        return a + b\n    return b"),
    ("emoji", "Deu tudo certo 🎉 obrigado!"),
]

# Mini-corpus do slide 6, com as frequências trabalhadas à mão no quadro.
MINI_CORPUS = {"casa": 5, "casas": 3, "casinha": 2, "casarão": 1}
MINI_MERGES = 3

SEP = "│"  # separador de fronteira de token: a turma tem que ver o corte
LINE = "-" * 88


# --------------------------------------------------------------------------------------
# Infraestrutura
# --------------------------------------------------------------------------------------

def setup_stdout() -> None:
    """Força UTF-8 na saída: sem isso, terminal Windows quebra em '▁', '│' e emoji."""
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def header(title: str) -> None:
    print(f"\n{LINE}\n{title}\n{LINE}")


def load_tokenizers() -> list[tuple[str, str, object]]:
    """Carrega os tokenizadores um a um, seguindo com os que der e avisando quais falharam."""
    from transformers import AutoTokenizer

    loaded: list[tuple[str, str, object]] = []
    failed: list[tuple[str, str]] = []

    for name, label in TOKENIZER_SPECS:
        try:
            tokenizer = AutoTokenizer.from_pretrained(name)
        except Exception as exc:  # rede, cache ausente, dependência faltando
            failed.append((name, f"{type(exc).__name__}: {exc}"))
            continue
        loaded.append((name, label, tokenizer))

    print(f"Tokenizadores carregados: {len(loaded)} de {len(TOKENIZER_SPECS)}")
    for name, label, _ in loaded:
        print(f"  ok    {name:<40} {label}")
    for name, reason in failed:
        print(f"  falha {name:<40} {reason}")
    if failed:
        print("\nA demo segue com os que carregaram. A Parte 4 roda offline, sem depender de nenhum.")
    return loaded


# --------------------------------------------------------------------------------------
# Parte 1 — as peças
# --------------------------------------------------------------------------------------

def show_pieces(tokenizers: list[tuple[str, str, object]]) -> None:
    header("PARTE 1 — o mesmo conteúdo, quatro tokenizadores (olhar as peças, não o total)")

    for language, text in (("PT", TEXT_PT), ("EN", TEXT_EN)):
        print(f"\n### {language}: {text[:70]}...")
        for name, label, tokenizer in tokenizers:
            pieces = tokenizer.tokenize(text)
            joined = SEP.join(pieces)
            print(f"\n  {name}  ({label})  —  {len(pieces)} tokens")
            for line in textwrap.wrap(joined, width=84, break_long_words=True):
                print(f"    {line}")


# --------------------------------------------------------------------------------------
# Parte 2 — fertilidade e a razão PT/EN
# --------------------------------------------------------------------------------------

def fertility(tokenizer, text: str) -> tuple[int, int, float]:
    """Fertilidade = tokens por palavra. Palavra aqui é separação por espaço em branco."""
    n_tokens = len(tokenizer.tokenize(text))
    n_words = len(text.split())
    return n_tokens, n_words, n_tokens / n_words


def show_fertility(tokenizers: list[tuple[str, str, object]]) -> None:
    header("PARTE 2 — fertilidade (tokens por palavra) e a razão PT/EN")

    print(f"\nPalavras no texto PT: {len(TEXT_PT.split())}   |   no texto EN: {len(TEXT_EN.split())}")
    print(
        f"\n{'tokenizador':<40}{'tok PT':>8}{'tok EN':>8}"
        f"{'fert PT':>10}{'fert EN':>10}{'razão PT/EN':>14}"
    )
    print(f"{'-' * 40}{'-' * 8}{'-' * 8}{'-' * 10}{'-' * 10}{'-' * 14}")

    for name, _, tokenizer in tokenizers:
        tokens_pt, _, fert_pt = fertility(tokenizer, TEXT_PT)
        tokens_en, _, fert_en = fertility(tokenizer, TEXT_EN)
        ratio = fert_pt / fert_en
        print(
            f"{name:<40}{tokens_pt:>8}{tokens_en:>8}"
            f"{fert_pt:>10.2f}{fert_en:>10.2f}{ratio:>14.2f}"
        )

    print(
        "\nA última coluna é o número da aula: quantas vezes mais tokens o mesmo conteúdo\n"
        "custa em português. Comparar a linha do tokenizador treinado em PT com as demais —\n"
        "a diferença mostra que a variável é o corpus dos merges, não a técnica."
    )


# --------------------------------------------------------------------------------------
# Parte 3 — casos difíceis
# --------------------------------------------------------------------------------------

def show_hard_cases(tokenizers: list[tuple[str, str, object]]) -> None:
    header("PARTE 3 — casos difíceis: números, código, palavra longa, emoji")

    for case_label, text in HARD_CASES:
        print(f"\n### {case_label}: {text!r}")
        for name, _, tokenizer in tokenizers:
            pieces = tokenizer.tokenize(text)
            joined = SEP.join(pieces)
            print(f"\n  {name}  —  {len(pieces)} tokens")
            for line in textwrap.wrap(joined, width=84, break_long_words=True):
                print(f"    {line}")


# --------------------------------------------------------------------------------------
# Parte 4 — BPE mínimo escrito do zero (roda offline)
# --------------------------------------------------------------------------------------

def count_pairs(splits: dict[str, list[str]], corpus: dict[str, int]) -> Counter:
    """Conta pares adjacentes de símbolos, ponderando pela frequência de cada palavra."""
    pairs: Counter = Counter()
    for word, symbols in splits.items():
        weight = corpus[word]
        for left, right in zip(symbols, symbols[1:]):
            pairs[(left, right)] += weight
    return pairs


def apply_merge(symbols: list[str], pair: tuple[str, str]) -> list[str]:
    """Aplica um merge da esquerda para a direita numa sequência de símbolos."""
    left, right = pair
    merged: list[str] = []
    i = 0
    while i < len(symbols):
        if i + 1 < len(symbols) and symbols[i] == left and symbols[i + 1] == right:
            merged.append(left + right)
            i += 2
        else:
            merged.append(symbols[i])
            i += 1
    return merged


def train_bpe(corpus: dict[str, int], num_merges: int):
    """Treina BPE: conta pares, funde o mais frequente, repete. O modelo é a lista de merges.

    A fronteira de palavra é omitida de propósito, para bater com o exemplo feito no quadro.
    Implementações reais marcam a fronteira (</w> no BPE clássico, ▁ no SentencePiece)
    para conseguir detokenizar sem ambiguidade.
    """
    splits = {word: list(word) for word in corpus}
    merges: list[tuple[tuple[str, str], int, dict[str, list[str]]]] = []

    for _ in range(num_merges):
        pairs = count_pairs(splits, corpus)
        if not pairs:
            break
        best_pair, best_count = pairs.most_common(1)[0]
        splits = {word: apply_merge(symbols, best_pair) for word, symbols in splits.items()}
        merges.append((best_pair, best_count, dict(splits)))

    return merges, splits


def show_mini_bpe() -> None:
    header("PARTE 4 — BPE do zero no mini-corpus do quadro (não usa rede)")

    print("\nMini-corpus:  " + "  ".join(f"{w}×{c}" for w, c in MINI_CORPUS.items()))
    initial = {word: list(word) for word in MINI_CORPUS}
    print("Início:       " + "   ".join(" ".join(s) for s in initial.values()))

    merges, final_splits = train_bpe(MINI_CORPUS, MINI_MERGES)

    print(f"\n{'#':<4}{'par fundido':<22}{'contagem':>10}   corpus depois")
    print(f"{'-' * 4}{'-' * 22}{'-' * 10}   {'-' * 42}")
    for index, (pair, count, splits_after) in enumerate(merges, start=1):
        left, right = pair
        merged_symbol = f"{left}+{right} -> {left + right}"
        corpus_after = "  ".join(" ".join(s) for s in splits_after.values())
        print(f"{index:<4}{merged_symbol:<22}{count:>10}   {corpus_after}")

    print("\nSegmentação final:")
    for word, symbols in final_splits.items():
        print(f"  {word:<12} {SEP.join(symbols)}   ({len(symbols)} token(s))")

    print(
        "\nO modelo treinado é essa lista ordenada de merges — nada mais.\n"
        "Codificar uma palavra nova é partir dos caracteres e aplicar a lista nessa ordem."
    )


# --------------------------------------------------------------------------------------

def main() -> None:
    setup_stdout()
    header("Aula 2 — Tokenização · demo do instrutor")

    tokenizers = load_tokenizers()

    if tokenizers:
        show_pieces(tokenizers)
        show_fertility(tokenizers)
        show_hard_cases(tokenizers)
    else:
        print("\nNenhum tokenizador carregou — rodando só a Parte 4, que é offline.")

    show_mini_bpe()


if __name__ == "__main__":
    main()
