#!/usr/bin/env python3
"""
Aula 3 — Embeddings e representações vetoriais · demo do instrutor.

Quatro partes, na ordem dos slides:
  1. one-hot em NumPy: a matriz de cossenos mostra que não existe semelhança (slide 3)
  2. vizinhos semânticos num espaço denso pré-treinado                     (slides 4 a 6)
  3. duas analogias vetoriais — uma de categoria forte, uma de fraca       (slide 7)
  4. os vizinhos de uma palavra ambígua: um vetor, dois sentidos           (slide 12)

Instalação (Colab ou local):

    pip install -q "gensim==4.3.3" "scipy<1.14" "numpy<2"

Pinagem obrigatória, não é preciosismo:
  - gensim 4.3.2 importa `scipy.linalg.triu`, que foi removido no scipy 1.13 —
    a combinação quebra no import com ImportError. O gensim 4.3.3 corrigiu esse
    import; manter `scipy<1.14` evita cair na combinação ruim caso o resolvedor
    de dependências escolha um gensim antigo.
  - `numpy<2`: as wheels compiladas do gensim 4.3.x são construídas contra a
    ABI do NumPy 1.x.
  - No Colab, reiniciar o runtime depois de instalar (o scipy já vem carregado).

Uso:

    python demo-embeddings.py              # usa o modelo pré-treinado (precisa de cache)
    python demo-embeddings.py --offline    # treina um modelo minúsculo embutido neste arquivo
    python demo-embeddings.py --topn 15    # quantos vizinhos listar

O modelo pré-treinado é baixado por `gensim.downloader` e tem ordem de 100 MB.
O cache fica em `~/gensim-data`. Baixar ANTES da aula: não se faz download de
100 MB na frente da turma.

Nenhum resultado está escrito nos comentários — o script mede e imprime.
"""

from __future__ import annotations

import argparse

import numpy as np

# Nome do modelo pré-treinado. Alternativa mais leve: "glove-wiki-gigaword-50".
PRETRAINED_MODEL = "glove-wiki-gigaword-100"

# Palavras da parte 1. |V| = 4 só para a matriz caber na tela: a ortogonalidade
# do one-hot não depende do tamanho do vocabulário, vale para |V| = 50 000 igual.
ONE_HOT_WORDS = ["gato", "gatinho", "cachorro", "parafuso"]

# Partes 2 a 4 com o modelo pré-treinado (inglês).
PRETRAINED_NEIGHBOR_WORDS = ["king", "python", "hospital"]
PRETRAINED_AMBIGUOUS_WORD = "bank"

# Analogias: (positivos, negativos, palavra esperada, rótulo da categoria).
# O script imprime os candidatos e marca se a esperada apareceu. Se a segunda
# analogia falhar, isso é o conteúdo do slide 7 — não é o script quebrado.
PRETRAINED_ANALOGIES = [
    (["king", "woman"], ["man"], "queen", "gênero (categoria que costuma funcionar)"),
    (["japan", "dollar"], ["usa"], "yen", "país→moeda (categoria notoriamente fraca)"),
]

# Mini-corpus do modo --offline. É de brinquedo de propósito: serve para provar a
# mecânica do treino quando a rede falha. Os vizinhos que ele produz são ruins, e
# investigar POR QUE são ruins é justamente o Lab 1 (Aula 4). Note que "banco"
# aparece nos dois sentidos — é o material do slide 12.
MINI_CORPUS = [
    "o gato dormia no sofá da sala",
    "o gato subiu no telhado da casa",
    "o gatinho dormia perto do gato",
    "o cachorro dormia no tapete da sala",
    "o cachorro correu atrás do gato no quintal",
    "o gerente do banco liberou o crédito da empresa",
    "o banco cobrou juros altos no empréstimo",
    "a fila do banco estava enorme hoje",
    "sentei no banco da praça para ler o jornal",
    "o banco de madeira da praça estava molhado",
    "as crianças subiram no banco da praça",
    "o médico atendeu o paciente no hospital",
    "o enfermeiro acompanhou o médico na visita",
    "o hospital recebeu novos equipamentos",
    "a água do café estava quente demais",
    "a água da piscina estava fria demais",
    "o dia amanheceu quente e sem vento",
    "o dia amanheceu frio e com chuva",
    "comprei manga e caju na feira da cidade",
    "a manga da camisa estava rasgada",
]

OFFLINE_NEIGHBOR_WORDS = ["gato", "médico", "praça"]
OFFLINE_AMBIGUOUS_WORD = "banco"
OFFLINE_ANALOGIES = [
    (["gato", "cachorro"], ["gatinho"], "cachorro", "analogia em corpus de brinquedo"),
]


# ---------------------------------------------------------------------------
# Utilitários
# ---------------------------------------------------------------------------

def cosine(u: np.ndarray, v: np.ndarray) -> float:
    """cos(u,v) = (u · v) / (‖u‖ ‖v‖). Escrita à mão: é a fórmula do slide 6."""
    denominator = float(np.linalg.norm(u) * np.linalg.norm(v))
    if denominator == 0.0:
        return 0.0
    return float(np.dot(u, v) / denominator)


def header(title: str) -> None:
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)


def safe_most_similar(vectors, positive, negative, topn):
    """Envolve most_similar: palavra fora do vocabulário devolve None em vez de estourar."""
    try:
        return vectors.most_similar(positive=positive, negative=negative, topn=topn)
    except KeyError as error:
        print(f"    [fora do vocabulário deste modelo: {error}]")
        return None


# ---------------------------------------------------------------------------
# Parte 1 — one-hot não tem semelhança (slide 3)
# ---------------------------------------------------------------------------

def one_hot_matrix(words: list[str]) -> np.ndarray:
    """Linha i = vetor one-hot da palavra i. Com |V| palavras, cada vetor tem |V| posições."""
    return np.eye(len(words), dtype=float)


def parte_1_one_hot(words: list[str] = ONE_HOT_WORDS) -> None:
    header("PARTE 1 — one-hot: a matriz de cossenos (sem download, só NumPy)")
    vectors = one_hot_matrix(words)

    print(f"\nVocabulário da demo: {words}  ->  cada vetor tem {len(words)} dimensões")
    print("Vetores:")
    for word, vector in zip(words, vectors):
        print(f"  {word:<10} {vector.astype(int)}")

    print("\nMatriz de cossenos (calculada com a fórmula do slide, não com biblioteca):\n")
    width = max(len(word) for word in words) + 2
    print(" " * width + "".join(f"{word:>{width}}" for word in words))
    for word_a, vector_a in zip(words, vectors):
        row = "".join(f"{cosine(vector_a, vector_b):>{width}.2f}" for vector_b in vectors)
        print(f"{word_a:<{width}}{row}")

    print(
        "\nLeitura: 1 na diagonal (cada palavra é idêntica a si mesma) e 0 em todo o resto.\n"
        "Não existe 'mais parecido' aqui — nenhuma semelhança para o modelo generalizar."
    )


# ---------------------------------------------------------------------------
# Carregamento do espaço denso: pré-treinado ou modelo minúsculo embutido
# ---------------------------------------------------------------------------

def load_pretrained(model_name: str = PRETRAINED_MODEL):
    """Carrega vetores pré-treinados do cache de `gensim.downloader` (~/gensim-data)."""
    import gensim.downloader as api

    print(f"\nCarregando '{model_name}' (cache em ~/gensim-data)...")
    vectors = api.load(model_name)
    print(f"Pronto: {len(vectors.index_to_key)} palavras, {vectors.vector_size} dimensões.")
    return vectors


def train_tiny_model(epochs: int = 300):
    """Treina um Word2Vec skip-gram minúsculo no MINI_CORPUS. Vizinhos ruins são o esperado."""
    from gensim.models import Word2Vec

    sentences = [sentence.lower().split() for sentence in MINI_CORPUS]
    print(f"\nTreinando Word2Vec no mini-corpus embutido: {len(sentences)} frases.")
    model = Word2Vec(
        sentences,
        vector_size=50,     # d do slide 5, no limite inferior da faixa
        window=3,           # janela pequena: substituibilidade (slide 9)
        min_count=1,        # corpus minúsculo: não dá para descartar nada
        sg=1,               # skip-gram: melhor em corpus pequeno (slide 9)
        negative=5,         # k da amostragem negativa (slide 10)
        epochs=epochs,
        workers=1,
        seed=42,
    )
    print(f"Pronto: {len(model.wv.index_to_key)} palavras, {model.wv.vector_size} dimensões.")
    return model.wv


# ---------------------------------------------------------------------------
# Parte 2 — vizinhos semânticos (slides 4 a 6)
# ---------------------------------------------------------------------------

def parte_2_vizinhos(vectors, words: list[str], topn: int) -> None:
    header("PARTE 2 — vizinhos semânticos num espaço denso")
    for word in words:
        print(f"\nVizinhos de '{word}':")
        if word not in vectors:
            print("    [fora do vocabulário deste modelo]")
            continue
        for neighbor, score in vectors.most_similar(word, topn=topn):
            print(f"    {neighbor:<20} {score:.3f}")

    print(
        "\nNinguém escreveu essas relações à mão. Elas vieram de contar quem aparece\n"
        "perto de quem — hipótese distribucional, slide 4."
    )


# ---------------------------------------------------------------------------
# Parte 3 — analogias vetoriais (slide 7)
# ---------------------------------------------------------------------------

def parte_3_analogias(vectors, analogies, topn: int = 3) -> None:
    header("PARTE 3 — analogias vetoriais: uma categoria forte, uma fraca")
    for positive, negative, expected, label in analogies:
        equation = " + ".join(positive)
        if negative:
            equation += " − " + " − ".join(negative)
        print(f"\n{equation}   [{label}]")
        print(f"    esperado: '{expected}'")

        candidates = safe_most_similar(vectors, positive, negative, topn)
        if candidates is None:
            continue
        for candidate, score in candidates:
            mark = "  <- esperado" if candidate == expected else ""
            print(f"    {candidate:<20} {score:.3f}{mark}")

        found = any(candidate == expected for candidate, _ in candidates)
        print(f"    a palavra esperada apareceu no top-{topn}: {'sim' if found else 'NÃO'}")

    print(
        "\nA analogia que falha é a parte pedagógica: regularidade linear induzida por\n"
        "coocorrência funciona em algumas categorias e não em outras — slide 7."
    )


# ---------------------------------------------------------------------------
# Parte 4 — a palavra ambígua (slide 12)
# ---------------------------------------------------------------------------

def parte_4_ambiguidade(vectors, word: str, topn: int) -> None:
    header(f"PARTE 4 — um vetor, dois sentidos: os vizinhos de '{word}'")
    if word not in vectors:
        print(f"    ['{word}' está fora do vocabulário deste modelo]")
        return

    for neighbor, score in vectors.most_similar(word, topn=topn):
        print(f"    {neighbor:<20} {score:.3f}")

    print(
        f"\nOs dois campos semânticos de '{word}' aparecem na MESMA lista, porque existe\n"
        "um vetor só para a palavra. Ele é um compromisso entre os sentidos, e a frase\n"
        "em que a palavra está não participa da consulta — slide 12."
    )


# ---------------------------------------------------------------------------
# Orquestração
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Demo de embeddings da Aula 3.")
    parser.add_argument(
        "--offline",
        action="store_true",
        help="não baixa nada: treina um Word2Vec minúsculo no mini-corpus embutido",
    )
    parser.add_argument(
        "--model",
        default=PRETRAINED_MODEL,
        help=f"modelo do gensim.downloader (padrão: {PRETRAINED_MODEL})",
    )
    parser.add_argument("--topn", type=int, default=10, help="quantos vizinhos listar")
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    # Parte 1 roda sempre: é só NumPy e não depende de rede nem de gensim.
    parte_1_one_hot()

    if args.offline:
        vectors = train_tiny_model()
        neighbor_words = OFFLINE_NEIGHBOR_WORDS
        analogies = OFFLINE_ANALOGIES
        ambiguous_word = OFFLINE_AMBIGUOUS_WORD
        print(
            "\n[modo --offline] Este modelo viu poucas dezenas de frases. Os vizinhos\n"
            "vão ser ruins, e isso é o esperado: é exatamente a pergunta dirigida da\n"
            "leitura de hoje e o assunto do Lab 1."
        )
    else:
        try:
            vectors = load_pretrained(args.model)
        except Exception as error:  # rede, cache ausente, dependência quebrada
            print(f"\nFalha ao carregar '{args.model}': {type(error).__name__}: {error}")
            print(
                "\nCaminhos possíveis:\n"
                f"  - baixar antes da aula: python -c \"import gensim.downloader as api;"
                f" api.load('{args.model}')\"  (~100 MB, cache em ~/gensim-data)\n"
                "  - se o erro citar scipy.linalg.triu ou ABI do NumPy, reinstalar com as\n"
                '    versões pinadas do cabeçalho e reiniciar o runtime\n'
                "  - contingência de sala: rodar com --offline"
            )
            return
        neighbor_words = PRETRAINED_NEIGHBOR_WORDS
        analogies = PRETRAINED_ANALOGIES
        ambiguous_word = PRETRAINED_AMBIGUOUS_WORD

    parte_2_vizinhos(vectors, neighbor_words, args.topn)
    parte_3_analogias(vectors, analogies)
    parte_4_ambiguidade(vectors, ambiguous_word, args.topn)

    header("Fim da demo")
    print(
        "Treinar do zero, em corpus português, medindo o que um corpus pequeno não\n"
        "consegue aprender: é o Laboratório 1, na Aula 4."
    )


if __name__ == "__main__":
    main()
